﻿<?php
include('header.php');
?>

  <main class="main auto-page-main">
    <section class="auto-page-hero">
      <div class="container" data-aos="fade-up">
        <span class="auto-eyebrow">The Rehman Brothers difference</span>
        <h1>Confidence in every drive</h1>
        <p>Buying a car should feel exciting â€” not stressful. We combine verified Japanese stock, clear pricing, and real after-sales support so you can choose with complete peace of mind.</p>
        <div class="auto-trust-bar">
          <span><i class="bi bi-star-fill"></i> 5.0 rated service</span>
          <span><i class="bi bi-people"></i> 1,200+ cars delivered</span>
          <span><i class="bi bi-award"></i> 18+ years experience</span>
        </div>
      </div>
    </section>

    <section class="why-page-content section">
      <div class="container">
        <div class="row g-4">
          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <div class="why-page-card">
              <span>01</span>
              <i class="bi bi-shield-check"></i>
              <h3>Trusted Dealer</h3>
              <p>Dependable vehicles and honest guidance from a team that values long-term relationships over quick sales.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="150">
            <div class="why-page-card">
              <span>02</span>
              <i class="bi bi-receipt"></i>
              <h3>Transparent Pricing</h3>
              <p>Clear deals, practical advice, and no confusing surprises when you make your decision.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <div class="why-page-card">
              <span>03</span>
              <i class="bi bi-search"></i>
              <h3>Quality Inspection</h3>
              <p>Every vehicle is reviewed for condition, performance, and road-readiness before handover.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6" data-aos="fade-up" data-aos-delay="250">
            <div class="why-page-card">
              <span>04</span>
              <i class="bi bi-headset"></i>
              <h3>Support After Sale</h3>
              <p>Our relationship continues with maintenance guidance and responsive after-sales support.</p>
            </div>
          </div>
        </div>

        <div class="row g-4 mt-2">
          <div class="col-lg-4" data-aos="fade-up">
            <div class="auto-value-card">
              <i class="bi bi-car-front"></i>
              <h4>Curated Japanese Stock</h4>
              <p>We focus on reliable brands and models that perform well on Pakistani roads â€” not random listings.</p>
            </div>
          </div>
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <div class="auto-value-card">
              <i class="bi bi-clock-history"></i>
              <h4>Fast, Smooth Process</h4>
              <p>From shortlisting to documentation, we keep things moving so you are not stuck waiting weeks.</p>
            </div>
          </div>
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <div class="auto-value-card">
              <i class="bi bi-chat-dots"></i>
              <h4>Real People, Real Answers</h4>
              <p>Talk directly to people who know cars â€” not scripted sales talk or vague promises.</p>
            </div>
          </div>
        </div>

        <div class="mt-5" data-aos="fade-up">
          <span class="auto-eyebrow">How it works</span>
          <h2 class="mt-2 mb-4" style="font-weight:700;">Your journey with us</h2>
          <div class="auto-process-grid">
            <div class="auto-process-step">
              <span>1</span>
              <h4>Tell us what you need</h4>
              <p>Share your budget, preferred model, and how you plan to use the car.</p>
            </div>
            <div class="auto-process-step">
              <span>2</span>
              <h4>Shortlist &amp; inspect</h4>
              <p>We show matching options and walk you through condition and value.</p>
            </div>
            <div class="auto-process-step">
              <span>3</span>
              <h4>Test &amp; decide</h4>
              <p>Take a test drive, ask questions, and choose with full clarity.</p>
            </div>
            <div class="auto-process-step">
              <span>4</span>
              <h4>Drive away happy</h4>
              <p>Documentation, handover, and ongoing support â€” all handled properly.</p>
            </div>
          </div>
        </div>

        <div class="why-page-banner">
          <div>
            <span class="auto-eyebrow">Find your right car</span>
            <h2>Want a car that fits your needs?</h2>
          </div>
          <a class="auto-primary-btn" href="contact.html">Contact us <i class="bi bi-arrow-up-right"></i></a>
        </div>
      </div>
    </section>

    <section class="customer-stories section">
      <div class="container section-title" data-aos="fade-up">
        <span class="section-kicker">Customer stories</span>
        <h2>Why drivers come back to us</h2>
        <p>Real feedback from people who bought, drove, and recommended us.</p>
      </div>
      <div class="container">
        <div class="row g-4">
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <article class="testimonial-card">
              <div class="testimonial-stars">â˜…â˜…â˜…â˜…â˜…</div>
              <p>&ldquo;They did not push me into anything. Just honest advice and a car that matched exactly what I needed.&rdquo;</p>
              <div class="testimonial-author"><strong>Faisal K.</strong><span>Toyota Corolla buyer</span></div>
            </article>
          </div>
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="150">
            <article class="testimonial-card featured">
              <div class="testimonial-stars">â˜…â˜…â˜…â˜…â˜…</div>
              <p>&ldquo;Inspection report, clear price, quick delivery â€” everything was handled professionally from start to finish.&rdquo;</p>
              <div class="testimonial-author"><strong>Maria S.</strong><span>Honda Civic buyer</span></div>
            </article>
          </div>
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <article class="testimonial-card">
              <div class="testimonial-stars">â˜…â˜…â˜…â˜…â˜…</div>
              <p>&ldquo;Even after purchase they helped with servicing questions. That kind of support is rare.&rdquo;</p>
              <div class="testimonial-author"><strong>Imran A.</strong><span>Suzuki Swift buyer</span></div>
            </article>
          </div>
        </div>
      </div>
    </section>
  </main>

   <?php
include('footer.php');
?>