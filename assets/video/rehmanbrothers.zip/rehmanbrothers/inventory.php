﻿<?php
include('header.php');
?>
<style>
  /* ==========================================
   CC FILTER ONLY
========================================== */

#inventory-cc {
    width: 190px;
    height: 50px;
    padding: 0 42px 0 16px;

    border: 1px solid #e1e5ea;
    border-radius: 8px;

    background-color: #fff;
    color: #222;

    font-size: 14px;
    font-weight: 500;

    cursor: pointer;
    outline: none;

    appearance: none;
    -webkit-appearance: none;

    /* Clean dropdown arrow */
    background-image:
        linear-gradient(45deg, transparent 50%, #555 50%),
        linear-gradient(135deg, #555 50%, transparent 50%);

    background-position:
        calc(100% - 18px) 21px,
        calc(100% - 13px) 21px;

    background-size:
        5px 5px,
        5px 5px;

    background-repeat: no-repeat;

    transition: all 0.2s ease;
}


/* Hover */
#inventory-cc:hover {
    border-color: #2563eb;
}


/* When clicked / focused */
#inventory-cc:focus {
    border-color: #2563eb;
    box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.08);
}


/* Dropdown menu options */
#inventory-cc option {
    background: #ffffff;
    color: #222;
    font-size: 14px;
    font-weight: 400;
    padding: 10px;
}


/* Selected option */
#inventory-cc option:checked {
    background: #2563eb;
    color: #ffffff;
}
  </style>
  <main class="main auto-page-main">
    <section class="auto-page-hero">
      <div class="container" data-aos="fade-up">
        <span class="auto-eyebrow">Featured inventory</span>
        <h1>Import a Car You Can Trust</h1>
        <p>Tired of fake mileage and hidden accidents? Every car we import comes with a verified auction report, pre-shipment inspection, and fixed pricing. From Serena to Alphard, Land Cruiser to Civic - we get it for you.</p>
        <div class="auto-trust-bar">
          <span><i class="bi bi-shield-check"></i> Pre-inspected stock</span>
          <span><i class="bi bi-receipt"></i> Transparent pricing</span>
          <span><i class="bi bi-truck"></i> Fast handover</span>
        </div>
      </div>
    </section>

    <section class="auto-listing section">
      <div class="container">
        <div class="auto-section-heading">
          <div>
            <span class="auto-eyebrow">Available now</span>
            <h2>Handpicked vehicles</h2>
          </div>
          <a class="auto-outline-btn" href="contact.html">Request a vehicle <i class="bi bi-arrow-up-right"></i></a>
        </div>

        <div class="inventory-search-panel" data-aos="fade-up">
          <div class="inventory-search-field">
            <i class="bi bi-search"></i>
            <input type="search" id="inventory-search" placeholder="Search model, brand, fuel, price, year...">
          </div>
<select id="inventory-cc" aria-label="Filter by engine capacity">
    <option value="all">All CC</option>
    <option value="600">600cc</option>
    <option value="1000">1000cc</option>
    <option value="1300">1300cc</option>
    <option value="1500">1500cc</option>
    <option value="1500plus">1500+cc</option>
</select>
        </div>

      


             <?php
require_once('config.php');

$query = "SELECT * FROM inventory ORDER BY id DESC";
$result = mysqli_query($conn, $query);
?>

<div class="inventory-grid">

<?php while ($vehicle = mysqli_fetch_assoc($result)): ?>

  <article 
    class="auto-vehicle-card inventory-clickable"
    data-car-id="<?= htmlspecialchars($vehicle['id']) ?>"
    data-engine-capacity="<?= htmlspecialchars($vehicle['engine_capacity']) ?>"

    role="button"
    tabindex="0"
  >

    <div class="auto-vehicle-image">
      <img 
        src="uploads/<?= htmlspecialchars($vehicle['img_1']) ?>" 
        alt="<?= htmlspecialchars($vehicle['name']) ?>"
      >
    </div>

    <div class="auto-vehicle-body">

      <span class="auto-tag">
        <?= htmlspecialchars($vehicle['conditions']) ?>
      </span>

      <h3><?= htmlspecialchars($vehicle['name']) ?></h3>

      <p>
        <?= htmlspecialchars($vehicle['year']) ?>
        &middot;
        <?= htmlspecialchars($vehicle['transmission']) ?>
        &middot;
        <?= htmlspecialchars($vehicle['fuel']) ?>
        &middot;
        <?= htmlspecialchars($vehicle['mileage']) ?>
           &middot;
        <?= htmlspecialchars($vehicle['engine_capacity']) ?>
      </p>

      <strong>
        $ <?= number_format((float)$vehicle['price']) ?>
      </strong>

      <button type="button" class="inventory-view-btn">
        View details <i class="bi bi-arrow-right"></i>
      </button>

    </div>

  </article>

<?php endwhile; ?>
        
<!-- Vehicle Details Modal -->

<div id="vehicleDetailsModal" class="vehicle-modal" aria-hidden="true">

  <div class="vehicle-modal-overlay"></div>

  <div class="vehicle-modal-content">

```
<!-- Close -->
<button type="button" class="vehicle-modal-close" id="vehicleModalClose">
  <i class="bi bi-x-lg"></i>
</button>

<!-- Loading -->
<div id="vehicleModalLoading" class="vehicle-modal-loading">
  <div class="vehicle-spinner"></div>
  <p>Loading vehicle details...</p>
</div>

<!-- Vehicle Details -->
<div id="vehicleModalDetails" class="vehicle-modal-details" style="display:none;">

  <!-- Image Gallery -->
  <div class="vehicle-gallery">

    <div class="vehicle-main-image-wrap">

      <img
        id="vehicleMainImage"
        src=""
        alt="Vehicle"
        class="vehicle-main-image"
      >

      <button
        type="button"
        class="vehicle-gallery-btn vehicle-gallery-prev"
        id="vehicleGalleryPrev"
      >
        <i class="bi bi-chevron-left"></i>
      </button>

      <button
        type="button"
        class="vehicle-gallery-btn vehicle-gallery-next"
        id="vehicleGalleryNext"
      >
        <i class="bi bi-chevron-right"></i>
      </button>

      <div class="vehicle-image-counter" id="vehicleImageCounter">
        1 / 1
      </div>

    </div>

    <!-- Thumbnails -->
    <div class="vehicle-thumbnails" id="vehicleThumbnails"></div>

  </div>


  <!-- Vehicle Information -->
  <div class="vehicle-modal-info">

    <div class="vehicle-modal-heading">

      <div>
        <span class="auto-tag" id="vehicleCondition"></span>

        <h2 id="vehicleName"></h2>

        <p class="vehicle-modal-subtitle" id="vehicleSummary"></p>
      </div>

      <div class="vehicle-modal-price" id="vehiclePrice"></div>

    </div>


    <!-- Specifications -->
    <div class="vehicle-specifications">

      <div class="vehicle-spec-item">
        <i class="bi bi-calendar3"></i>
        <div>
          <span>Year</span>
          <strong id="vehicleYear"></strong>
        </div>
      </div>

      <div class="vehicle-spec-item">
        <i class="bi bi-gear"></i>
        <div>
          <span>Transmission</span>
          <strong id="vehicleTransmission"></strong>
        </div>
      </div>

      <div class="vehicle-spec-item">
        <i class="bi bi-fuel-pump"></i>
        <div>
          <span>Fuel</span>
          <strong id="vehicleFuel"></strong>
        </div>
      </div>

      <div class="vehicle-spec-item">
        <i class="bi bi-speedometer2"></i>
        <div>
          <span>Mileage</span>
          <strong id="vehicleMileage"></strong>
        </div>
      </div>

      <div class="vehicle-spec-item">
        <i class="bi bi-cpu"></i>
        <div>
          <span>Engine</span>
          <strong id="vehicleEngine"></strong>
        </div>
      </div>

      <div class="vehicle-spec-item">
        <i class="bi bi-palette"></i>
        <div>
          <span>Color</span>
          <strong id="vehicleColor"></strong>
        </div>
      </div>

      <div class="vehicle-spec-item">
        <i class="bi bi-people"></i>
        <div>
          <span>Seats</span>
          <strong id="vehicleSeats"></strong>
        </div>
      </div>

      <div class="vehicle-spec-item">
        <i class="bi bi-upc-scan"></i>
        <div>
          <span>Chassis Number</span>
          <strong id="vehicleChassis"></strong>
        </div>
      </div>

    </div>


    <!-- Description -->
    <div class="vehicle-description">

      <div class="vehicle-detail-title">
        <i class="bi bi-info-circle"></i>
        <h3>Vehicle Description</h3>
      </div>

      <p id="vehicleDescription"></p>

    </div>


    <!-- Actions -->
    <div class="vehicle-modal-actions">

      <a
        href="contact.php"
        class="auto-primary-btn"
      >
        <i class="bi bi-chat-dots"></i>
        Inquire About This Vehicle
      </a>

    

    </div>

  </div>

</div>
```

  </div>
</div>

     
       

        
    </section>

    <section class="section pt-0">
      <div class="container" data-aos="fade-up">
        <div class="auto-cta-strip d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-4">
          <div>
            <span class="auto-eyebrow" style="color:#77a9ff;">Find your right car</span>
            <h2>Want a car that fits your needs?</h2>
            <p>Contact us and our team will help you find the right car with honest guidance and clear answers.</p>
          </div>
          <a class="auto-primary-btn" href="contact.html">Contact us <i class="bi bi-arrow-up-right"></i></a>
        </div>
      </div>
    </section>
  </main>
  <script>
    /* ==========================================
   INVENTORY SEARCH + CC FILTER
========================================== */

const searchInput = document.getElementById("inventory-search");
const ccFilter = document.getElementById("inventory-cc");
const inventoryCards = document.querySelectorAll(".inventory-clickable");

function filterInventory() {

    const searchValue = searchInput.value.toLowerCase().trim();
    const selectedCC = ccFilter.value;

    inventoryCards.forEach(function (card) {

        const cardText = card.innerText.toLowerCase();
        const engineCapacity =
            (card.dataset.engineCapacity || "").toLowerCase();

        /* SEARCH */
        const matchesSearch =
            searchValue === "" ||
            cardText.includes(searchValue) ||
            engineCapacity.includes(searchValue);

        /* CC FILTER */
        let matchesCC = true;

        if (selectedCC !== "all") {

            const ccNumber =
                parseInt(engineCapacity.replace(/[^0-9]/g, ""));

            if (selectedCC === "600") {
                matchesCC = ccNumber === 600;
            }

            else if (selectedCC === "1000") {
                matchesCC = ccNumber === 1000;
            }

            else if (selectedCC === "1300") {
                matchesCC = ccNumber === 1300;
            }

            else if (selectedCC === "1500") {
                matchesCC = ccNumber === 1500;
            }

            else if (selectedCC === "1500plus") {
                matchesCC = ccNumber > 1500;
            }
        }

        /* SHOW / HIDE */
        if (matchesSearch && matchesCC) {
            card.style.display = "";
        } else {
            card.style.display = "none";
        }

    });
}


/* LIVE SEARCH */
searchInput.addEventListener("input", filterInventory);


/* CC FILTER */
ccFilter.addEventListener("change", filterInventory);
    </script>
<script>
document.addEventListener("DOMContentLoaded", function () {

    console.log("Vehicle modal JS loaded");

    const modal = document.getElementById("vehicleDetailsModal");
    const closeBtn = document.getElementById("vehicleModalClose");
    const overlay = document.querySelector(".vehicle-modal-overlay");

    if (!modal) {
        console.error("ERROR: vehicleDetailsModal not found");
        return;
    }

    /*
    ==========================================
    OPEN VEHICLE MODAL
    ==========================================
    */

    document.querySelectorAll(".inventory-clickable").forEach(function (card) {

        card.addEventListener("click", function (e) {

            /*
            If user clicked the button, don't let
            card click cause any weird behaviour.
            */

            e.preventDefault();

            const vehicleId = this.dataset.carId;

            console.log("Vehicle clicked:", vehicleId);

            if (!vehicleId) {
                console.error("Vehicle ID missing");
                return;
            }

            openVehicle(vehicleId);

        });

    });


    /*
    ==========================================
    FETCH VEHICLE
    ==========================================
    */

    function openVehicle(vehicleId) {

        modal.classList.add("active");

        modal.setAttribute("aria-hidden", "false");

        document.body.classList.add("vehicle-modal-open");

        const loading = document.getElementById("vehicleModalLoading");
        const details = document.getElementById("vehicleModalDetails");

        loading.style.display = "flex";
        details.style.display = "none";


        fetch("vehicle-details.php?id=" + encodeURIComponent(vehicleId))

            .then(function (response) {

                if (!response.ok) {
                    throw new Error("HTTP error: " + response.status);
                }

                return response.json();

            })

            .then(function (data) {

                console.log("Vehicle data:", data);

                if (!data.success) {
                    throw new Error(
                        data.message || "Vehicle not found"
                    );
                }

                showVehicle(data.vehicle);

                loading.style.display = "none";

                details.style.display = "grid";

            })

            .catch(function (error) {

                console.error("Vehicle fetch error:", error);

                loading.innerHTML = `
                    <i class="bi bi-exclamation-circle"
                       style="font-size:45px;color:var(--accent-color);">
                    </i>

                    <p>
                        Unable to load vehicle details.
                    </p>

                    <small>
                        ${error.message}
                    </small>
                `;

            });

    }


    /*
    ==========================================
    SHOW VEHICLE DETAILS
    ==========================================
    */

    function showVehicle(vehicle) {

        document.getElementById("vehicleName").textContent =
            vehicle.name || "Vehicle";

        document.getElementById("vehicleCondition").textContent =
            vehicle.conditions || "Available";

        document.getElementById("vehicleSummary").textContent =
            (vehicle.year || "") +
            " · " +
            (vehicle.transmission || "") +
            " · " +
            (vehicle.fuel || "");

        document.getElementById("vehiclePrice").textContent =
            "$ " +
            Number(vehicle.price || 0).toLocaleString("en-PK");


        document.getElementById("vehicleYear").textContent =
            vehicle.year || "N/A";

        document.getElementById("vehicleTransmission").textContent =
            vehicle.transmission || "N/A";

        document.getElementById("vehicleFuel").textContent =
            vehicle.fuel || "N/A";

        document.getElementById("vehicleMileage").textContent =
            vehicle.mileage || "N/A";

        document.getElementById("vehicleEngine").textContent =
            vehicle.engine || "N/A";

        document.getElementById("vehicleColor").textContent =
            vehicle.color || "N/A";

        document.getElementById("vehicleSeats").textContent =
            vehicle.seats || "N/A";

        document.getElementById("vehicleChassis").textContent =
            vehicle.chassis_number || "N/A";

        document.getElementById("vehicleDescription").textContent =
            vehicle.description || "No description available.";


        /*
        ==========================================
        IMAGES
        ==========================================
        */

        const images = (vehicle.images || []).map(function (image) {
    return "uploads/" + image;
});

        const mainImage =
            document.getElementById("vehicleMainImage");

        const thumbnails =
            document.getElementById("vehicleThumbnails");

        const counter =
            document.getElementById("vehicleImageCounter");

        const prev =
            document.getElementById("vehicleGalleryPrev");

        const next =
            document.getElementById("vehicleGalleryNext");


        thumbnails.innerHTML = "";

        let currentIndex = 0;


        if (images.length === 0) {

            mainImage.style.display = "none";

            counter.style.display = "none";

            prev.style.display = "none";

            next.style.display = "none";

            return;
        }


        mainImage.style.display = "block";

        counter.style.display = "block";


        function changeImage(index) {

            currentIndex = index;

            mainImage.src = images[index];

            mainImage.alt =
                vehicle.name + " image " + (index + 1);

            counter.textContent =
                (index + 1) + " / " + images.length;


            document
                .querySelectorAll(".vehicle-thumbnail")
                .forEach(function (thumb, i) {

                    thumb.classList.toggle(
                        "active",
                        i === index
                    );

                });

        }


        /*
        CREATE THUMBNAILS
        */

        images.forEach(function (image, index) {

            const thumb = document.createElement("button");

            thumb.type = "button";

            thumb.className = "vehicle-thumbnail";

            thumb.innerHTML = `
                <img
                    src="${image}"
                    alt="${vehicle.name} image ${index + 1}"
                >
            `;

            thumb.addEventListener("click", function (event) {

                event.stopPropagation();

                changeImage(index);

            });

            thumbnails.appendChild(thumb);

        });


        /*
        PREVIOUS
        */

        prev.onclick = function (event) {

            event.stopPropagation();

            let index = currentIndex - 1;

            if (index < 0) {
                index = images.length - 1;
            }

            changeImage(index);

        };


        /*
        NEXT
        */

        next.onclick = function (event) {

            event.stopPropagation();

            let index = currentIndex + 1;

            if (index >= images.length) {
                index = 0;
            }

            changeImage(index);

        };


        /*
        SHOW / HIDE ARROWS
        */

        if (images.length > 1) {

            prev.style.display = "flex";
            next.style.display = "flex";

        } else {

            prev.style.display = "none";
            next.style.display = "none";

        }


        /*
        FIRST IMAGE
        */

        changeImage(0);

    }


    /*
    ==========================================
    CLOSE MODAL
    ==========================================
    */

    function closeModal() {

        modal.classList.remove("active");

        modal.setAttribute("aria-hidden", "true");

        document.body.classList.remove("vehicle-modal-open");

    }


    closeBtn.addEventListener(
        "click",
        closeModal
    );


    overlay.addEventListener(
        "click",
        closeModal
    );


    /*
    ESC KEY
    */

    document.addEventListener("keydown", function (e) {

        if (
            e.key === "Escape" &&
            modal.classList.contains("active")
        ) {

            closeModal();

        }

    });

});
</script>

  <?php
include('footer.php');
?>