(function () {
  "use strict";

  const STORAGE_KEY = "arb-inventory-reviews";

  const vehicles = [
    {
      id: "corolla",
      name: "Toyota Corolla",
      brand: "Toyota",
      tag: "Most popular",
      category: "Sedan",
      year: 2023,
      transmission: "Automatic",
      fuel: "Petrol",
      mileage: "18,400 km",
      price: 4250000,
      priceLabel: "PKR 4,250,000",
      image: "https://images.unsplash.com/photo-1544636331-e26879cd4d9b?auto=format&fit=crop&w=900&q=80",
      color: "Super White",
      engine: "1.8L Petrol",
      seats: 5,
      condition: "Excellent",
      location: "Karachi Showroom",
      description: "Smooth daily driver with excellent fuel economy, clean interior, and full service history. Ideal for city and highway use.",
      features: ["Push Start", "Reverse Camera", "Cruise Control", "ABS + Airbags", "Alloy Wheels"],
      reviews: [
        { name: "Ahmed R.", rating: 5, text: "Drives exactly as described. Very happy with the Corolla.", date: "2026-01-12" },
        { name: "Sana K.", rating: 5, text: "Clean car, honest pricing, quick handover.", date: "2026-02-03" }
      ]
    },
    {
      id: "civic",
      name: "Honda Civic",
      brand: "Honda",
      tag: "City drive",
      category: "Sedan",
      year: 2022,
      transmission: "Automatic",
      fuel: "Hybrid",
      mileage: "21,800 km",
      price: 5100000,
      priceLabel: "PKR 5,100,000",
      image: "https://images.unsplash.com/photo-1553440569-bcc63803a83d?auto=format&fit=crop&w=900&q=80",
      color: "Modern Steel",
      engine: "1.5L Hybrid",
      seats: 5,
      condition: "Excellent",
      location: "Karachi Showroom",
      description: "Premium feel, strong hybrid efficiency, and a comfortable ride for long commutes.",
      features: ["Lane Assist", "Sunroof", "LED Headlights", "Smart Entry", "Hybrid Battery Checked"],
      reviews: [
        { name: "Hina M.", rating: 5, text: "Hybrid mileage is amazing. Team was very helpful.", date: "2026-01-20" }
      ]
    },
    {
      id: "swift",
      name: "Suzuki Swift",
      brand: "Suzuki",
      tag: "Value choice",
      category: "Hatchback",
      year: 2021,
      transmission: "Manual",
      fuel: "Petrol",
      mileage: "16,300 km",
      price: 3680000,
      priceLabel: "PKR 3,680,000",
      image: "https://images.unsplash.com/photo-1494905998402-395d579af36f?auto=format&fit=crop&w=900&q=80",
      color: "Pearl Red",
      engine: "1.2L Petrol",
      seats: 5,
      condition: "Very Good",
      location: "Karachi Showroom",
      description: "Compact, easy to park, and perfect for first-time buyers or city-only driving.",
      features: ["Fuel Efficient", "Touchscreen", "Power Windows", "Central Locking", "Low Running Cost"],
      reviews: [
        { name: "Usman A.", rating: 4, text: "Great value car for daily office commute.", date: "2025-12-08" }
      ]
    },
    {
      id: "fortuner",
      name: "Toyota Fortuner",
      brand: "Toyota",
      tag: "Family SUV",
      category: "SUV",
      year: 2022,
      transmission: "Automatic",
      fuel: "Diesel",
      mileage: "32,500 km",
      price: 9850000,
      priceLabel: "PKR 9,850,000",
      image: "https://images.unsplash.com/photo-1519641471654-76cead7a3415?auto=format&fit=crop&w=900&q=80",
      color: "Attitude Black",
      engine: "2.8L Diesel",
      seats: 7,
      condition: "Excellent",
      location: "Karachi Showroom",
      description: "Spacious 7-seater with strong road presence, ideal for family trips and long drives.",
      features: ["4x4 Capability", "Leather Interior", "Rear AC Vents", "Roof Rails", "Premium Sound"],
      reviews: [
        { name: "Bilal H.", rating: 5, text: "Perfect family SUV. Inspection report was detailed.", date: "2026-02-15" }
      ]
    },
    {
      id: "vezel",
      name: "Honda Vezel",
      brand: "Honda",
      tag: "Hybrid pick",
      category: "Hybrid",
      year: 2021,
      transmission: "Automatic",
      fuel: "Hybrid",
      mileage: "24,100 km",
      price: 6450000,
      priceLabel: "PKR 6,450,000",
      image: "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?auto=format&fit=crop&w=900&q=80",
      color: "Premium Silver",
      engine: "1.5L Hybrid",
      seats: 5,
      condition: "Excellent",
      location: "Karachi Showroom",
      description: "Stylish crossover hybrid with great visibility, comfort, and low fuel bills.",
      features: ["Hybrid System", "Panoramic Feel Cabin", "Auto AC", "Keyless Entry", "Parking Sensors"],
      reviews: [
        { name: "Maria S.", rating: 5, text: "Looks premium and runs quietly. Loved the test drive.", date: "2026-01-28" }
      ]
    },
    {
      id: "yaris",
      name: "Toyota Yaris",
      brand: "Toyota",
      tag: "Budget friendly",
      category: "Sedan",
      year: 2020,
      transmission: "Automatic",
      fuel: "Petrol",
      mileage: "28,700 km",
      price: 3290000,
      priceLabel: "PKR 3,290,000",
      image: "https://images.unsplash.com/photo-1618843479313-40f8afb4b4d8?auto=format&fit=crop&w=900&q=80",
      color: "Silver Metallic",
      engine: "1.3L Petrol",
      seats: 5,
      condition: "Very Good",
      location: "Karachi Showroom",
      description: "Reliable Toyota sedan at an accessible price point with low maintenance costs.",
      features: ["Economical Engine", "Reliable Transmission", "Clean Interior", "Fresh Service Done", "Ready to Drive"],
      reviews: [
        { name: "Faisal K.", rating: 4, text: "Good first car option within budget.", date: "2025-11-19" }
      ]
    }
  ];

  const grid = document.getElementById("inventory-grid");
  const emptyState = document.getElementById("inventory-empty");
  const searchInput = document.getElementById("inventory-search");
  const sortSelect = document.getElementById("inventory-sort");
  const filterBar = document.querySelector(".auto-filter-bar");
  const modalEl = document.getElementById("carDetailModal");

  if (!grid || !modalEl) return;

  let activeFilter = "All";
  let activeVehicleId = null;
  const modal = new bootstrap.Modal(modalEl);

  function getStoredReviews() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY) || "{}");
    } catch (e) {
      return {};
    }
  }

  function saveStoredReviews(data) {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  }

  function getAllReviews(vehicle) {
    const stored = getStoredReviews()[vehicle.id] || [];
    return [...vehicle.reviews, ...stored];
  }

  function averageRating(reviews) {
    if (!reviews.length) return 0;
    const sum = reviews.reduce((acc, r) => acc + r.rating, 0);
    return (sum / reviews.length).toFixed(1);
  }

  function renderStars(rating) {
    let html = "";
    for (let i = 1; i <= 5; i++) {
      html += `<i class="bi ${i <= rating ? "bi-star-fill" : "bi-star"}"></i>`;
    }
    return html;
  }

  function matchesFilter(vehicle) {
    if (activeFilter === "All") return true;
    if (activeFilter === "Hybrid") return vehicle.fuel === "Hybrid" || vehicle.category === "Hybrid";
    if (activeFilter === "SUV") return vehicle.category === "SUV";
    return vehicle.brand === activeFilter;
  }

  function matchesSearch(vehicle, query) {
    if (!query) return true;
    const haystack = [
      vehicle.name,
      vehicle.brand,
      vehicle.tag,
      vehicle.category,
      vehicle.fuel,
      vehicle.transmission,
      vehicle.year,
      vehicle.priceLabel,
      vehicle.color,
      vehicle.engine
    ].join(" ").toLowerCase();
    return haystack.includes(query.toLowerCase());
  }

  function getFilteredVehicles() {
    const query = searchInput ? searchInput.value.trim() : "";
    let list = vehicles.filter((v) => matchesFilter(v) && matchesSearch(v, query));

    if (sortSelect) {
      if (sortSelect.value === "price-asc") list.sort((a, b) => a.price - b.price);
      if (sortSelect.value === "price-desc") list.sort((a, b) => b.price - a.price);
      if (sortSelect.value === "year-desc") list.sort((a, b) => b.year - a.year);
      if (sortSelect.value === "name-asc") list.sort((a, b) => a.name.localeCompare(b.name));
    }

    return list;
  }

  function renderCards() {
    const list = getFilteredVehicles();
    grid.innerHTML = "";

    list.forEach((vehicle, index) => {
      const reviews = getAllReviews(vehicle);
      const avg = averageRating(reviews);
      const col = document.createElement("div");
      col.className = "col-lg-4 col-md-6";
      col.setAttribute("data-aos", "fade-up");
      col.setAttribute("data-aos-delay", String(100 + index * 50));

      col.innerHTML = `
        <article class="auto-vehicle-card inventory-clickable" data-car-id="${vehicle.id}" role="button" tabindex="0">
          <div class="auto-vehicle-image">
            <img src="${vehicle.image}" alt="${vehicle.name}">
          </div>
          <div class="auto-vehicle-body">
            <span class="auto-tag">${vehicle.tag}</span>
            <h3>${vehicle.name}</h3>
            <p>${vehicle.year} &middot; ${vehicle.transmission} &middot; ${vehicle.fuel} &middot; ${vehicle.mileage}</p>
            <div class="inventory-card-rating">${renderStars(Math.round(avg))} <span>${avg} (${reviews.length} reviews)</span></div>
            <strong>${vehicle.priceLabel}</strong>
            <button type="button" class="inventory-view-btn">View details <i class="bi bi-arrow-right"></i></button>
          </div>
        </article>
      `;

      grid.appendChild(col);
    });

    if (emptyState) {
      emptyState.hidden = list.length > 0;
    }

    if (typeof AOS !== "undefined") AOS.refreshHard();
  }

  function renderModalReviews(vehicle) {
    const listEl = document.getElementById("modal-reviews-list");
    const reviews = getAllReviews(vehicle);
    const avgEl = document.getElementById("modal-avg-rating");

    if (avgEl) {
      const avg = averageRating(reviews);
      avgEl.innerHTML = `${renderStars(Math.round(avg))} <strong>${avg}</strong> <span>(${reviews.length} reviews)</span>`;
    }

    if (!listEl) return;

    if (!reviews.length) {
      listEl.innerHTML = `<p class="inventory-no-reviews">No reviews yet. Be the first to share your experience.</p>`;
      return;
    }

    listEl.innerHTML = reviews.slice().reverse().map((review) => `
      <div class="inventory-review-item">
        <div class="inventory-review-top">
          <strong>${review.name}</strong>
          <span class="inventory-review-stars">${renderStars(review.rating)}</span>
        </div>
        <p>${review.text}</p>
        <small>${review.date || "Recently"}</small>
      </div>
    `).join("");
  }

  function openModal(vehicleId) {
    const vehicle = vehicles.find((v) => v.id === vehicleId);
    if (!vehicle) return;

    activeVehicleId = vehicleId;
    document.getElementById("modal-car-image").src = vehicle.image;
    document.getElementById("modal-car-image").alt = vehicle.name;
    document.getElementById("modal-car-title").textContent = vehicle.name;
    document.getElementById("modal-car-tag").textContent = vehicle.tag;
    document.getElementById("modal-car-price").textContent = vehicle.priceLabel;
    document.getElementById("modal-car-desc").textContent = vehicle.description;

    document.getElementById("modal-spec-year").textContent = vehicle.year;
    document.getElementById("modal-spec-mileage").textContent = vehicle.mileage;
    document.getElementById("modal-spec-transmission").textContent = vehicle.transmission;
    document.getElementById("modal-spec-fuel").textContent = vehicle.fuel;
    document.getElementById("modal-spec-engine").textContent = vehicle.engine;
    document.getElementById("modal-spec-color").textContent = vehicle.color;
    document.getElementById("modal-spec-seats").textContent = vehicle.seats;
    document.getElementById("modal-spec-condition").textContent = vehicle.condition;
    document.getElementById("modal-spec-location").textContent = vehicle.location;

    document.getElementById("modal-features").innerHTML = vehicle.features.map((f) => `<li><i class="bi bi-check-circle-fill"></i>${f}</li>`).join("");

    const form = document.getElementById("review-form");
    if (form) form.reset();

    renderModalReviews(vehicle);
    modal.show();
  }

  grid.addEventListener("click", function (e) {
    const card = e.target.closest("[data-car-id]");
    if (card) openModal(card.getAttribute("data-car-id"));
  });

  grid.addEventListener("keydown", function (e) {
    if (e.key === "Enter" || e.key === " ") {
      const card = e.target.closest("[data-car-id]");
      if (card) {
        e.preventDefault();
        openModal(card.getAttribute("data-car-id"));
      }
    }
  });

  if (searchInput) {
    searchInput.addEventListener("input", renderCards);
  }

  if (sortSelect) {
    sortSelect.addEventListener("change", renderCards);
  }

  if (filterBar) {
    filterBar.querySelectorAll("button").forEach(function (button) {
      button.addEventListener("click", function () {
        filterBar.querySelectorAll("button").forEach((btn) => btn.classList.remove("active"));
        button.classList.add("active");
        activeFilter = button.textContent.trim();
        renderCards();
      });
    });
  }

  const reviewForm = document.getElementById("review-form");
  if (reviewForm) {
    reviewForm.addEventListener("submit", function (e) {
      e.preventDefault();
      if (!activeVehicleId) return;

      const name = document.getElementById("review-name").value.trim();
      const rating = parseInt(document.getElementById("review-rating").value, 10);
      const text = document.getElementById("review-text").value.trim();

      if (!name || !text || !rating) return;

      const stored = getStoredReviews();
      if (!stored[activeVehicleId]) stored[activeVehicleId] = [];

      stored[activeVehicleId].push({
        name: name,
        rating: rating,
        text: text,
        date: new Date().toISOString().slice(0, 10)
      });

      saveStoredReviews(stored);

      const vehicle = vehicles.find((v) => v.id === activeVehicleId);
      renderModalReviews(vehicle);
      renderCards();
      reviewForm.reset();

      const toast = document.getElementById("review-success");
      if (toast) {
        toast.hidden = false;
        setTimeout(() => { toast.hidden = true; }, 2500);
      }
    });
  }

  renderCards();
})();
