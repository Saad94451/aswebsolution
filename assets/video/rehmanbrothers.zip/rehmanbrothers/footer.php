  <a class="whatsapp-float" href="https://wa.me/817027963926" target="_blank" rel="noopener noreferrer" aria-label="Chat with Rehman Brothers on WhatsApp">
      <i class="bi bi-whatsapp" aria-hidden="true"></i>
   
    </a>

    <footer id="footer" class="footer-16 footer position-relative">

    <div class="container">

      <div class="footer-main" data-aos="fade-up" data-aos-delay="100">
        <div class="row align-items-start">

          <div class="col-lg-5">
            <div class="brand-section">
              <a href="index.html" class="logo d-flex align-items-center mb-4">
                <img src="./assets/img/logoremove.png" alt="Rehman Brothers logo">
              </a>
              <p class="brand-description">Your trusted gateway to quality Japanese vehicles, transparent export support, and dependable delivery worldwide.</p>

              <div class="contact-info">
              
                <div class="contact-item">
                  <i class="bi bi-telephone"></i>
                  <a href="tel:+817027963926">+81 70-2796-3926</a>
                </div>
                <div class="contact-item">
                  <i class="bi bi-envelope"></i>
                  <a href="mailto:rehmanbrothers.info@gmail.com">rehmanbrothers.info@gmail.com</a>
                </div>
              </div>
            </div>
          </div>

          <div class="col-lg-7">
            <div class="footer-nav-wrapper">
              <div class="row">

                <div class="col-6 col-lg-3">
                  <div class="nav-column">
                    <h6>Company</h6>
                    <nav class="footer-nav">
                      <a href="#about">About Us</a>
                      <a href="#inventory">Inventory</a>
                      <a href="#services">Services</a>
                      <a href="#why-us">Why Us</a>
                      <a href="#contact">Contact</a>
                    </nav>
                  </div>
                </div>

                <div class="col-6 col-lg-3">
                  <div class="nav-column">
                    <h6>Models</h6>
                    <nav class="footer-nav">
                      <a href="#inventory">Toyota</a>
                      <a href="#inventory">Honda</a>
                      <a href="#inventory">Suzuki</a>
                      <a href="#inventory">Hybrid</a>
                      <a href="#inventory">SUV</a>
                    </nav>
                  </div>
                </div>

                <div class="col-6 col-lg-3">
                  <div class="nav-column">
                    <h6>Support</h6>
                    <nav class="footer-nav">
                      <a href="#contact">Book Test Drive</a>
                      <a href="#contact">Financing</a>
                      <a href="#contact">Vehicle Check</a>
                      <a href="#contact">Service Support</a>
                      <a href="#contact">FAQs</a>
                    </nav>
                  </div>
                </div>

                <div class="col-6 col-lg-3">
                  <div class="nav-column">
                    <h6>Connect</h6>
                    <nav class="footer-nav">
                      <a href="https://www.facebook.com/profile.php?id=61594269141009" target="_blank" rel="noopener noreferrer">Facebook</a>
                      <a href="https://www.instagram.com/rehmanbrothers.info/" target="_blank" rel="noopener noreferrer">Instagram</a>
                      <a href="https://www.linkedin.com/in/rehman-brothers-ba7822433" target="_blank" rel="noopener noreferrer">LinkedIn</a>
                      <a href="https://wa.me/817027963926" target="_blank" rel="noopener noreferrer">WhatsApp</a>
                      <a href="tel:+817027963926">Call Now</a>
                    </nav>
                  </div>
                </div>

              </div>
            </div>
          </div>

        </div>
      </div>

    </div>

    <div class="footer-bottom">
      <div class="container">
        <div class="bottom-content">
          <div class="row align-items-center">

            <div class="col-lg-6">
              <div class="copyright">
                <p>Copyright &copy; 2026 <span class="sitename">Rehman Brothers</span>. All rights reserved.</p>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="legal-links">
                <a href="#!">Privacy Policy</a>
                <a href="#!">Terms of Service</a>
                <a href="#!">Cookie Policy</a>
              </div>
            </div>

          </div>
        </div>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#!" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="./assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <!-- <script src="./assets/vendor/php-email-form/validate.js"></script> -->
  <script src="./assets/vendor/aos/aos.js"></script>
  <script src="./assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="./assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="./assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Main JS File -->
  <script src="./assets/js/main.js"></script>

</body>

</html>
