﻿<?php
include('header.php');
?>

  <main class="main auto-page-main">
    <section class="auto-page-hero">
      <div class="container" data-aos="fade-up">
        <span class="auto-eyebrow">Our story</span>
        <h1>About Rehman Brothers</h1>
        <p>A trusted Japanese car exporter sourcing quality vehicles directly from Japan's top auctions. 
We deliver to Caribbean, Africa, Middle East and worldwide — with transparent pricing, 
reliable shipping, and complete export documentation.</p>
      </div>
    </section>

    <section class="auto-about-page section">
      <div class="container">
        <div class="row align-items-center g-5">
          <div class="col-lg-6" data-aos="fade-right">
            <span class="auto-eyebrow">Who we are</span>
            <h2>Quality Cars. Clear Process. Worldwide Delivery.</h2>
            <p class="auto-about-lead">Rehman Brothers is your trusted gateway to quality Japanese cars, sourced directly from Japan and prepared for customers around the world.</p>
            <p>From auction bidding to port shipping, we keep the entire process transparent and simple. Our team helps you choose the right vehicle, inspects every car carefully, and provides honest guidance before you make a decision.</p>
            <p>We also handle the essential documentation, export arrangements, and shipping coordination, so you always know what is happening at each stage. Whether it is your first import or your tenth, our goal is to make buying from Japan clear, dependable, and stress-free.</p>
            <div class="auto-about-stats">
              <div><strong>18+</strong><span>Years experience</span></div>
              <div><strong>1,200+</strong><span>Cars delivered</span></div>
              <div><strong>96%</strong><span>Happy repeat buyers</span></div>
            </div>
            <a class="auto-primary-btn" href="inventory.html">Explore inventory <i class="bi bi-arrow-up-right"></i></a>
          </div>
          <div class="col-lg-6" data-aos="fade-left">
            <div class="auto-about-gallery">
              <figure class="auto-about-gallery-main">
                <img src="assets/img/office/WhatsApp Image 2026-09-03 at 2.02.54 PM.jpeg" alt="Japanese vehicles in the Rehman Brothers yard">
              </figure>
              <figure>
                <img src="assets/img/office/WhatsApp Image 2026-09-03 at 2.02.55 PM.jpeg" alt="Japanese vehicles ready for inspection">
              </figure>
              <figure>
                <img src="assets/img/office/WhatsApp Image 2026-09-03 at 2.02.56 PM.jpeg" alt="Vehicle inspection area at Rehman Brothers">
              </figure>
            
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section pt-0">
      <div class="container" data-aos="fade-up">
        <div class="row g-4">
          <div class="col-lg-6">
            <div class="auto-feature-panel h-100">
              <span class="auto-eyebrow" style="color:#77a9ff;">Our mission</span>
              <h2>Trusted support from auction to port</h2>
              <p>We believe every importer deserves a vehicle they can trust, without hidden fees, confusing paperwork, or unnecessary delays. That is why Rehman Brothers is built around transparent communication, quality inspections, and practical guidance at every stage.</p>
              <p>From selecting the right car and bidding at Japan&apos;s leading auctions to arranging export documents and shipping, our team stays with you until your vehicle reaches its destination port.</p>
            </div>
          </div>
          <div class="col-lg-6">
            <div class="auto-value-card h-100" style="background:#f8fbff;">
              <i class="bi bi-eye"></i>
              <h4>Our vision</h4>
              <p>To be the global bridge between Japan&apos;s best car auctions and customers around the world, making quality Japanese vehicles easier to access wherever you are.</p>
              <p class="mb-0">We deliver more than vehicles. With every export, we deliver trust, clarity, and peace of mind through honest service, careful coordination, and support you can rely on.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section about-journey-section">
      <div class="container" data-aos="fade-up">
        <div class="text-center mb-5">
          <span class="auto-eyebrow">How we grew</span>
          <h2 class="mt-2" style="font-weight:700;">Our journey so far</h2>
          <p class="mx-auto" style="max-width:640px;color:color-mix(in srgb,var(--default-color),transparent 25%);">From a small family operation to a trusted showroom â€” built one satisfied customer at a time.</p>
        </div>
        <div class="auto-process-grid">
          <div class="auto-process-step">
            <span>2008</span>
            <h4>Where it started</h4>
            <p>Rehman Brothers began as a small family venture with a simple idea â€” bring reliable Japanese cars to local buyers at fair prices.</p>
          </div>
          <div class="auto-process-step">
            <span>2014</span>
            <h4>Building trust</h4>
            <p>Word spread quickly. Repeat customers and referrals became our biggest source of growth â€” proof that honesty works.</p>
          </div>
          <div class="auto-process-step">
            <span>2019</span>
            <h4>Expanding inventory</h4>
            <p>We expanded our stock to include hybrids, SUVs, and premium imports â€” always with the same strict inspection standards.</p>
          </div>
          <div class="auto-process-step">
            <span>Today</span>
            <h4>1,200+ cars delivered</h4>
            <p>Today we serve drivers across Karachi and beyond â€” with a full showroom, after-sales support, and a team that treats every buyer like family.</p>
          </div>
        </div>
      </div>
    </section>

    <section class="section pt-0">
      <div class="container" data-aos="fade-up">
        <div class="row align-items-center g-5">
          <div class="col-lg-6 order-lg-2">
            <span class="auto-eyebrow">Inside our showroom</span>
            <h2 style="font-weight:700;">More than a dealership â€” a place you can trust</h2>
            <p class="auto-about-lead">Walk into our showroom and you will find a team that listens first and sells second.</p>
            <p>We know buying a car is a big decision. That is why we take time to understand your daily routine, your budget, and what matters most to you â€” fuel economy, family space, resale value, or simply a smooth city drive.</p>
            <p>Every vehicle on our floor has been personally reviewed. We check the engine, body, interior, electronics, and service history before it goes up for sale. If we would not drive it ourselves, we will not offer it to you.</p>
            <ul class="about-promise-list">
              <li><i class="bi bi-check-circle-fill"></i> No accident-hidden vehicles</li>
              <li><i class="bi bi-check-circle-fill"></i> Clear, upfront pricing</li>
              <li><i class="bi bi-check-circle-fill"></i> Test drives welcome anytime</li>
              <li><i class="bi bi-check-circle-fill"></i> Documentation handled properly</li>
              <li><i class="bi bi-check-circle-fill"></i> After-sales support that stays</li>
            </ul>
          </div>
          <div class="col-lg-6 order-lg-1">
            <div class="row g-3">
              <div class="col-6">
                <div class="auto-about-image about-image-sm">
                  <img src="assets/img/office/WhatsApp Image 2026-09-03 at 2.02.51 PM.jpeg" alt="Showroom interior">
                </div>
              </div>
              <div class="col-6">
                <div class="auto-about-image about-image-sm" style="margin-top:28px;">
                  <img src="assets/img/office/WhatsApp Image 2026-09-03 at 2.02.52 PM.jpeg" alt="Vehicle display area">
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section about-brands-section">
      <div class="container" data-aos="fade-up">
        <div class="text-center mb-5">
          <span class="auto-eyebrow">Brands we work with</span>
          <h2 class="mt-2" style="font-weight:700;">Japanese quality you already trust</h2>
          <p class="mx-auto" style="max-width:620px;color:color-mix(in srgb,var(--default-color),transparent 25%);">We focus on brands and models known for reliability on local roads.</p>
        </div>
        <div class="row g-4">
          <div class="col-lg-3 col-md-6">
            <div class="auto-value-card text-center">
              <i class="bi bi-car-front-fill"></i>
              <h4>Toyota</h4>
              <p>Corolla, Yaris, Fortuner, and more â€” the gold standard for reliability and resale value.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="auto-value-card text-center">
              <i class="bi bi-lightning-charge-fill"></i>
              <h4>Honda</h4>
              <p>Civic, City, Vezel â€” stylish, efficient, and perfect for city and highway driving.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="auto-value-card text-center">
              <i class="bi bi-fuel-pump-fill"></i>
              <h4>Suzuki</h4>
              <p>Swift, Wagon R, Alto â€” smart choices for budget-conscious buyers and daily commutes.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="auto-value-card text-center">
              <i class="bi bi-globe-asia-australia"></i>
              <h4>Premium Imports</h4>
              <p>Selected hybrid and SUV imports sourced carefully from Japan with full inspection.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="section pt-0">
      <div class="container" data-aos="fade-up">
        <div class="text-center mb-5">
          <span class="auto-eyebrow">What drives us</span>
          <h2 class="mt-2" style="font-weight:700;">Our core values</h2>
          <p class="mx-auto" style="max-width:620px;color:color-mix(in srgb,var(--default-color),transparent 25%);">These principles guide every conversation, every inspection, and every handover.</p>
        </div>
        <div class="row g-4">
          <div class="col-lg-3 col-md-6">
            <div class="auto-value-card">
              <i class="bi bi-heart"></i>
              <h4>Honesty First</h4>
              <p>We tell you what a car is â€” and what it is not. No hidden issues, no inflated promises.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="auto-value-card">
              <i class="bi bi-shield-check"></i>
              <h4>Quality Assured</h4>
              <p>Every vehicle goes through a proper check before it earns a place in our inventory.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="auto-value-card">
              <i class="bi bi-people"></i>
              <h4>Customer Focus</h4>
              <p>Your budget, your lifestyle, your timeline â€” we work around what matters to you.</p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6">
            <div class="auto-value-card">
              <i class="bi bi-hand-thumbs-up"></i>
              <h4>Long-Term Trust</h4>
              <p>We stay available after the sale because a good dealer does not disappear at handover.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="customer-stories section">
      <div class="container section-title" data-aos="fade-up">
        <span class="section-kicker">Customer stories</span>
        <h2>Trusted by drivers across the region</h2>
        <p>Our best measure of success is the confidence customers carry home.</p>
      </div>
      <div class="container">
        <div class="row g-4">
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="100">
            <article class="testimonial-card">
              <div class="testimonial-stars">â˜…â˜…â˜…â˜…â˜…</div>
              <p>&ldquo;A smooth buying experience from the first call to the final handover. Everything was transparent.&rdquo;</p>
              <div class="testimonial-author"><strong>Bilal M.</strong><span>Verified customer</span></div>
            </article>
          </div>
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="150">
            <article class="testimonial-card featured">
              <div class="testimonial-stars">â˜…â˜…â˜…â˜…â˜…</div>
              <p>&ldquo;The advice was practical and the vehicle inspection gave me complete peace of mind.&rdquo;</p>
              <div class="testimonial-author"><strong>Sana F.</strong><span>Verified customer</span></div>
            </article>
          </div>
          <div class="col-lg-4" data-aos="fade-up" data-aos-delay="200">
            <article class="testimonial-card">
              <div class="testimonial-stars">â˜…â˜…â˜…â˜…â˜…</div>
              <p>&ldquo;Professional people, quality cars, and support that continues even after delivery.&rdquo;</p>
              <div class="testimonial-author"><strong>Hamza T.</strong><span>Verified customer</span></div>
            </article>
          </div>
        </div>
      </div>
    </section>

    <section class="section pt-0 pb-5">
      <div class="container" data-aos="fade-up">
        <div class="auto-cta-strip d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-4">
          <div>
            <span class="auto-eyebrow" style="color:#77a9ff;">Find your right car</span>
            <h2>Want a car that fits your needs?</h2>
            <p>Contact us and our team will help you find the right car with honest guidance and clear answers.</p>
          </div>
          <a class="auto-primary-btn" href="contact.html">Contact us <i class="bi bi-arrow-up-right"></i></a>
        </div>
      </div>
    </section>
  </main>

 <?php
include('footer.php');
?>