<?php

require_once('config.php');

/*
|--------------------------------------------------------------------------
| Contact Form Processing
|--------------------------------------------------------------------------
*/

$formStatus = '';
$formMessage = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['contact_submit'])) {

    // Get form values
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $interest = trim($_POST['interest'] ?? '');
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');


    /*
    |--------------------------------------------------------------------------
    | Validation
    |--------------------------------------------------------------------------
    */

    if (
        $name === '' ||
        $email === '' ||
        $interest === '' ||
        $subject === '' ||
        $message === ''
    ) {

        $formStatus = 'error';
        $formMessage = 'Please fill in all required fields.';

    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

        $formStatus = 'error';
        $formMessage = 'Please enter a valid email address.';

    } else {

        /*
        |--------------------------------------------------------------------------
        | Insert into contacts table
        |--------------------------------------------------------------------------
        */

        $sql = "INSERT INTO contacts
                (name, email, phone, interest, subject, message)
                VALUES (?, ?, ?, ?, ?, ?)";

        $stmt = mysqli_prepare($conn, $sql);

        if ($stmt) {

            mysqli_stmt_bind_param(
                $stmt,
                "ssssss",
                $name,
                $email,
                $phone,
                $interest,
                $subject,
                $message
            );

            if (mysqli_stmt_execute($stmt)) {

                $formStatus = 'success';
                $formMessage = 'Your enquiry has been sent successfully.';

            } else {

                $formStatus = 'error';
                $formMessage = 'Unable to send your enquiry. Please try again.';
            }

            mysqli_stmt_close($stmt);

        } else {

            $formStatus = 'error';
            $formMessage = 'Database error. Please try again.';
        }
    }
}

include('header.php');

?>

<main class="main auto-page-main">

    <!-- =====================================================
         HERO
    ====================================================== -->

    <section class="auto-page-hero">

        <div class="container" data-aos="fade-up">

            <span class="auto-eyebrow">
                Get in touch
            </span>

            <h1>
                Want a car that fits your needs?
            </h1>

            <p>
                Contact us and our team will help you find the right car
                with honest guidance and clear answers.
            </p>

            <div class="auto-trust-bar">

                <span>
                    <i class="bi bi-telephone"></i>
                    Same-day response
                </span>

                <span>
                    <i class="bi bi-chat-left-text"></i>
                    WhatsApp friendly
                </span>

                <span>
                    <i class="bi bi-geo-alt"></i>
                    24 hrs Support
                </span>

            </div>

        </div>

    </section>


    <!-- =====================================================
         CONTACT SECTION
    ====================================================== -->

    <section class="auto-contact-page section">

        <div class="container">

            <div class="row g-4 align-items-stretch">


                <!-- =================================================
                     LEFT CONTACT INFORMATION
                ================================================== -->

                <div class="col-lg-5" data-aos="fade-right">

                    <div class="auto-contact-panel">

                        <span
                            class="auto-eyebrow"
                            style="color:#77a9ff;"
                        >
                            Start a conversation
                        </span>

                        <h2>
                            We are here to help.
                        </h2>

                        <p>
                            Whether you have a vehicle in mind, need a
                            service quote, or just want honest advice —
                            reach out and we will respond with clear,
                            practical guidance.
                        </p>


                        <!-- Phone -->

                        <div class="auto-contact-detail">

                            <i class="bi bi-telephone"></i>

                            <div>

                                <small>
                                    Call us
                                </small>

                                <a href="tel:+817027963926">
                                    +81 70-2796-3926
                                </a>

                            </div>

                        </div>


                        <!-- Email -->

                        <div class="auto-contact-detail">

                            <i class="bi bi-envelope"></i>

                            <div>

                                <small>
                                    Email us
                                </small>

                                <a href="mailto:rehmanbrothers.info@gmail.com">
                                    rehmanbrothers.info@gmail.com
                                </a>

                            </div>

                        </div>


                        <!-- Location -->

                        <div class="auto-contact-detail">

                            <i class="bi bi-geo-alt"></i>

                            <div>

                                <small>
                                    Visit us
                                </small>

                                <span>
                                    Karachi, Pakistan
                                </span>

                            </div>

                        </div>


                        <!-- WhatsApp -->

                        <div class="auto-contact-detail">

                            <i class="bi bi-whatsapp"></i>

                            <div>

                                <small>
                                    WhatsApp
                                </small>

                                <a
                                    href="https://wa.me/817027963926"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    Message us anytime
                                </a>

                            </div>

                        </div>

                    </div>

                </div>


                <!-- =================================================
                     CONTACT FORM
                ================================================== -->

                <div class="col-lg-7" data-aos="fade-left">

                    <div class="auto-message-card">

                        <span class="auto-eyebrow">
                            Quick enquiry
                        </span>

                        <h2>
                            What can we help you with?
                        </h2>


                        <form
                            method="POST"
                            class="php-email-form"
                        >

                            <div class="row g-3">


                                <!-- Name -->

                                <div class="col-md-6">

                                    <input
                                        type="text"
                                        name="name"
                                        placeholder="Your name"
                                        value="<?= htmlspecialchars($_POST['name'] ?? '') ?>"
                                        required
                                    >

                                </div>


                                <!-- Email -->

                                <div class="col-md-6">

                                    <input
                                        type="email"
                                        name="email"
                                        placeholder="Your email"
                                        value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
                                        required
                                    >

                                </div>


                                <!-- Phone -->

                                <div class="col-md-6">

                                    <input
                                        type="tel"
                                        name="phone"
                                        placeholder="Phone number"
                                        value="<?= htmlspecialchars($_POST['phone'] ?? '') ?>"
                                    >

                                </div>


                                <!-- Interest -->

                                <div class="col-md-6">

                                    <select
                                        name="interest"
                                        style="
                                            width:100%;
                                            padding:14px 15px;
                                            border:1px solid color-mix(in srgb,var(--default-color),transparent 82%);
                                            border-radius:8px;
                                            outline:none;
                                        "
                                        required
                                    >

                                        <option value="">
                                            I am interested in...
                                        </option>

                                        <option
                                            value="Buying a car"
                                            <?= (($_POST['interest'] ?? '') === 'Buying a car') ? 'selected' : '' ?>
                                        >
                                            Buying a car
                                        </option>

                                        <option
                                            value="Vehicle inspection"
                                            <?= (($_POST['interest'] ?? '') === 'Vehicle inspection') ? 'selected' : '' ?>
                                        >
                                            Vehicle inspection
                                        </option>

                                        <option
                                            value="Maintenance / service"
                                            <?= (($_POST['interest'] ?? '') === 'Maintenance / service') ? 'selected' : '' ?>
                                        >
                                            Maintenance / service
                                        </option>

                                        <option
                                            value="Modifications"
                                            <?= (($_POST['interest'] ?? '') === 'Modifications') ? 'selected' : '' ?>
                                        >
                                            Modifications
                                        </option>

                                        <option
                                            value="General enquiry"
                                            <?= (($_POST['interest'] ?? '') === 'General enquiry') ? 'selected' : '' ?>
                                        >
                                            General enquiry
                                        </option>

                                    </select>

                                </div>


                                <!-- Subject -->

                                <div class="col-12">

                                    <input
                                        type="text"
                                        name="subject"
                                        placeholder="Preferred model or budget"
                                        value="<?= htmlspecialchars($_POST['subject'] ?? '') ?>"
                                        required
                                    >

                                </div>


                                <!-- Message -->

                                <div class="col-12">

                                    <textarea
                                        name="message"
                                        rows="5"
                                        placeholder="Tell us what you need — model, budget, timeline..."
                                        required
                                    ><?= htmlspecialchars($_POST['message'] ?? '') ?></textarea>

                                </div>


                                <!-- Submit -->

                                <div class="col-12">

                                    <button
                                        type="submit"
                                        name="contact_submit"
                                    >
                                        Send enquiry
                                        <i class="bi bi-arrow-up-right"></i>
                                    </button>

                                </div>

                            </div>

                        </form>

                    </div>

                </div>

            </div>


            <!-- =====================================================
                 EXTRA INFORMATION CARDS
            ====================================================== -->

            <div class="row g-4 mt-2">


                <!-- Showroom Hours -->

                <div
                    class="col-lg-4"
                    data-aos="fade-up"
                >

                    <div class="auto-hours-card">

                        <h4>
                            <i class="bi bi-clock me-2"></i>
                            Showroom Hours
                        </h4>


                        <div class="auto-hours-row">

                            <span>
                                Monday – Friday
                            </span>

                            <strong>
                                9:00 AM – 7:00 PM
                            </strong>

                        </div>


                        <div class="auto-hours-row">

                            <span>
                                Saturday
                            </span>

                            <strong>
                                10:00 AM – 6:00 PM
                            </strong>

                        </div>


                        <div class="auto-hours-row">

                            <span>
                                Sunday
                            </span>

                            <strong>
                                By appointment
                            </strong>

                        </div>

                    </div>

                </div>


                <!-- Test Drives -->

                <div
                    class="col-lg-4"
                    data-aos="fade-up"
                    data-aos-delay="100"
                >

                    <div class="auto-value-card">

                        <i class="bi bi-car-front"></i>

                        <h4>
                            Inquiries
                        </h4>

                        <p>
                           Our Team is alwasy available to answer  your inquiries realting to cars.
                           We always seek to have potential customers.
                        </p>

                    </div>

                </div>


                <!-- Financing -->

                <div
                    class="col-lg-4"
                    data-aos="fade-up"
                    data-aos-delay="200"
                >

                    <div class="auto-value-card">

                        <i class="bi bi-cash-coin"></i>

                        <h4>
                            Financing Help
                        </h4>

                        <p>
                            Need guidance on payment plans? Ask us —
                            we will explain your options clearly and honestly.
                        </p>

                    </div>

                </div>

            </div>


            <!-- =====================================================
                 GOOGLE MAP
            ====================================================== -->

            <div
                class="auto-map-wrap"
                data-aos="fade-up"
            >

                <iframe
                    src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3087.1535902864034!2d140.1330578!3d35.50786999999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x602299052287765d%3A0x8d44e03d9bbe9fa!2sRehman%20Brothers%20Co%20Ltd!5e1!3m2!1sen!2s!4v1788594004409!5m2!1sen!2s"
                    allowfullscreen
                    loading="lazy"
                    referrerpolicy="strict-origin-when-cross-origin"
                    title="Rehman Brothers Co Ltd location"
                ></iframe>

            </div>

        </div>

    </section>

</main>


<!-- =========================================================
     SWEETALERT2
========================================================== -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<?php if ($formStatus === 'success'): ?>

<script>

Swal.fire({

    icon: 'success',

    title: 'Message Sent!',

    text: 'Thank you for contacting us. Our team will get back to you shortly.',

    confirmButtonText: 'Done',

    confirmButtonColor: '#2563eb',

    background: '#ffffff',

    allowOutsideClick: true,

    allowEscapeKey: true

});

</script>

<?php elseif ($formStatus === 'error'): ?>

<script>

Swal.fire({

    icon: 'error',

    title: 'Something went wrong',

    text: <?= json_encode($formMessage) ?>,

    confirmButtonText: 'Try Again',

    confirmButtonColor: '#2563eb',

    background: '#ffffff',

    allowOutsideClick: true,

    allowEscapeKey: true

});

</script>

<?php endif; ?>


<?php

include('footer.php');

?>