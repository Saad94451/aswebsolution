﻿<?php
include('config.php');
include('header.php');

$hero_query = "SELECT * FROM hero_slides 
               WHERE status = 1 
               ORDER BY sort_order ASC, id ASC 
               LIMIT 3";

$hero_result = mysqli_query($conn, $hero_query);
?>

  <main class="main">

    <section id="hero" class="hero section">
      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row align-items-center">
          <div class="col-lg-6">
            <div class="hero-content">
              <div class="trust-badges mb-4" data-aos="fade-right" data-aos-delay="200">
                <div class="badge-item">
                  <i class="bi bi-award"></i>
                  <span>Quality Used Cars</span>
                </div>
                <div class="badge-item">
                  <i class="bi bi-shield-check"></i>
                  <span>Worldwide Shipping</span>
                </div>
                <div class="badge-item">
                  <i class="bi bi-star-fill"></i>
                  <span>Complete Export Support</span>
                </div>
              </div>

              <h1 data-aos="fade-right" data-aos-delay="300">
                Your Gateway to <span class="highlight">Japanese Cars</span>
              </h1>

              <p class="hero-description" data-aos="fade-right" data-aos-delay="400">
                Your trusted Japanese car exporter. Based in Japan, we export quality used cars worldwide, with a special focus on Caribbean countries. From sourcing and shipping to documentation, we handle everything for you and deliver to 50+ countries globally.
              </p>

              <div class="hero-stats mb-4" data-aos="fade-right" data-aos-delay="500">
                <div class="stat-item">
                  <h3><span data-purecounter-start="0" data-purecounter-end="18" data-purecounter-duration="2" class="purecounter"></span>+</h3>
                  <p>Years in Market</p>
                </div>
                <div class="stat-item">
                  <h3><span data-purecounter-start="0" data-purecounter-end="1200" data-purecounter-duration="2" class="purecounter"></span>+</h3>
                  <p>Cars Sold</p>
                </div>
                <div class="stat-item">
                  <h3><span data-purecounter-start="0" data-purecounter-end="96" data-purecounter-duration="2" class="purecounter"></span>%</h3>
                  <p>Repeat Buyers</p>
                </div>
              </div>

              <div class="hero-actions" data-aos="fade-right" data-aos-delay="600">
                <a href="#inventory" class="btn btn-primary">View Inventory</a>
                <a href="#contact" class="btn btn-outline">Contact Now</a>
              </div>

          
            </div>
          </div>

          <div class="col-lg-6">
            <div class="hero-visual" data-aos="fade-left" data-aos-delay="400">
              <div class="main-image">
                <div class="hero-image-slider swiper init-swiper">
                  <script type="application/json" class="swiper-config">
                    {
                      "loop": true,
                      "speed": 1200,
                      "effect": "fade",
                      "fadeEffect": {
                        "crossFade": true
                      },
                      "autoplay": {
                        "delay": 3500,
                        "disableOnInteraction": false
                      }
                    }
                  </script>
                 <div class="swiper-wrapper">

<?php if ($hero_result && mysqli_num_rows($hero_result) > 0): ?>

    <?php while ($hero = mysqli_fetch_assoc($hero_result)): ?>

        <div class="swiper-slide">

            <img
                src="uploads/<?= htmlspecialchars($hero['image']) ?>"
                alt="<?= htmlspecialchars($hero['alt_text'] ?: 'Japanese car') ?>"
                class="img-fluid"
            >

        </div>

    <?php endwhile; ?>

<?php else: ?>

    <!-- Fallback image agar database mein koi image nahi -->
    <div class="swiper-slide">
        <img
            src="assets/img/hero-default.jpg"
            alt="Japanese car dealership"
            class="img-fluid"
        >
    </div>

<?php endif; ?>

</div>

                <div class="floating-card rating-card">
                  <div class="card-content">
                    <div class="rating-stars">
                      <i class="bi bi-star-fill"></i>
                      <i class="bi bi-star-fill"></i>
                      <i class="bi bi-star-fill"></i>
                      <i class="bi bi-star-fill"></i>
                      <i class="bi bi-star-fill"></i>
                    </div>
                    <h6>5.0 Rated</h6>
                    <small>1,200+ Happy Drivers</small>
                  </div>
                </div>
              </div>
              <div class="background-elements">
                <div class="element element-1"></div>
                <div class="element element-2"></div>
                <div class="element element-3"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="about" class="home-about section">
      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row align-items-center">
          <div class="col-lg-6 mb-5 mb-lg-0" data-aos="fade-right" data-aos-delay="200">
            <div class="about-content">
              <h2 class="section-heading">Quality Japanese Cars, Honest Advice</h2>
              <p class="lead-text">For years, Rehman Brothers has helped drivers across Pakistan find dependable, stylish, and fuel-efficient Japanese vehicles that match their lifestyle and budget.</p>

              <p>We specialize in quality imported and locally sourced cars with transparent pricing, proper inspection, and reliable after-sales support. Whether you want a family sedan, a city hatchback, or a premium SUV, our team is here to guide you every step of the way.</p>

              <div class="stats-grid">
                <div class="stat-item">
                  <div class="stat-number purecounter" data-purecounter-start="0" data-purecounter-end="1200" data-purecounter-duration="1"></div>
                  <div class="stat-label">Cars Delivered</div>
                </div>
                <div class="stat-item">
                  <div class="stat-number purecounter" data-purecounter-start="0" data-purecounter-end="18" data-purecounter-duration="1"></div>
                  <div class="stat-label">Years Experience</div>
                </div>
                <div class="stat-item">
                  <div class="stat-number purecounter" data-purecounter-start="0" data-purecounter-end="15" data-purecounter-duration="1"></div>
                  <div class="stat-label">Popular Models</div>
                </div>
              </div>

              <div class="cta-section">
                <a href="#contact" class="btn-primary">Talk to Our Team</a>
              </div>
            </div>
          </div>

          <div class="col-lg-6" data-aos="fade-left" data-aos-delay="300">
            <div class="about-visual">
              <div class="main-image">
                <img src=".\assets\\img\office\\WhatsApp Image 2026-09-03 at 2.02.54 PM.jpeg" alt="Japanese car showroom" class="img-fluid" style="height: 30rem;width: 100rem;">
              </div>
              <div class="floating-card">
                <div class="card-content">
                  <div class="icon">
                    <i class="bi bi-check-circle"></i>
                  </div>
                  <div class="card-text">
                    <h4>Pre-checked Vehicles</h4>
                    <p>Every car inspected before sale</p>
                  </div>
                </div>
              </div>
              <div class="experience-badge">
                <div class="badge-content">
                  <span class="years">18+</span>
                  <span class="text">Trusted Auto Experts</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="inventory" class="featured-departments section dealership-inventory">
      <div class="container">
        
          <div class="container section-title" >
            <span class="eyebrow">Featured Inventory</span>
            <h2>Handpicked Japanese Cars</h2>
          </div>
          
        

        <div class="inventory-grid" data-aos="fade-up" data-aos-delay="100">
          <article class="inventory-card ">
            <div class="inventory-image">
              <img src="https://images.unsplash.com/photo-1544636331-e26879cd4d9b?auto=format&fit=crop&w=900&q=80" alt="Toyota Corolla car">
            </div>
            <div class="inventory-body">
              <div class="inventory-topline">
                <span class="inventory-badge">Most Popular</span>
                <span class="inventory-km">18,400 km</span>
              </div>
              <h3>Toyota Corolla</h3>
              <div class="inventory-meta">
                <span>2023</span>
                <span>Automatic</span>
                <span>Petrol</span>
              </div>
              <div class="inventory-price-row">
                <div>
                  <small>Starting from</small>
                  <strong>PKR 4,250,000</strong>
                </div>
                <a href="#contact">Details</a>
              </div>
            </div>
          </article>

          <article class="inventory-card">
            <div class="inventory-image">
              <img src="https://images.unsplash.com/photo-1553440569-bcc63803a83d?auto=format&fit=crop&w=900&q=80" alt="Honda Civic car">
            </div>
            <div class="inventory-body">
              <div class="inventory-topline">
                <span class="inventory-badge alt">City Drive</span>
                <span class="inventory-km">21,800 km</span>
              </div>
              <h3>Honda Civic</h3>
              <div class="inventory-meta">
                <span>2022</span>
                <span>Automatic</span>
                <span>Hybrid</span>
              </div>
              <div class="inventory-price-row">
                <div>
                  <small>Starting from</small>
                  <strong>PKR 5,100,000</strong>
                </div>
                <a href="#contact">Details</a>
              </div>
            </div>
          </article>

          <article class="inventory-card">
            <div class="inventory-image">
              <img src="https://images.unsplash.com/photo-1494905998402-395d579af36f?auto=format&fit=crop&w=900&q=80" alt="Suzuki Swift car">
            </div>
            <div class="inventory-body">
              <div class="inventory-topline">
                <span class="inventory-badge alt">Value Choice</span>
                <span class="inventory-km">16,300 km</span>
              </div>
              <h3>Suzuki Swift</h3>
              <div class="inventory-meta">
                <span>2021</span>
                <span>Manual</span>
                <span>Petrol</span>
              </div>
              <div class="inventory-price-row">
                <div>
                  <small>Starting from</small>
                  <strong>PKR 3,680,000</strong>
                </div>
                <a href="#contact">Details</a>
              </div>
            </div>
          </article>
        </div>
      </div>
    </section>

    <section id="services" class="featured-services section">
      <div class="container section-title" data-aos="fade-up">
        <h2>Export Services</h2>
        <p>Reliable support at every stage of your Japanese car export, from auction sourcing to delivery at your port.</p>
      </div>

      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row g-0">
          <div class="col-lg-8" data-aos="fade-right" data-aos-delay="200">
            <div class="featured-service-main">
              <div class="service-image-wrapper">
                <img src=".\assets\img\office\WhatsApp Image 2026-09-03 at 2.02.51 PM.jpeg" alt="Japanese car dealership" class="img-fluid" loading="lazy" style="height: 50rem !important; ">
                <div class="service-overlay">
                  <div class="service-badge">
                    <i class="bi bi-car-front"></i>
                    <span>Ready to Export</span>
                  </div>
                </div>
              </div>
              <div class="service-details">
                <h2>Complete Export Support, One Trusted Team</h2>
                <p>From finding the right vehicle in Japan auctions to shipping and documentation, our team keeps your export clear, organized, and supported at every step.</p>
                <a href="inventory.html" class="main-cta">View Inventory <i class="bi bi-arrow-up-right"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-4" data-aos="fade-left" data-aos-delay="300">
            <div class="services-sidebar">
              <div class="service-item" data-aos="fade-up" data-aos-delay="400">
                  <div class="service-icon-wrapper"><i class="bi bi-search"></i></div>
                <div class="service-info">
                  <h4>Auction Verified Vehicles</h4>
                  <p>Every car is sourced from Japan auctions and inspected for grade, mileage, and condition. We send you full reports, photos, and videos.</p>
                    <a href="inventory.html" class="service-link">View Inventory <i class="bi bi-arrow-up-right"></i></a>
                </div>
              </div>

              <div class="service-item" data-aos="fade-up" data-aos-delay="500">
                <div class="service-icon-wrapper"><i class="bi bi-truck-flatbed"></i></div>
                <div class="service-info">
                  <h4>FOB &amp; CIF Shipping</h4>
                  <p>Secure port-to-port shipping worldwide. We handle booking, insurance, and provide real-time updates until delivery.</p>
                  <a href="#contact" class="service-link">Get Shipping Quote <i class="bi bi-arrow-up-right"></i></a>
                </div>
              </div>

              <div class="service-item" data-aos="fade-up" data-aos-delay="600">
                <div class="service-icon-wrapper"><i class="bi bi-file-earmark-check"></i></div>
                <div class="service-info">
                  <h4>Export Documentation</h4>
                  <p>All export paperwork is handled by our team, including clear invoicing, certificates, and customs support for smooth delivery.</p>
                  <a href="#contact" class="service-link">Contact Us <i class="bi bi-arrow-up-right"></i></a>
                </div>
              </div>

         
            </div>
          </div>
        </div>
      </div>
    </section>

    <section id="why-us" class="why-choose-us section">
      <div class="container section-title" data-aos="fade-up">
        <span class="section-kicker">The Rehman Brothers difference</span>
        <h2>Why Choose Us</h2>
        <p>Confidence comes standard with every vehicle, every conversation, and every handover.</p>
      </div>

      <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row g-4">
          <div class="col-lg-3 col-md-6">
            <div class="department-highlight">
              <span class="highlight-number">01</span>
              <div class="highlight-icon"><i class="bi bi-shield-check"></i></div>
              <h4>Trusted Dealer</h4>
              <p>Honest guidance, dependable vehicles, and support that stays with you after delivery.</p>
              <span class="highlight-note">Built for long-term trust</span>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="department-highlight">
              <span class="highlight-number">02</span>
              <div class="highlight-icon"><i class="bi bi-receipt"></i></div>
              <h4>Transparent Pricing</h4>
              <p>Clear pricing and straightforward communication, with no hidden surprises.</p>
              <span class="highlight-note">Clear from day one</span>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="department-highlight">
              <span class="highlight-number">03</span>
              <div class="highlight-icon"><i class="bi bi-search"></i></div>
              <h4>Quality Inspection</h4>
              <p>Every vehicle is carefully checked for condition, performance, and road-readiness.</p>
              <span class="highlight-note">Checked before handover</span>
            </div>
          </div>

          <div class="col-lg-3 col-md-6">
            <div class="department-highlight">
              <span class="highlight-number">04</span>
              <div class="highlight-icon"><i class="bi bi-bag-check"></i></div>
              <h4>Easy Handover</h4>
              <p>Quick processing, clear documentation, and a smooth path from selection to delivery.</p>
              <span class="highlight-note">Ready when you are</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <section class="customer-stories section">
      <div class="container section-title" data-aos="fade-up">
        <span class="section-kicker">Customer stories</span>
        <h2>Drivers choose us with confidence</h2>
        <p>Real support, straightforward deals, and cars that make every journey feel better.</p>
      </div>
      <div class="container"><div class="row g-4">
       ```html
<div class="col-lg-4">
    <article class="testimonial-card">

        <div class="testimonial-stars">★★★★★</div>

        <p>
            “Rehman Brothers made the whole car-buying process simple and transparent.
            The vehicle was exactly as described and delivered on time.”
        </p>

        <div class="testimonial-author">
            <strong>Ahmed R.</strong>
            <span>Toyota Corolla Owner</span>
        </div>

    </article>
</div>


<div class="col-lg-4">
    <article class="testimonial-card featured">

        <div class="testimonial-stars">★★★★★</div>

        <p>
            “Excellent service from start to finish. The team provided honest guidance,
            clear pricing, and helped me find the right Japanese imported car.”
        </p>

        <div class="testimonial-author">
            <strong>Hina K.</strong>
            <span>Honda Civic Owner</span>
        </div>

    </article>
</div>


<div class="col-lg-4">
    <article class="testimonial-card">

        <div class="testimonial-stars">★★★★★</div>

        <p>
            “I was looking for a reliable Japanese car within my budget, and
            Rehman Brothers helped me find exactly what I needed. Highly recommended.”
        </p>

        <div class="testimonial-author">
            <strong>Usman A.</strong>
            <span>Suzuki Swift Owner</span>
        </div>

    </article>
</div>
```

      </div></div>
    </section>

    <section id="call-to-action" class="call-to-action section light-background">
      <div class="container">
        <div class="hero-content">
          <div class="row align-items-center">
            <div class="col-lg-6">
              <div class="content-wrapper">
                <span class="cta-kicker">Find your right car</span>
                <h1>Want a car that fits your needs?</h1>
                <p>Contact us and our team will help you find the right car with honest guidance and clear answers.</p>

                <div class="cta-wrapper">
                  <a href="#contact" class="primary-cta"><span>Contact us</span><i class="bi bi-arrow-up-right"></i></a>
                  <a href="#inventory" class="secondary-cta"><span>Browse Inventory</span><i class="bi bi-arrow-up-right"></i></a>
                </div>
              </div>
            </div>

            <div class="col-lg-6">
              <div class="image-container">
                <img src=".\assets\img\office\WhatsApp Image 2026-09-03 at 2.02.52 PM.jpeg" alt="Japanese car dealership" class="img-fluid">
                <div class="image-caption"><i class="bi bi-geo-alt"></i><span>Visit our showroom</span></div>
              </div>
            </div>
          </div>
        </div>

        <div class="features-section">
          <div class="row g-0">
            <div class="col-lg-4">
              <div class="feature-block">
                <div class="feature-icon"><i class="bi bi-shield-check"></i></div>
                <h3>Certified Quality</h3>
                <p>Every vehicle is carefully selected and checked to meet high standards.</p>
              </div>
            </div>

            <div class="col-lg-4">
              <div class="feature-block">
                <div class="feature-icon"><i class="bi bi-clock-history"></i></div>
                <h3>Fast Turnaround</h3>
                <p>We help you move quickly from search to delivery with minimal hassle.</p>
              </div>
            </div>

            <div class="col-lg-4">
              <div class="feature-block">
                <div class="feature-icon"><i class="bi bi-people"></i></div>
                <h3>Customer First</h3>
                <p>Friendly guidance, clear communication, and service that values your trust.</p>
              </div>
            </div>
          </div>
        </div>

        <div class="contact-block" id="contact">
          <div class="row">
            <div class="col-lg-8">
              <div class="contact-content">
                <span class="contact-kicker">Find your right car</span>
                <h2>Want a car that fits your needs?</h2>
                <p>Contact us and our team will help you find the right car with honest guidance and clear answers.</p>
              </div>
            </div>

            <div class="col-lg-4">
              <div class="contact-actions">
                <a href="tel:+817027963926" class="emergency-call"><i class="bi bi-telephone"></i><span>Call Now</span></a>
                <a href="mailto:rehmanbrothers.info@gmail.com" class="contact-link"><i class="bi bi-envelope"></i><span>Email Us</span></a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

  </main>
<?php
include('footer.php');
?>
  