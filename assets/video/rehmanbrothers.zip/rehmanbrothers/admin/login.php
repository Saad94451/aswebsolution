<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login | Rehman Brothers Admin</title>
  <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/vendors/bootstrap-icons/bootstrap-icons.css">
  <link rel="stylesheet" href="./assets/css/style.css">
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
  <style>
    body {
      background: linear-gradient(135deg, #0A3785 0%, #2F62BA 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
    }
    .login-card {
      background: #ffffff;
      border-radius: 20px;
      padding: 3rem;
      box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
      max-width: 400px;
      width: 100%;
    }
    .login-card h2 {
      color: #0f4cb3;
      font-weight: 800;
      margin-bottom: 0.5rem;
    }
    .login-card p {
      color: #666;
      margin-bottom: 2rem;
    }
    .form-control {
      padding: 0.75rem 1rem;
      border-radius: 10px;
      border: 1px solid #ddd;
    }
    .form-control:focus {
      border-color: #0f4cb3;
      box-shadow: 0 0 0 0.2rem rgba(29, 26, 194, 0.25);
    }
    .btn-primary {
        background: linear-gradient(135deg, #0A3785 0%, #2F62BA 100%);
     
      padding: 0.75rem 1.5rem;
      border-radius: 10px;
      font-weight: 600;
    }
    .btn-primary:hover {
     
      border-color:2px solid #0f4cb3;
      background-color:white;
      color:#0f4cb3;
    }
  </style>
</head>
<body>
  <div class="login-card">
    <div class="text-center mb-4">
      <h2>Admin Login</h2>
      <p>Rehman Brothers</p>
    </div>
    <?php
    session_start();
    include '../config.php';

    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
      $username = mysqli_real_escape_string($conn, trim($_POST['username']));
      $password = trim($_POST['password']);

      if ($username == 'admin' && $password == 'admin123') {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_username'] = 'admin';
        echo "<script>
          Swal.fire({
            icon: 'success',
            title: 'Login Successful',
            text: 'Welcome back!',
            timer: 1500,
            showConfirmButton: false
          }).then(() => {
            window.location.href = 'index.php';
          });
        </script>";
      } else {
        echo "<script>
          Swal.fire({
            icon: 'error',
            title: 'Login Failed',
            text: 'Invalid username or password'
          });
        </script>";
      }
    }
    ?>
    <form method="POST">
      <div class="mb-3">
        <label for="username" class="form-label">Username</label>
        <input type="text" class="form-control" id="username" name="username" required>
      </div>
      <div class="mb-3">
        <label for="password" class="form-label">Password</label>
        <input type="password" class="form-control" id="password" name="password" required>
      </div>
      <button type="submit" class="btn btn-primary w-100">Login</button>
    </form>
  </div>
  <script src="./assets/js/bootstrap.bundle.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</body>
</html>
