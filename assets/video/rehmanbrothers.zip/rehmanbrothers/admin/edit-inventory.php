<?php

include '../config.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header("Location: view-inventory.php");
    exit;
}


// ==========================================
// GET CURRENT VEHICLE
// ==========================================

$query = mysqli_query(
    $conn,
    "SELECT * FROM inventory WHERE id = '$id' LIMIT 1"
);

$row = mysqli_fetch_assoc($query);

if (!$row) {
    header("Location: view-inventory.php");
    exit;
}


// ==========================================
// ALERT VARIABLES
// ==========================================

$alert_type = '';
$alert_title = '';
$alert_text = '';


// ==========================================
// UPDATE VEHICLE
// ==========================================

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $name = mysqli_real_escape_string(
        $conn,
        trim($_POST['name'] ?? '')
    );

    $year = mysqli_real_escape_string(
        $conn,
        trim($_POST['year'] ?? '')
    );

    $transmission = mysqli_real_escape_string(
        $conn,
        trim($_POST['transmission'] ?? '')
    );

    $fuel = mysqli_real_escape_string(
        $conn,
        trim($_POST['fuel'] ?? '')
    );

    $mileage = mysqli_real_escape_string(
        $conn,
        trim($_POST['mileage'] ?? '')
    );

    $price = mysqli_real_escape_string(
        $conn,
        trim($_POST['price'] ?? '')
    );

    $chassis_number = mysqli_real_escape_string(
        $conn,
        trim($_POST['chassis_number'] ?? '')
    );

    $engine = mysqli_real_escape_string(
        $conn,
        trim($_POST['engine'] ?? '')
    );

    $color = mysqli_real_escape_string(
        $conn,
        trim($_POST['color'] ?? '')
    );

    $seats = mysqli_real_escape_string(
        $conn,
        trim($_POST['seats'] ?? '')
    );

    $conditions = mysqli_real_escape_string(
        $conn,
        trim($_POST['conditions'] ?? '')
    );

    $description = mysqli_real_escape_string(
        $conn,
        trim($_POST['description'] ?? '')
    );

    $engine_capacity = mysqli_real_escape_string(
        $conn,
        trim($_POST['engine_capacity'] ?? '')
    );


    // ==========================================
    // CURRENT IMAGES
    // ==========================================

    $existing_images = [];

    for ($i = 1; $i <= 10; $i++) {

        $image = trim($row['img_' . $i] ?? '');

        if ($image !== '') {
            $existing_images[] = $image;
        }
    }


    // ==========================================
    // REMOVED OLD IMAGES
    // ==========================================

    $removed_images = [];

    if (!empty($_POST['removed_images'])) {

        $removed_images = json_decode(
            $_POST['removed_images'],
            true
        );

        if (!is_array($removed_images)) {
            $removed_images = [];
        }
    }


    // Remove deleted images from existing array

    foreach ($removed_images as $removed) {

        $removed = basename($removed);

        $key = array_search(
            $removed,
            $existing_images,
            true
        );

        if ($key !== false) {
            unset($existing_images[$key]);
        }
    }

    $existing_images = array_values($existing_images);


    // ==========================================
    // UPLOAD NEW IMAGES
    // ==========================================

    $new_uploaded_images = [];

    $upload_dir = "../uploads/";

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }


    if (
        isset($_FILES['vehicle_images']) &&
        isset($_FILES['vehicle_images']['name']) &&
        is_array($_FILES['vehicle_images']['name'])
    ) {

        $total_new = count(
            $_FILES['vehicle_images']['name']
        );


        for (
            $i = 0;
            $i < $total_new && count($new_uploaded_images) < 10;
            $i++
        ) {

            if (
                $_FILES['vehicle_images']['error'][$i]
                !== UPLOAD_ERR_OK
            ) {
                continue;
            }


            $original_name =
                $_FILES['vehicle_images']['name'][$i];

            $tmp_name =
                $_FILES['vehicle_images']['tmp_name'][$i];


            if (empty($original_name)) {
                continue;
            }


            $extension = strtolower(
                pathinfo(
                    $original_name,
                    PATHINFO_EXTENSION
                )
            );


            $allowed_extensions = [
                'jpg',
                'jpeg',
                'png',
                'webp'
            ];


            if (
                !in_array(
                    $extension,
                    $allowed_extensions,
                    true
                )
            ) {
                continue;
            }


            $new_name =
                'vehicle_' .
                time() .
                '_' .
                uniqid() .
                '.' .
                $extension;


            $target_file =
                $upload_dir . $new_name;


            if (
                move_uploaded_file(
                    $tmp_name,
                    $target_file
                )
            ) {

                $new_uploaded_images[] = $new_name;
            }
        }
    }


    // ==========================================
    // IMAGE ORDER
    // ==========================================

    /*
       image_order contains values like:

       existing:filename1.jpg
       existing:filename2.jpg
       new:0
       new:1

       This tells PHP exactly which image
       should become img_1, img_2 etc.
    */

    $image_order = [];

    if (!empty($_POST['image_order'])) {

        $image_order = json_decode(
            $_POST['image_order'],
            true
        );

        if (!is_array($image_order)) {
            $image_order = [];
        }
    }


    $final_images = [];

    foreach ($image_order as $item) {

        if (count($final_images) >= 10) {
            break;
        }


        // ======================================
        // EXISTING IMAGE
        // ======================================

        if (
            is_string($item) &&
            strpos($item, 'existing:') === 0
        ) {

            $filename = substr(
                $item,
                strlen('existing:')
            );

            $filename = basename($filename);


            if (
                in_array(
                    $filename,
                    $existing_images,
                    true
                )
            ) {

                $final_images[] = $filename;
            }
        }


        // ======================================
        // NEW IMAGE
        // ======================================

        elseif (
            is_string($item) &&
            strpos($item, 'new:') === 0
        ) {

            $new_index = (int)substr(
                $item,
                strlen('new:')
            );


            if (
                isset(
                    $new_uploaded_images[$new_index]
                )
            ) {

                $final_images[] =
                    $new_uploaded_images[$new_index];
            }
        }
    }


    // ==========================================
    // FALLBACK
    // ==========================================

    /*
       Agar browser image_order na bheje,
       existing + new images ko use karenge.
    */

    if (empty($image_order)) {

        $final_images = array_merge(
            $existing_images,
            $new_uploaded_images
        );

        $final_images = array_slice(
            $final_images,
            0,
            10
        );
    }


    // ==========================================
    // DELETE REMOVED OLD FILES
    // ==========================================

    foreach ($removed_images as $removed) {

        $removed = basename($removed);

        $file_path =
            $upload_dir . $removed;


        if (
            file_exists($file_path) &&
            !in_array(
                $removed,
                $final_images,
                true
            )
        ) {

            unlink($file_path);
        }
    }


    // ==========================================
    // DELETE NEWLY UPLOADED BUT NOT USED
    // ==========================================

    foreach ($new_uploaded_images as $new_image) {

        if (
            !in_array(
                $new_image,
                $final_images,
                true
            )
        ) {

            $file_path =
                $upload_dir . $new_image;


            if (file_exists($file_path)) {
                unlink($file_path);
            }
        }
    }


    // ==========================================
    // IMG_1 TO IMG_10
    // ==========================================

    $image_values = [];

    for ($i = 0; $i < 10; $i++) {

        $image_values[$i] =
            $final_images[$i] ?? '';
    }


    // Escape image values

    for ($i = 0; $i < 10; $i++) {

        $image_values[$i] =
            mysqli_real_escape_string(
                $conn,
                $image_values[$i]
            );
    }


    // ==========================================
    // UPDATE QUERY
    // ==========================================

    $update = mysqli_query(
        $conn,
        "
        UPDATE inventory SET

            name='$name',

            year='$year',

            transmission='$transmission',

            fuel='$fuel',

            mileage='$mileage',

            price='$price',

            chassis_number='$chassis_number',

            engine='$engine',

            color='$color',

            seats='$seats',

            conditions='$conditions',

            description='$description',

            img_1='{$image_values[0]}',

            img_2='{$image_values[1]}',

            img_3='{$image_values[2]}',

            img_4='{$image_values[3]}',

            img_5='{$image_values[4]}',

            img_6='{$image_values[5]}',

            img_7='{$image_values[6]}',

            img_8='{$image_values[7]}',

            img_9='{$image_values[8]}',

            img_10='{$image_values[9]}',

            engine_capacity='$engine_capacity'

        WHERE id='$id'
        "
    );


    // ==========================================
    // RESULT
    // ==========================================

    if ($update) {

        $alert_type = 'success';

        $alert_title = 'Updated!';

        $alert_text =
            'Vehicle inventory updated successfully.';

    } else {

        $alert_type = 'error';

        $alert_title = 'Error';

        $alert_text =
            'Failed to update vehicle inventory.';
    }


    // Refresh row after update

    $query = mysqli_query(
        $conn,
        "SELECT * FROM inventory WHERE id='$id' LIMIT 1"
    );

    $row = mysqli_fetch_assoc($query);
}


// ==========================================
// HEADER
// ==========================================

include 'header.php';

?>


<!-- ==========================================
     PAGE HEADING
========================================== -->

<div class="page-heading">

    <div class="page-heading-copy">

        <span class="page-icon">

            <i
                class="bi bi-car-front-fill"
                aria-hidden="true"
            ></i>

        </span>


        <div>

            <p class="eyebrow mb-1">
                Inventory
            </p>

            <h1 class="h3 mb-1">
                Edit Inventory
            </h1>

            <p class="text-muted mb-0">
                Update vehicle details and images
            </p>

        </div>

    </div>

</div>


<!-- ==========================================
     MAIN PANEL
========================================== -->

<section class="panel">

    <div class="panel-header">

        <div>

            <h2 class="h5 mb-1 section-title">

                <i
                    class="bi bi-pencil"
                    aria-hidden="true"
                ></i>

                <span>
                    Edit Vehicle
                </span>

            </h2>

            <p class="text-muted mb-0">
                Update the details below
            </p>

        </div>

    </div>


    <form
        method="POST"
        enctype="multipart/form-data"
        id="inventoryForm"
    >

        <div class="row g-3">


            <!-- ==================================
                 VEHICLE NAME
            ================================== -->

            <div class="col-md-6">

                <label class="form-label">
                    Vehicle Name
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="name"
                    value="<?php echo htmlspecialchars($row['name'] ?? ''); ?>"
                    required
                >

            </div>


            <!-- YEAR -->

            <div class="col-md-3">

                <label class="form-label">
                    Year
                </label>

                <input
                    type="number"
                    class="form-control"
                    name="year"
                    value="<?php echo htmlspecialchars($row['year'] ?? ''); ?>"
                    min="1900"
                    max="2100"
                    required
                >

            </div>


            <!-- CONDITION -->

            <div class="col-md-3">

                <label class="form-label">
                    Condition
                </label>

                <select
                    class="form-select"
                    name="conditions"
                    required
                >

                    <option value="">
                        Select Condition
                    </option>

                    <option
                        value="New"
                        <?php echo (($row['conditions'] ?? '') == 'New') ? 'selected' : ''; ?>
                    >
                        New
                    </option>

                    <option
                        value="Used"
                        <?php echo (($row['conditions'] ?? '') == 'Used') ? 'selected' : ''; ?>
                    >
                        Used
                    </option>

                    <option
                        value="Excellent"
                        <?php echo (($row['conditions'] ?? '') == 'Excellent') ? 'selected' : ''; ?>
                    >
                        Excellent
                    </option>

                    <option
                        value="Good"
                        <?php echo (($row['conditions'] ?? '') == 'Good') ? 'selected' : ''; ?>
                    >
                        Good
                    </option>

                </select>

            </div>


            <!-- TRANSMISSION -->

            <div class="col-md-4">

                <label class="form-label">
                    Transmission
                </label>

                <select
                    class="form-select"
                    name="transmission"
                    required
                >

                    <option value="">
                        Select Transmission
                    </option>

                    <option
                        value="Automatic"
                        <?php echo (($row['transmission'] ?? '') == 'Automatic') ? 'selected' : ''; ?>
                    >
                        Automatic
                    </option>

                    <option
                        value="Manual"
                        <?php echo (($row['transmission'] ?? '') == 'Manual') ? 'selected' : ''; ?>
                    >
                        Manual
                    </option>

                    <option
                        value="CVT"
                        <?php echo (($row['transmission'] ?? '') == 'CVT') ? 'selected' : ''; ?>
                    >
                        CVT
                    </option>

                </select>

            </div>


            <!-- FUEL -->

            <div class="col-md-4">

                <label class="form-label">
                    Fuel
                </label>

                <select
                    class="form-select"
                    name="fuel"
                    required
                >

                    <option value="">
                        Select Fuel
                    </option>

                    <option
                        value="Petrol"
                        <?php echo (($row['fuel'] ?? '') == 'Petrol') ? 'selected' : ''; ?>
                    >
                        Petrol
                    </option>

                    <option
                        value="Diesel"
                        <?php echo (($row['fuel'] ?? '') == 'Diesel') ? 'selected' : ''; ?>
                    >
                        Diesel
                    </option>

                    <option
                        value="Hybrid"
                        <?php echo (($row['fuel'] ?? '') == 'Hybrid') ? 'selected' : ''; ?>
                    >
                        Hybrid
                    </option>

                    <option
                        value="Electric"
                        <?php echo (($row['fuel'] ?? '') == 'Electric') ? 'selected' : ''; ?>
                    >
                        Electric
                    </option>

                </select>

            </div>


            <!-- MILEAGE -->

            <div class="col-md-4">

                <label class="form-label">
                    Mileage
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="mileage"
                    value="<?php echo htmlspecialchars($row['mileage'] ?? ''); ?>"
                    required
                >

            </div>


            <!-- ENGINE CAPACITY -->

            <div class="col-md-4">

                <label class="form-label">
                    Engine Capacity / CC
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="engine_capacity"
                    value="<?php echo htmlspecialchars($row['engine_capacity'] ?? ''); ?>"
                    required
                >

            </div>


            <!-- ENGINE -->

            <div class="col-md-4">

                <label class="form-label">
                    Engine
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="engine"
                    value="<?php echo htmlspecialchars($row['engine'] ?? ''); ?>"
                    required
                >

            </div>


            <!-- COLOR -->

            <div class="col-md-4">

                <label class="form-label">
                    Color
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="color"
                    value="<?php echo htmlspecialchars($row['color'] ?? ''); ?>"
                    required
                >

            </div>


            <!-- SEATS -->

            <div class="col-md-4">

                <label class="form-label">
                    Seats
                </label>

                <input
                    type="number"
                    class="form-control"
                    name="seats"
                    value="<?php echo htmlspecialchars($row['seats'] ?? ''); ?>"
                    min="1"
                    required
                >

            </div>


            <!-- PRICE -->

            <div class="col-md-4">

                <label class="form-label">
                    Price
                </label>

                <input
                    type="number"
                    class="form-control"
                    name="price"
                    value="<?php echo htmlspecialchars($row['price'] ?? ''); ?>"
                    min="0"
                    required
                >

            </div>


            <!-- CHASSIS -->

            <div class="col-md-8">

                <label class="form-label">
                    Chassis Number
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="chassis_number"
                    value="<?php echo htmlspecialchars($row['chassis_number'] ?? ''); ?>"
                    required
                >

            </div>


            <!-- DESCRIPTION -->

            <div class="col-12">

                <label class="form-label">
                    Description
                </label>

                <textarea
                    class="form-control"
                    name="description"
                    rows="5"
                    required
                ><?php echo htmlspecialchars($row['description'] ?? ''); ?></textarea>

            </div>


            <!-- ==================================
                 IMAGE MANAGEMENT
            ================================== -->

            <div class="col-12">

                <div class="inventory-image-header">

                    <div>

                        <label class="form-label mb-1">
                            Vehicle Images
                        </label>

                        <div class="text-muted small">

                            Drag images to change their order.
                            The first image will become <b>img_1</b>.

                        </div>

                    </div>

                    <span
                        class="badge bg-primary"
                        id="imageCount"
                    >
                        0 / 10
                    </span>

                </div>


                <!-- ==================================
                     IMAGE GALLERY
                ================================== -->

                <div
                    id="imageGallery"
                    class="row g-3 mt-2"
                >

                    <?php

                    for ($i = 1; $i <= 10; $i++) {

                        $image =
                            trim($row['img_' . $i] ?? '');

                        if ($image === '') {
                            continue;
                        }

                    ?>

                        <div
                            class="col-6 col-md-4 col-lg-3 gallery-item"
                            data-type="existing"
                            data-filename="<?php echo htmlspecialchars($image); ?>"
                        >

                            <div class="inventory-image-card">

                                <div class="drag-handle">

                                    <i class="bi bi-grip-vertical"></i>

                                    <span>
                                        Drag
                                    </span>

                                </div>


                                <img
                                    src="../uploads/<?php echo htmlspecialchars($image); ?>"
                                    alt="Vehicle Image"
                                    class="inventory-preview-image"
                                >


                                <div class="image-card-footer">

                                    <span class="image-label">
                                        Image <?php echo $i; ?>
                                    </span>


                                    <button
                                        type="button"
                                        class="btn btn-danger btn-sm remove-existing-image"
                                    >

                                        <i class="bi bi-trash"></i>

                                    </button>

                                </div>

                            </div>

                        </div>

                    <?php } ?>

                </div>


                <!-- ==================================
                     NEW IMAGE INPUT
                ================================== -->

                <div class="mt-4">

                    <label class="form-label">
                        Add New Images
                    </label>

                    <input
                        type="file"
                        class="form-control"
                        id="vehicleImages"
                        name="vehicle_images[]"
                        multiple
                        accept="image/jpeg,image/png,image/webp"
                    >

                    <small class="text-muted">
                        Add new JPG, JPEG, PNG or WEBP images.
                        Maximum total images: 10.
                    </small>

                </div>


                <!-- Hidden fields -->

                <input
                    type="hidden"
                    name="image_order"
                    id="imageOrder"
                >

                <input
                    type="hidden"
                    name="removed_images"
                    id="removedImages"
                >

            </div>


            <!-- ==================================
                 BUTTONS
            ================================== -->

            <div class="col-12 mt-3">

                <button
                    type="submit"
                    class="btn btn-primary"
                >

                    <i class="bi bi-check-circle"></i>

                    Update Vehicle

                </button>


                <a
                    href="view-inventory.php"
                    class="btn btn-secondary"
                >
                    Cancel
                </a>

            </div>

        </div>

    </form>

</section>


<!-- ==========================================
     SORTABLE JS
========================================== -->

<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.6/Sortable.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<script>

const gallery =
    document.getElementById('imageGallery');

const imageInput =
    document.getElementById('vehicleImages');

const imageOrderInput =
    document.getElementById('imageOrder');

const removedImagesInput =
    document.getElementById('removedImages');

const imageCount =
    document.getElementById('imageCount');


// ==========================================
// NEW FILES ARRAY
// ==========================================

let selectedFiles = [];


// ==========================================
// REMOVED EXISTING IMAGES
// ==========================================

let removedImages = [];


// ==========================================
// INITIALIZE SORTABLE
// ==========================================

const sortable = new Sortable(gallery, {

    animation: 200,

    handle: '.drag-handle',

    ghostClass: 'sortable-ghost',

    chosenClass: 'sortable-chosen',

    dragClass: 'sortable-drag',

    onEnd: function () {

        updateImageOrder();

        updateLabels();

    }

});


// ==========================================
// NEW IMAGE SELECT
// ==========================================

imageInput.addEventListener(
    'change',
    function () {

        const files =
            Array.from(this.files);


        const currentCount =
            gallery.querySelectorAll('.gallery-item').length;


        if (
            currentCount + files.length > 10
        ) {

            Swal.fire({

                icon: 'warning',

                title: 'Maximum 10 Images',

                text:
                    'You can have maximum 10 images in total.'

            });


            this.value = '';

            return;
        }


        files.forEach(function (file) {

            if (
                !file.type.startsWith('image/')
            ) {
                return;
            }


            const fileIndex =
                selectedFiles.length;


            selectedFiles.push(file);


            createNewImagePreview(
                file,
                fileIndex
            );

        });


        this.value = '';

        updateImageOrder();

        updateLabels();

    }
);


// ==========================================
// CREATE NEW IMAGE PREVIEW
// ==========================================

function createNewImagePreview(
    file,
    fileIndex
) {

    const reader =
        new FileReader();


    reader.onload = function (event) {

        const col =
            document.createElement('div');


        col.className =
            'col-6 col-md-4 col-lg-3 gallery-item';


        col.setAttribute(
            'data-type',
            'new'
        );


        col.setAttribute(
            'data-file-index',
            fileIndex
        );


        col.innerHTML = `

            <div class="inventory-image-card">

                <div class="drag-handle">

                    <i class="bi bi-grip-vertical"></i>

                    <span>
                        Drag
                    </span>

                </div>


                <img
                    src="${event.target.result}"
                    alt="New Vehicle Image"
                    class="inventory-preview-image"
                >


                <div class="image-card-footer">

                    <span class="image-label">
                        New Image
                    </span>


                    <button
                        type="button"
                        class="btn btn-danger btn-sm remove-new-image"
                    >

                        <i class="bi bi-trash"></i>

                    </button>

                </div>

            </div>

        `;


        gallery.appendChild(col);


        updateImageOrder();

        updateLabels();

    };


    reader.readAsDataURL(file);

}


// ==========================================
// REMOVE EXISTING IMAGE
// ==========================================

gallery.addEventListener(
    'click',
    function (e) {

        const button =
            e.target.closest(
                '.remove-existing-image'
            );


        if (!button) {
            return;
        }


        const item =
            button.closest('.gallery-item');


        const filename =
            item.getAttribute(
                'data-filename'
            );


        Swal.fire({

            icon: 'warning',

            title: 'Remove Image?',

            text:
                'This image will be removed from this vehicle.',

            showCancelButton: true,

            confirmButtonText: 'Yes, Remove',

            cancelButtonText: 'Cancel'

        }).then(function (result) {

            if (!result.isConfirmed) {
                return;
            }


            if (
                !removedImages.includes(
                    filename
                )
            ) {

                removedImages.push(
                    filename
                );

            }


            item.remove();


            updateImageOrder();

            updateLabels();

        });

    }
);


// ==========================================
// REMOVE NEW IMAGE
// ==========================================

gallery.addEventListener(
    'click',
    function (e) {

        const button =
            e.target.closest(
                '.remove-new-image'
            );


        if (!button) {
            return;
        }


        const item =
            button.closest('.gallery-item');


        const fileIndex =
            parseInt(
                item.getAttribute(
                    'data-file-index'
                )
            );


        selectedFiles[fileIndex] = null;


        item.remove();


        updateImageOrder();

        updateLabels();

    }
);


// ==========================================
// UPDATE IMAGE ORDER
// ==========================================

function updateImageOrder() {

    const items =
        Array.from(
            gallery.querySelectorAll(
                '.gallery-item'
            )
        );


    const order = [];


    items.forEach(function (item) {

        const type =
            item.getAttribute(
                'data-type'
            );


        if (type === 'existing') {

            const filename =
                item.getAttribute(
                    'data-filename'
                );


            order.push(
                'existing:' + filename
            );

        }


        else if (type === 'new') {

            const fileIndex =
                item.getAttribute(
                    'data-file-index'
                );


            order.push(
                'new:' + fileIndex
            );

        }

    });


    imageOrderInput.value =
        JSON.stringify(order);


    removedImagesInput.value =
        JSON.stringify(removedImages);


    updateImageCount();

}


// ==========================================
// UPDATE LABELS
// ==========================================

function updateLabels() {

    const items =
        Array.from(
            gallery.querySelectorAll(
                '.gallery-item'
            )
        );


    items.forEach(function (item, index) {

        const label =
            item.querySelector(
                '.image-label'
            );


        if (!label) {
            return;
        }


        if (index === 0) {

            label.innerHTML =
                '⭐ Main Image';

        } else {

            label.innerHTML =
                'Image ' + (index + 1);

        }

    });

}


// ==========================================
// IMAGE COUNT
// ==========================================

function updateImageCount() {

    const count =
        gallery.querySelectorAll(
            '.gallery-item'
        ).length;


    imageCount.textContent =
        count + ' / 10';


    if (count >= 10) {

        imageCount.classList.remove(
            'bg-primary'
        );

        imageCount.classList.add(
            'bg-danger'
        );

    } else {

        imageCount.classList.remove(
            'bg-danger'
        );

        imageCount.classList.add(
            'bg-primary'
        );
    }

}


// ==========================================
// FORM SUBMIT
// ==========================================

document
    .getElementById('inventoryForm')
    .addEventListener(
        'submit',
        function (e) {

            updateImageOrder();

            updateLabels();


            const totalImages =
                gallery.querySelectorAll(
                    '.gallery-item'
                ).length;


            if (totalImages === 0) {

                e.preventDefault();


                Swal.fire({

                    icon: 'warning',

                    title: 'No Images',

                    text:
                        'Please keep at least one vehicle image.'

                });


                return false;
            }


            if (totalImages > 10) {

                e.preventDefault();


                Swal.fire({

                    icon: 'warning',

                    title: 'Too Many Images',

                    text:
                        'Maximum 10 images are allowed.'

                });


                return false;
            }

        }
    );


// Initial values

updateImageOrder();

updateLabels();

updateImageCount();

</script>


<!-- ==========================================
     STYLING
========================================== -->

<style>

.inventory-image-header {

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 15px;

}


.inventory-image-card {

    position: relative;

    background: #fff;

    border: 1px solid #e5e7eb;

    border-radius: 10px;

    overflow: hidden;

    transition:
        transform 0.2s ease,
        box-shadow 0.2s ease;

}


.inventory-image-card:hover {

    transform: translateY(-2px);

    box-shadow:
        0 5px 18px rgba(0, 0, 0, 0.08);

}


.inventory-preview-image {

    display: block;

    width: 100%;

    height: 180px;

    object-fit: cover;

}


.drag-handle {

    position: absolute;

    top: 8px;

    left: 8px;

    z-index: 5;

    display: flex;

    align-items: center;

    gap: 4px;

    padding: 5px 8px;

    background: rgba(0, 0, 0, 0.65);

    color: #fff;

    border-radius: 6px;

    font-size: 12px;

    cursor: grab;

}


.drag-handle:active {

    cursor: grabbing;

}


.image-card-footer {

    min-height: 48px;

    padding: 8px 10px;

    display: flex;

    align-items: center;

    justify-content: space-between;

    gap: 8px;

}


.image-label {

    font-size: 13px;

    font-weight: 600;

}


.sortable-ghost {

    opacity: 0.35;

}


.sortable-chosen {

    transform: scale(1.02);

}


.sortable-drag {

    cursor: grabbing;

}


.remove-existing-image,

.remove-new-image {

    flex-shrink: 0;

}

</style>


<?php if ($alert_type !== '') { ?>

<script>

Swal.fire({

    icon: <?php echo json_encode($alert_type); ?>,

    title: <?php echo json_encode($alert_title); ?>,

    text: <?php echo json_encode($alert_text); ?>,

    timer: 1600,

    showConfirmButton: false

}).then(function () {

    <?php if ($alert_type === 'success') { ?>

    window.location.href =
        'view-inventory.php';

    <?php } ?>

});

</script>

<?php } ?>


<?php include 'footer.php'; ?>