```php
<?php include 'header.php'; ?>

<?php
include '../config.php';

/*
|--------------------------------------------------------------------------
| Fetch Dashboard Counts
|--------------------------------------------------------------------------
*/

// Total Inventory
$inventory_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM inventory");
$inventory_data = mysqli_fetch_assoc($inventory_query);
$total_inventory = $inventory_data['total'];

// Total Contacts
$contacts_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM contacts");
$contacts_data = mysqli_fetch_assoc($contacts_query);
$total_contacts = $contacts_data['total'];

// Total Hero Slides
$slides_query = mysqli_query($conn, "SELECT COUNT(*) AS total FROM hero_slides");
$slides_data = mysqli_fetch_assoc($slides_query);
$total_slides = $slides_data['total'];
?>

<!-- Page Heading -->
<div class="page-heading">
    <div class="page-heading-copy">

        <span class="page-icon">
            <i class="bi bi-speedometer2" aria-hidden="true"></i>
        </span>

        <div>
            <p class="eyebrow mb-1">Overview</p>

            <h1 class="h3 mb-1">
                Dashboard
            </h1>

            <p class="text-muted mb-0">
                Manage your inventory, contacts, and website content from one clean workspace.
            </p>
        </div>

    </div>
</div>


<!-- Dashboard Metrics -->
<section class="row g-3 mt-1" aria-label="Dashboard metrics">

    <!-- Inventory -->
    <div class="col-12 col-sm-6 col-xl-4">

        <article class="metric-card metric-primary">

            <div class="metric-top">

                <span class="metric-label">
                    Total Inventory
                </span>

                <span class="metric-icon">
                    <i class="bi bi-car-front-fill" aria-hidden="true"></i>
                </span>

            </div>

            <div class="metric-value">
                <?php echo $total_inventory; ?>
            </div>

            <div class="metric-meta">

                <span class="text-success">
                    Vehicles
                </span>

                <span>
                    in inventory
                </span>

            </div>

        </article>

    </div>


    <!-- Contacts -->
    <div class="col-12 col-sm-6 col-xl-4">

        <article class="metric-card metric-success">

            <div class="metric-top">

                <span class="metric-label">
                    Total Contacts
                </span>

                <span class="metric-icon">
                    <i class="bi bi-envelope-fill" aria-hidden="true"></i>
                </span>

            </div>

            <div class="metric-value">
                <?php echo $total_contacts; ?>
            </div>

            <div class="metric-meta">

                <span class="text-success">
                    Contact Messages
                </span>

                <span>
                    received
                </span>

            </div>

        </article>

    </div>


    <!-- Hero Slides -->
    <div class="col-12 col-sm-6 col-xl-4">

        <article class="metric-card metric-warning">

            <div class="metric-top">

                <span class="metric-label">
                    Hero Slides
                </span>

                <span class="metric-icon">
                    <i class="bi bi-images" aria-hidden="true"></i>
                </span>

            </div>

            <div class="metric-value">
                <?php echo $total_slides; ?>
            </div>

            <div class="metric-meta">

                <span class="text-success">
                    Website Slides
                </span>

                <span>
                    available
                </span>

            </div>

        </article>

    </div>

</section>


<?php include 'footer.php'; ?>
```

