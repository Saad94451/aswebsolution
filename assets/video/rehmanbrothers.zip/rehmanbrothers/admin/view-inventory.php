<?php include 'header.php'; ?>

<?php
include '../config.php';

// =========================
// Handle Delete
// =========================
if (isset($_GET['delete'])) {

    $id = mysqli_real_escape_string($conn, $_GET['delete']);

    $delete_query = mysqli_query(
        $conn,
        "DELETE FROM inventory WHERE id = '$id'"
    );

    if ($delete_query) {
        echo "<script>
            Swal.fire({
                icon: 'success',
                title: 'Deleted!',
                text: 'Vehicle deleted successfully',
                timer: 1500,
                showConfirmButton: false
            }).then(() => {
                window.location.href = 'view-inventory.php';
            });
        </script>";
    } else {
        echo "<script>
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Failed to delete vehicle'
            });
        </script>";
    }
}


// =========================
// Pagination
// =========================
$limit = 10;

$page = isset($_GET['page'])
    ? (int)$_GET['page']
    : 1;

if ($page < 1) {
    $page = 1;
}

$offset = ($page - 1) * $limit;


// =========================
// Search
// =========================
$search = isset($_GET['search'])
    ? mysqli_real_escape_string($conn, $_GET['search'])
    : '';

$search_condition = '';

if ($search !== '') {

    $search_condition = "
        AND (
            inventory.name LIKE '%$search%'
            OR inventory.year LIKE '%$search%'
            OR inventory.transmission LIKE '%$search%'
            OR inventory.fuel LIKE '%$search%'
            OR inventory.mileage LIKE '%$search%'
            OR inventory.engine_capacity LIKE '%$search%'
            OR inventory.color LIKE '%$search%'
            OR inventory.conditions LIKE '%$search%'
        )
    ";
}


// =========================
// Count Total Records
// =========================
$count_query = mysqli_query(
    $conn,
    "SELECT COUNT(*) AS total
     FROM inventory
     WHERE 1=1 $search_condition"
);

$count_result = mysqli_fetch_assoc($count_query);

$total_records = (int)$count_result['total'];

$total_pages = ceil($total_records / $limit);


// =========================
// Fetch Inventory
// =========================
$query = mysqli_query(
    $conn,
    "SELECT *
     FROM inventory
     WHERE 1=1 $search_condition
     ORDER BY id DESC
     LIMIT $limit OFFSET $offset"
);
?>


<!-- =========================
     PAGE HEADING
========================= -->

<div class="page-heading">

    <div class="page-heading-copy">

        <span class="page-icon">
            <i class="bi bi-car-front-fill" aria-hidden="true"></i>
        </span>

        <div>

            <p class="eyebrow mb-1">
                Inventory
            </p>

            <h1 class="h3 mb-1">
                View Inventory
            </h1>

            <p class="text-muted mb-0">
                Manage all vehicles
            </p>

        </div>

    </div>


    <div class="heading-actions">

        <a
            class="btn btn-primary btn-sm"
            href="create-inventory.php"
        >

            <i
                class="bi bi-plus-circle"
                aria-hidden="true"
            ></i>

            Add Vehicle

        </a>

    </div>

</div>



<!-- =========================
     INVENTORY PANEL
========================= -->

<section class="panel">

    <div class="panel-header">

        <div
            class="d-flex justify-content-between align-items-center flex-wrap gap-2"
        >

            <div>

                <h2 class="h5 mb-1 section-title">

                    <i
                        class="bi bi-car-front"
                        aria-hidden="true"
                    ></i>

                    <span>
                        All Vehicles
                    </span>

                </h2>

                <p class="text-muted mb-0">
                    View and manage vehicles
                </p>

            </div>


            <!-- Search -->

            <div class="search-box">

                <input
                    type="text"
                    id="searchInput"
                    class="form-control"
                    placeholder="Search vehicles..."
                    value="<?php echo htmlspecialchars($search); ?>"
                >

            </div>

        </div>

    </div>



    <!-- =========================
         TABLE
    ========================= -->

    <div class="table-responsive">

        <table class="table align-middle mb-0">

            <thead>

                <tr>

                    <th>ID</th>

                    <th>Image</th>

                    <th>Vehicle</th>

                    <th>Year</th>

                    <th>Transmission</th>

                    <th>Fuel</th>

                    <th>Mileage</th>

                    <th>CC</th>

                    <th>Price</th>

                    <th class="text-end">
                        Action
                    </th>

                </tr>

            </thead>


            <tbody>

                <?php if (mysqli_num_rows($query) > 0) { ?>

                    <?php while ($row = mysqli_fetch_assoc($query)) { ?>


                        <?php

                        /*
                         * Images:
                         * img_1, img_2 ... img_10
                         */

                        $first_image = '';

                        if (!empty($row['img_1'])) {

                            $first_image = '../uploads/' . $row['img_1'];

                        } elseif (!empty($row['img_2'])) {

                            $first_image = '../uploads/' . $row['img_2'];

                        } elseif (!empty($row['img_3'])) {

                            $first_image = '../uploads/' . $row['img_3'];

                        }

                        ?>


                        <tr>


                            <!-- ID -->

                            <td>

                                <?php
                                echo (int)$row['id'];
                                ?>

                            </td>



                            <!-- IMAGE -->

                            <td>

                                <?php if ($first_image !== '') { ?>

                                    <img
                                        src="<?php echo htmlspecialchars($first_image); ?>"
                                        alt="<?php echo htmlspecialchars($row['name']); ?>"
                                        style="
                                            width:60px;
                                            height:60px;
                                            object-fit:cover;
                                            border-radius:8px;
                                        "
                                    >

                                <?php } else { ?>

                                    <span class="text-muted">
                                        No image
                                    </span>

                                <?php } ?>

                            </td>



                            <!-- VEHICLE -->

                            <td>

                                <strong>

                                    <?php
                                    echo htmlspecialchars($row['name']);
                                    ?>

                                </strong>

                            </td>



                            <!-- YEAR -->

                            <td>

                                <?php
                                echo htmlspecialchars($row['year']);
                                ?>

                            </td>



                            <!-- TRANSMISSION -->

                            <td>

                                <?php
                                echo htmlspecialchars($row['transmission']);
                                ?>

                            </td>



                            <!-- FUEL -->

                            <td>

                                <?php
                                echo htmlspecialchars($row['fuel']);
                                ?>

                            </td>



                            <!-- MILEAGE -->

                            <td>

                                <?php
                                echo htmlspecialchars($row['mileage']);
                                ?>

                            </td>



                            <!-- CC -->

                            <td>

                                <?php
                                echo htmlspecialchars($row['engine_capacity']);
                                ?>

                            </td>



                            <!-- PRICE -->

                            <td>

                                <?php
                                echo number_format(
                                    (int)$row['price']
                                );
                                ?>

                            </td>



                            <!-- ACTION -->

                            <td class="text-end">

                                <!-- VIEW -->

                                <a
                                    class="btn btn-primary btn-sm"
                                    href="inventory-details.php?id=<?php echo (int)$row['id']; ?>"
                                    title="View Vehicle"
                                >

                                    <i class="bi bi-eye"></i>

                                </a>


                                <!-- EDIT -->

                                <a
                                    class="btn btn-light btn-sm"
                                    href="edit-inventory.php?id=<?php echo (int)$row['id']; ?>"
                                    title="Edit Vehicle"
                                >

                                    <i class="bi bi-pencil"></i>

                                </a>


                                <!-- DELETE -->

                                <button
                                    class="btn btn-danger btn-sm"
                                    onclick="confirmDelete(<?php echo (int)$row['id']; ?>)"
                                    title="Delete Vehicle"
                                >

                                    <i class="bi bi-trash"></i>

                                </button>

                            </td>

                        </tr>


                    <?php } ?>

                <?php } else { ?>

                    <tr>

                        <td
                            colspan="10"
                            class="text-center py-5 text-muted"
                        >

                            <i
                                class="bi bi-car-front fs-2 d-block mb-2"
                            ></i>

                            No vehicles found.

                        </td>

                    </tr>

                <?php } ?>

            </tbody>

        </table>

    </div>



    <!-- =========================
         PAGINATION
    ========================= -->

    <?php if ($total_pages > 1) { ?>

        <nav class="mt-3">

            <ul class="pagination justify-content-center">


                <!-- PREVIOUS -->

                <?php if ($page > 1) { ?>

                    <li class="page-item">

                        <a
                            class="page-link"
                            href="view-inventory.php?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>"
                        >

                            Previous

                        </a>

                    </li>

                <?php } ?>



                <!-- PAGE NUMBERS -->

                <?php for ($i = 1; $i <= $total_pages; $i++) { ?>

                    <li
                        class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>"
                    >

                        <a
                            class="page-link"
                            href="view-inventory.php?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"
                        >

                            <?php echo $i; ?>

                        </a>

                    </li>

                <?php } ?>



                <!-- NEXT -->

                <?php if ($page < $total_pages) { ?>

                    <li class="page-item">

                        <a
                            class="page-link"
                            href="view-inventory.php?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>"
                        >

                            Next

                        </a>

                    </li>

                <?php } ?>


            </ul>

        </nav>

    <?php } ?>



    <!-- RECORD COUNT -->

    <div class="text-center text-muted mt-2">

        <?php

        $showing = min(
            $limit,
            max(0, $total_records - $offset)
        );

        ?>

        Showing
        <?php echo $showing; ?>
        of
        <?php echo $total_records; ?>
        records

    </div>

</section>



<?php include 'footer.php'; ?>


<!-- =========================
     SWEETALERT
========================= -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>

$(document).ready(function() {

    $('#searchInput').on('keyup', function() {

        var searchValue = $(this).val();

        window.location.href =
            'view-inventory.php?search=' +
            encodeURIComponent(searchValue);

    });

});



/*
 * Delete Confirmation
 */

function confirmDelete(id) {

    Swal.fire({

        title: 'Are you sure?',

        text: 'You won\'t be able to revert this!',

        icon: 'warning',

        showCancelButton: true,

        confirmButtonColor: '#d33',

        cancelButtonColor: '#3085d6',

        confirmButtonText: 'Yes, delete it!',

        cancelButtonText: 'Cancel'

    }).then((result) => {

        if (result.isConfirmed) {

            window.location.href =
                'view-inventory.php?delete=' + id;

        }

    });

}

</script>