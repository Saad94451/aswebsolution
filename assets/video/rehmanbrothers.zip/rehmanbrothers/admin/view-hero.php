<?php

error_reporting(E_ALL);
ini_set('display_errors', 1);

include '../config.php';

$message = '';
$error = '';

/*
|--------------------------------------------------------------------------
| SAVE REORDER
|--------------------------------------------------------------------------
*/

if (isset($_POST['save_order'])) {

    $order = isset($_POST['order'])
        ? json_decode($_POST['order'], true)
        : [];

    if (is_array($order) && !empty($order)) {

        $success = true;

        foreach ($order as $position => $slide_id) {

            $slide_id = (int)$slide_id;
            $sort_order = $position + 1;

            if ($slide_id <= 0) {
                continue;
            }

            $update_order = mysqli_query(
                $conn,
                "UPDATE hero_slides
                 SET sort_order = '$sort_order'
                 WHERE id = '$slide_id'"
            );

            if (!$update_order) {
                $success = false;
            }
        }

        if ($success) {

            $message = "Hero slides reordered successfully.";

        } else {

            $error = "Failed to save slide order.";

        }
    }
}


/*
|--------------------------------------------------------------------------
| UPDATE HERO SLIDE
|--------------------------------------------------------------------------
*/

if (isset($_POST['update_slide'])) {

    $id = isset($_POST['slide_id'])
        ? (int)$_POST['slide_id']
        : 0;

    if ($id <= 0) {

        $error = "Invalid slide ID.";

    } else {

        /*
        Get current slide
        */

        $result = mysqli_query(
            $conn,
            "SELECT * FROM hero_slides
             WHERE id = '$id'
             LIMIT 1"
        );

        if (!$result || mysqli_num_rows($result) === 0) {

            $error = "Hero slide not found.";

        } else {

            $slide = mysqli_fetch_assoc($result);

            /*
            Alt text
            */

            $alt_text = isset($_POST['alt_text'])
                ? trim($_POST['alt_text'])
                : '';

            $alt_text = mysqli_real_escape_string(
                $conn,
                $alt_text
            );

            /*
            Current image
            */

            $image_name = $slide['image'];


            /*
            |--------------------------------------------------------------------------
            | NEW IMAGE
            |--------------------------------------------------------------------------
            */

            if (
                isset($_FILES['image']) &&
                $_FILES['image']['error'] !== UPLOAD_ERR_NO_FILE
            ) {

                if ($_FILES['image']['error'] !== UPLOAD_ERR_OK) {

                    $error = "There was a problem uploading the image.";

                } else {

                    $allowed = [
                        'jpg',
                        'jpeg',
                        'png',
                        'webp'
                    ];

                    $extension = strtolower(
                        pathinfo(
                            $_FILES['image']['name'],
                            PATHINFO_EXTENSION
                        )
                    );


                    /*
                    Check extension
                    */

                    if (!in_array($extension, $allowed, true)) {

                        $error =
                            "Only JPG, JPEG, PNG and WEBP images are allowed.";

                    } else {

                        /*
                        Check actual image
                        */

                        $image_info = getimagesize(
                            $_FILES['image']['tmp_name']
                        );

                        if ($image_info === false) {

                            $error =
                                "The selected file is not a valid image.";

                        } else {

                            /*
                            New filename
                            */

                            $new_name =
                                'hero_' .
                                time() .
                                '_' .
                                uniqid() .
                                '.' .
                                $extension;


                            $upload_path =
                                '../uploads/' . $new_name;


                            /*
                            Upload
                            */

                            if (
                                move_uploaded_file(
                                    $_FILES['image']['tmp_name'],
                                    $upload_path
                                )
                            ) {

                                /*
                                Delete old image
                                */

                                if (
                                    !empty($slide['image']) &&
                                    file_exists(
                                        '../uploads/' . $slide['image']
                                    )
                                ) {

                                    unlink(
                                        '../uploads/' . $slide['image']
                                    );
                                }


                                $image_name = $new_name;

                            } else {

                                $error =
                                    "Failed to upload the new image.";

                            }
                        }
                    }
                }
            }


            /*
            |--------------------------------------------------------------------------
            | UPDATE DATABASE
            |--------------------------------------------------------------------------
            */

            if (empty($error)) {

                $image_name = mysqli_real_escape_string(
                    $conn,
                    $image_name
                );

                $update = mysqli_query(
                    $conn,
                    "UPDATE hero_slides
                     SET
                        image = '$image_name',
                        alt_text = '$alt_text'
                     WHERE id = '$id'"
                );


                if ($update) {

                    $message =
                        "Hero slide updated successfully.";

                } else {

                    $error =
                        "Failed to update hero slide.";

                }
            }
        }
    }
}


/*
|--------------------------------------------------------------------------
| GET HERO SLIDES
|--------------------------------------------------------------------------
*/

$query = mysqli_query(
    $conn,
    "SELECT *
     FROM hero_slides
     ORDER BY sort_order ASC, id ASC
     LIMIT 3"
);

$slides = [];

if ($query) {

    while ($row = mysqli_fetch_assoc($query)) {

        $slides[] = $row;
    }
}


/*
|--------------------------------------------------------------------------
| HEADER
|--------------------------------------------------------------------------
*/

include 'header.php';

?>


<div class="page-heading">

    <div class="page-heading-copy">

        <span class="page-icon">

            <i class="bi bi-images"></i>

        </span>

        <div>

            <p class="eyebrow mb-1">
                Homepage
            </p>

            <h1 class="h3 mb-1">
                Hero Slides
            </h1>

            <p class="text-muted mb-0">
                Manage homepage hero images and their order
            </p>

        </div>

    </div>

</div>


<section class="panel">

    <div class="panel-header d-flex justify-content-between align-items-center">

        <div>

            <h2 class="h5 mb-1">

                <i class="bi bi-image me-2"></i>

                Homepage Hero Images

            </h2>

            <p class="text-muted mb-0">

                Drag and drop the images to change their order.

            </p>

        </div>

        <span class="badge bg-primary">

            <?php echo count($slides); ?> Slides

        </span>

    </div>


    <div class="p-4">


        <?php if (empty($slides)) { ?>

            <div class="text-center py-5">

                <i
                    class="bi bi-images"
                    style="font-size:50px; opacity:.4;"
                ></i>

                <h5 class="mt-3">
                    No hero slides found
                </h5>

            </div>

        <?php } else { ?>


            <!-- HERO SLIDES -->

            <div
                id="heroSlidesContainer"
                class="hero-slides-container"
            >

                <?php foreach ($slides as $index => $slide) { ?>

                    <div
                        class="hero-slide-item"
                        data-id="<?php echo (int)$slide['id']; ?>"
                    >


                        <!-- DRAG -->

                        <div class="hero-drag-handle">

                            <i class="bi bi-grip-vertical"></i>

                        </div>


                        <!-- ORDER -->

                        <div class="hero-order">

                            <span>

                                #<?php echo $index + 1; ?>

                            </span>

                        </div>


                        <!-- IMAGE -->

                        <div class="hero-image">

                            <img
                                src="../uploads/<?php echo htmlspecialchars($slide['image']); ?>"
                                alt="<?php echo htmlspecialchars($slide['alt_text'] ?? ''); ?>"
                            >

                        </div>


                        <!-- INFO -->

                        <div class="hero-info">

                            <h5>
                                Hero Slide #<?php echo $index + 1; ?>
                            </h5>

                            <p class="text-muted mb-1">

                                <strong>Image:</strong>

                                <?php
                                echo htmlspecialchars(
                                    $slide['image']
                                );
                                ?>

                            </p>

                            <p class="text-muted mb-0">

                                <strong>Alt:</strong>

                                <?php

                                if (!empty($slide['alt_text'])) {

                                    echo htmlspecialchars(
                                        $slide['alt_text']
                                    );

                                } else {

                                    echo 'No alt text';

                                }

                                ?>

                            </p>

                        </div>


                        <!-- EDIT -->

                        <div class="hero-actions">

                            <button
                                type="button"
                                class="btn btn-primary edit-hero-btn"
                                data-id="<?php echo (int)$slide['id']; ?>"
                                data-image="<?php echo htmlspecialchars($slide['image'], ENT_QUOTES); ?>"
                                data-alt="<?php echo htmlspecialchars($slide['alt_text'] ?? '', ENT_QUOTES); ?>"
                            >

                                <i class="bi bi-pencil me-1"></i>

                                Edit

                            </button>

                        </div>


                    </div>

                <?php } ?>

            </div>


            <!-- SAVE ORDER -->

            <form
                method="POST"
                id="orderForm"
                class="mt-4"
            >

                <input
                    type="hidden"
                    name="order"
                    id="heroOrder"
                    value=""
                >

                <button
                    type="submit"
                    name="save_order"
                    class="btn btn-primary"
                    id="saveOrderBtn"
                >

                    <i class="bi bi-check-circle me-1"></i>

                    Save Order

                </button>

            </form>


        <?php } ?>

    </div>

</section>



<!--
|--------------------------------------------------------------------------
| EDIT MODAL
|--------------------------------------------------------------------------
-->

<div
    class="modal fade"
    id="editHeroModal"
    tabindex="-1"
    aria-hidden="true"
>

    <div class="modal-dialog modal-lg modal-dialog-centered">

        <div class="modal-content">


            <form
                method="POST"
                enctype="multipart/form-data"
                id="editHeroForm"
            >

                <div class="modal-header">

                    <h5 class="modal-title">

                        <i class="bi bi-pencil me-2"></i>

                        Edit Hero Slide

                    </h5>

                    <button
                        type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                    ></button>

                </div>


                <div class="modal-body">


                    <input
                        type="hidden"
                        name="slide_id"
                        id="editSlideId"
                    >


                    <!-- CURRENT IMAGE -->

                    <div class="mb-4">

                        <label class="form-label fw-semibold">

                            Current Image

                        </label>

                        <div>

                            <img
                                id="currentHeroImage"
                                src=""
                                alt="Current Hero"
                                class="hero-modal-image"
                            >

                        </div>

                    </div>


                    <!-- CHANGE IMAGE -->

                    <div class="mb-4">

                        <label
                            for="editHeroImage"
                            class="form-label fw-semibold"
                        >

                            Change Image

                        </label>

                        <input
                            type="file"
                            name="image"
                            id="editHeroImage"
                            class="form-control"
                            accept=".jpg,.jpeg,.png,.webp"
                        >

                        <small class="text-muted">

                            JPG, JPEG, PNG or WEBP only.

                        </small>

                    </div>


                    <!-- PREVIEW -->

                    <div
                        id="newImagePreviewContainer"
                        class="mb-4"
                        style="display:none;"
                    >

                        <label class="form-label fw-semibold">

                            New Image Preview

                        </label>

                        <div>

                            <img
                                id="newHeroImagePreview"
                                src=""
                                alt="New Image Preview"
                                class="hero-modal-image"
                            >

                        </div>

                    </div>


                    <!-- ALT TEXT -->

                    <div class="mb-3">

                        <label
                            for="editAltText"
                            class="form-label fw-semibold"
                        >

                            Image Alt Text

                        </label>

                        <input
                            type="text"
                            name="alt_text"
                            id="editAltText"
                            class="form-control"
                            placeholder="Japanese car dealership"
                        >

                    </div>


                </div>


                <div class="modal-footer">

                    <button
                        type="button"
                        class="btn btn-light"
                        data-bs-dismiss="modal"
                    >

                        Cancel

                    </button>


                    <button
                        type="submit"
                        name="update_slide"
                        class="btn btn-primary"
                    >

                        <i class="bi bi-check-circle me-1"></i>

                        Update Image

                    </button>

                </div>


            </form>

        </div>

    </div>

</div>



<style>

/* HERO CONTAINER */

.hero-slides-container {

    display: flex;

    flex-direction: column;

    gap: 15px;

}


/* HERO ITEM */

.hero-slide-item {

    display: flex;

    align-items: center;

    gap: 18px;

    padding: 16px;

    background: #fff;

    border: 1px solid #e5e7eb;

    border-radius: 12px;

    transition: .2s ease;

}


.hero-slide-item:hover {

    box-shadow:
        0 5px 18px rgba(0, 0, 0, .06);

}


/* DRAG */

.hero-drag-handle {

    width: 35px;

    text-align: center;

    font-size: 24px;

    color: #9ca3af;

    cursor: grab;

}


.hero-drag-handle:active {

    cursor: grabbing;

}


/* ORDER */

.hero-order {

    width: 45px;

    text-align: center;

    font-weight: 600;

}


.hero-order span {

    display: inline-flex;

    align-items: center;

    justify-content: center;

    width: 40px;

    height: 40px;

    background: #f3f4f6;

    border-radius: 50%;

}


/* IMAGE */

.hero-image {

    width: 220px;

    flex-shrink: 0;

}


.hero-image img {

    width: 220px;

    height: 120px;

    object-fit: cover;

    border-radius: 10px;

    border: 1px solid #e5e7eb;

}


/* INFO */

.hero-info {

    flex: 1;

    min-width: 0;

}


.hero-info h5 {

    margin-bottom: 8px;

}


.hero-info p {

    font-size: 14px;

    word-break: break-word;

}


/* ACTION */

.hero-actions {

    flex-shrink: 0;

}


/* MODAL IMAGE */

.hero-modal-image {

    width: 100%;

    max-width: 650px;

    height: 300px;

    object-fit: cover;

    border-radius: 12px;

    border: 1px solid #e5e7eb;

}


/* SORTABLE */

.hero-slide-ghost {

    opacity: .45;

    background: #f3f4f6;

}


/* MOBILE */

@media (max-width: 768px) {

    .hero-slide-item {

        flex-wrap: wrap;

    }


    .hero-image {

        width: 100%;

    }


    .hero-image img {

        width: 100%;

        height: 200px;

    }


    .hero-info {

        width: 100%;

    }


    .hero-actions {

        width: 100%;

    }


    .hero-actions .btn {

        width: 100%;

    }

}

</style>



<?php include 'footer.php'; ?>


<!-- SORTABLE JS -->

<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.6/Sortable.min.js"></script>


<script>

document.addEventListener(
    "DOMContentLoaded",
    function () {


        /*
        |--------------------------------------------------------------------------
        | SWEETALERT MESSAGES
        |--------------------------------------------------------------------------
        */

        <?php if (!empty($message)) { ?>

        Swal.fire({

            icon: "success",

            title: "Success!",

            text: <?php echo json_encode($message); ?>,

            confirmButtonText: "OK"

        });

        <?php } ?>


        <?php if (!empty($error)) { ?>

        Swal.fire({

            icon: "error",

            title: "Error!",

            text: <?php echo json_encode($error); ?>,

            confirmButtonText: "OK"

        });

        <?php } ?>


        /*
        |--------------------------------------------------------------------------
        | SORTABLE
        |--------------------------------------------------------------------------
        */

        const container =
            document.getElementById(
                "heroSlidesContainer"
            );

        const orderInput =
            document.getElementById(
                "heroOrder"
            );

        const orderForm =
            document.getElementById(
                "orderForm"
            );


        if (container && orderInput) {


            new Sortable(
                container,
                {

                    animation: 200,

                    handle: ".hero-drag-handle",

                    ghostClass:
                        "hero-slide-ghost",

                    onEnd: function () {

                        updateOrder();

                    }

                }
            );


            function updateOrder() {

                const items =
                    container.querySelectorAll(
                        ".hero-slide-item"
                    );

                const ids = [];


                items.forEach(
                    function (item, index) {

                        ids.push(
                            item.dataset.id
                        );


                        const orderNumber =
                            item.querySelector(
                                ".hero-order span"
                            );


                        if (orderNumber) {

                            orderNumber.textContent =
                                "#" + (index + 1);

                        }

                    }
                );


                orderInput.value =
                    JSON.stringify(ids);

            }


            updateOrder();


            /*
            SAVE ORDER CONFIRMATION
            */

            if (orderForm) {

                orderForm.addEventListener(
                    "submit",
                    function (event) {

                        event.preventDefault();

                        updateOrder();


                        Swal.fire({

                            title: "Save Order?",

                            text:
                                "Do you want to save the new hero slide order?",

                            icon: "question",

                            showCancelButton: true,

                            confirmButtonText:
                                "Yes, Save It",

                            cancelButtonText:
                                "Cancel"

                        }).then(
                            function (result) {

                                if (
                                    result.isConfirmed
                                ) {

                                    orderForm.submit();

                                }

                            }
                        );

                    }
                );

            }

        }


        /*
        |--------------------------------------------------------------------------
        | EDIT MODAL
        |--------------------------------------------------------------------------
        */

        const editButtons =
            document.querySelectorAll(
                ".edit-hero-btn"
            );

        const editModalElement =
            document.getElementById(
                "editHeroModal"
            );


        if (
            editButtons.length &&
            editModalElement &&
            typeof bootstrap !== "undefined"
        ) {


            const editModal =
                new bootstrap.Modal(
                    editModalElement
                );


            const slideId =
                document.getElementById(
                    "editSlideId"
                );


            const currentImage =
                document.getElementById(
                    "currentHeroImage"
                );


            const altText =
                document.getElementById(
                    "editAltText"
                );


            const imageInput =
                document.getElementById(
                    "editHeroImage"
                );


            const previewContainer =
                document.getElementById(
                    "newImagePreviewContainer"
                );


            const previewImage =
                document.getElementById(
                    "newHeroImagePreview"
                );


            /*
            EDIT BUTTON
            */

            editButtons.forEach(
                function (button) {

                    button.addEventListener(
                        "click",
                        function () {


                            const id =
                                this.dataset.id;


                            const image =
                                this.dataset.image;


                            const alt =
                                this.dataset.alt;


                            slideId.value =
                                id;


                            currentImage.src =
                                "../uploads/" +
                                image;


                            altText.value =
                                alt || "";


                            imageInput.value =
                                "";


                            previewContainer.style.display =
                                "none";


                            previewImage.src =
                                "";


                            editModal.show();

                        }
                    );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | IMAGE PREVIEW
            |--------------------------------------------------------------------------
            */

            imageInput.addEventListener(
                "change",
                function () {


                    const file =
                        this.files[0];


                    if (!file) {

                        previewContainer.style.display =
                            "none";

                        previewImage.src =
                            "";

                        return;

                    }


                    const allowedTypes = [

                        "image/jpeg",

                        "image/png",

                        "image/webp"

                    ];


                    if (
                        !allowedTypes.includes(
                            file.type
                        )
                    ) {


                        Swal.fire({

                            icon: "error",

                            title: "Invalid Image",

                            text:
                                "Please select a JPG, JPEG, PNG or WEBP image.",

                            confirmButtonText:
                                "OK"

                        });


                        this.value = "";


                        previewContainer.style.display =
                            "none";


                        previewImage.src =
                            "";


                        return;

                    }


                    /*
                    File size check
                    */

                    const maxSize =
                        10 * 1024 * 1024;


                    if (file.size > maxSize) {


                        Swal.fire({

                            icon: "error",

                            title: "Image Too Large",

                            text:
                                "Image size must be less than 10 MB.",

                            confirmButtonText:
                                "OK"

                        });


                        this.value = "";


                        previewContainer.style.display =
                            "none";


                        previewImage.src =
                            "";


                        return;

                    }


                    /*
                    PREVIEW
                    */

                    const reader =
                        new FileReader();


                    reader.onload =
                        function (e) {


                            previewImage.src =
                                e.target.result;


                            previewContainer.style.display =
                                "block";

                        };


                    reader.readAsDataURL(
                        file
                    );

                }
            );


            /*
            |--------------------------------------------------------------------------
            | UPDATE CONFIRMATION
            |--------------------------------------------------------------------------
            */

            const editForm =
                document.getElementById(
                    "editHeroForm"
                );


            if (editForm) {

                editForm.addEventListener(
                    "submit",
                    function (event) {

                        event.preventDefault();


                        Swal.fire({

                            title: "Update Hero Image?",

                            text:
                                "The current image will be replaced if you selected a new image.",

                            icon: "question",

                            showCancelButton: true,

                            confirmButtonText:
                                "Yes, Update",

                            cancelButtonText:
                                "Cancel"

                        }).then(
                            function (result) {

                                if (
                                    result.isConfirmed
                                ) {

                                    editForm.submit();

                                }

                            }
                        );

                    }
                );

            }

        }

    }
);

</script>