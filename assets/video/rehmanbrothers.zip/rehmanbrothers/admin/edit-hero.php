<?php include 'header.php'; ?>
<?php
include '../config.php';

$id = mysqli_real_escape_string($conn, $_GET['id']);
$query = mysqli_query($conn, "SELECT * FROM blogs WHERE id = '$id'");
$row = mysqli_fetch_assoc($query);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $category_id = mysqli_real_escape_string($conn, trim($_POST['category_id']));
  $title = mysqli_real_escape_string($conn, trim($_POST['title']));
  $slug = mysqli_real_escape_string($conn, trim($_POST['slug']));
  $description = mysqli_real_escape_string($conn, trim($_POST['description']));
  $author_name = mysqli_real_escape_string($conn, trim($_POST['author_name']));
  $author_designation = mysqli_real_escape_string($conn, trim($_POST['author_designation']));
  $read_time = mysqli_real_escape_string($conn, trim($_POST['read_time']));
  $created_at = mysqli_real_escape_string($conn, trim($_POST['created_at']));
  
  $target_dir = "../uploads/blogs/";
  $author_target = "../uploads/authors/";
  
  // Blog image upload if new image provided
  if ($_FILES['blog_image']['name'] != '') {
    $blog_image = $_FILES['blog_image']['name'];
    $target_file = $target_dir . basename($blog_image);
    move_uploaded_file($_FILES['blog_image']['tmp_name'], $target_file);
    
    $update = mysqli_query($conn, "
      UPDATE blogs SET category_id='$category_id', title='$title', slug='$slug', description='$description', blog_image='$blog_image', author_name='$author_name', author_designation='$author_designation', read_time='$read_time', created_at='$created_at' WHERE id='$id'
    ");
  } else {
    $update = mysqli_query($conn, "
      UPDATE blogs SET category_id='$category_id', title='$title', slug='$slug', description='$description', author_name='$author_name', author_designation='$author_designation', read_time='$read_time', created_at='$created_at' WHERE id='$id'
    ");
  }
  
  // Author image upload if new image provided
  if ($_FILES['author_image']['name'] != '') {
    $author_image = $_FILES['author_image']['name'];
    $author_file = $author_target . basename($author_image);
    move_uploaded_file($_FILES['author_image']['tmp_name'], $author_file);
    
    $update = mysqli_query($conn, "
      UPDATE blogs SET author_image='$author_image' WHERE id='$id'
    ");
  }
  
  if ($update) {
    echo "<script>
      Swal.fire({
        icon: 'success',
        title: 'Updated!',
        text: 'Blog updated successfully',
        timer: 1500,
        showConfirmButton: false
      }).then(() => {
        window.location.href = 'view-blogs.php';
      });
    </script>";
  } else {
    echo "<script>
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Failed to update blog'
      });
    </script>";
  }
}
?>

<div class="page-heading">
  <div class="page-heading-copy">
    <span class="page-icon"><i class="bi bi-journal-text" aria-hidden="true"></i></span>
    <div>
      <p class="eyebrow mb-1">Blog</p>
      <h1 class="h3 mb-1">Edit Blog</h1>
      <p class="text-muted mb-0">Update blog post</p>
    </div>
  </div>
</div>

<section class="panel">
  <div class="panel-header">
    <div>
      <h2 class="h5 mb-1 section-title"><i class="bi bi-pencil" aria-hidden="true"></i><span>Edit Blog Post</span></h2>
      <p class="text-muted mb-0">Update the details below</p>
    </div>
  </div>
  <form method="POST" enctype="multipart/form-data">
    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label">Category</label>
        <select class="form-select" name="category_id" required>
          <option value="">Select Category</option>
          <?php
          $categories = mysqli_query($conn, "SELECT * FROM blog_categories ORDER BY category_name ASC");
          while($cat = mysqli_fetch_assoc($categories)) {
          ?>
          <option value="<?php echo $cat['id']; ?>" <?php echo $row['category_id'] == $cat['id'] ? 'selected' : ''; ?>><?php echo $cat['category_name']; ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Title</label>
        <input type="text" class="form-control" name="title" value="<?php echo $row['title']; ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Slug</label>
        <input type="text" class="form-control" name="slug" value="<?php echo $row['slug']; ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Read Time</label>
        <input type="text" class="form-control" name="read_time" value="<?php echo $row['read_time']; ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Author Name</label>
        <input type="text" class="form-control" name="author_name" value="<?php echo $row['author_name']; ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Author Designation</label>
        <input type="text" class="form-control" name="author_designation" value="<?php echo $row['author_designation']; ?>" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Created Date</label>
        <input type="date" class="form-control" name="created_at" value="<?php echo $row['created_at']; ?>" required>
      </div>
      <div class="col-12">
        <label class="form-label">Description</label>
        <textarea class="form-control" name="description" rows="5" required><?php echo $row['description']; ?></textarea>
      </div>
      <div class="col-md-6">
        <label class="form-label">Current Blog Image</label>
        <img src="<?php echo $row['blog_image']; ?>" alt="Current" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px;">
      </div>
      <div class="col-md-6">
        <label class="form-label">New Blog Image (leave blank to keep current)</label>
        <input type="file" class="form-control" name="blog_image">
      </div>
      <div class="col-md-6">
        <label class="form-label">Current Author Image</label>
        <img src="<?php echo $row['author_image']; ?>" alt="Current" style="width: 100px; height: 100px; object-fit: cover; border-radius: 8px;">
      </div>
      <div class="col-md-6">
        <label class="form-label">New Author Image (leave blank to keep current)</label>
        <input type="file" class="form-control" name="author_image">
      </div>
      <div class="col-12">
        <button type="submit" class="btn btn-primary">
          <i class="bi bi-check-circle"></i> Update Blog
        </button>
        <a href="view-blogs.php" class="btn btn-secondary">Cancel</a>
      </div>
    </div>
  </form>
</section>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
