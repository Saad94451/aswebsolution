<?php
include 'header.php';
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    // ==========================================
    // FORM DATA
    // ==========================================

    $name = mysqli_real_escape_string($conn, trim($_POST['name'] ?? ''));
    $year = mysqli_real_escape_string($conn, trim($_POST['year'] ?? ''));
    $transmission = mysqli_real_escape_string($conn, trim($_POST['transmission'] ?? ''));
    $fuel = mysqli_real_escape_string($conn, trim($_POST['fuel'] ?? ''));
    $mileage = mysqli_real_escape_string($conn, trim($_POST['mileage'] ?? ''));
    $price = mysqli_real_escape_string($conn, trim($_POST['price'] ?? ''));
    $chassis_number = mysqli_real_escape_string($conn, trim($_POST['chassis_number'] ?? ''));
    $engine = mysqli_real_escape_string($conn, trim($_POST['engine'] ?? ''));
    $color = mysqli_real_escape_string($conn, trim($_POST['color'] ?? ''));
    $seats = mysqli_real_escape_string($conn, trim($_POST['seats'] ?? ''));
    $conditions = mysqli_real_escape_string($conn, trim($_POST['conditions'] ?? ''));
    $description = mysqli_real_escape_string($conn, trim($_POST['description'] ?? ''));
    $engine_capacity = mysqli_real_escape_string($conn, trim($_POST['engine_capacity'] ?? ''));


    // ==========================================
    // IMAGE UPLOAD
    // ==========================================

    $uploaded_images = [];

    $upload_dir = "../uploads/";

    if (!is_dir($upload_dir)) {
        mkdir($upload_dir, 0777, true);
    }

    if (isset($_FILES['vehicle_images'])) {

        $total_images = count($_FILES['vehicle_images']['name']);

        for ($i = 0; $i < $total_images && count($uploaded_images) < 10; $i++) {

            if (
                $_FILES['vehicle_images']['error'][$i] === UPLOAD_ERR_OK &&
                !empty($_FILES['vehicle_images']['name'][$i])
            ) {

                $original_name = $_FILES['vehicle_images']['name'][$i];
                $tmp_name = $_FILES['vehicle_images']['tmp_name'][$i];

                $extension = strtolower(
                    pathinfo($original_name, PATHINFO_EXTENSION)
                );

                $allowed_extensions = [
                    'jpg',
                    'jpeg',
                    'png',
                    'webp'
                ];

                if (in_array($extension, $allowed_extensions)) {

                    $new_name =
                        'vehicle_' .
                        time() .
                        '_' .
                        uniqid() .
                        '.' .
                        $extension;

                    $target_file = $upload_dir . $new_name;

                    if (move_uploaded_file($tmp_name, $target_file)) {
                        $uploaded_images[] = $new_name;
                    }
                }
            }
        }
    }


    // ==========================================
    // CHECK IMAGE
    // ==========================================

    if (empty($uploaded_images)) {

        echo "
        <script>
            Swal.fire({
                icon: 'error',
                title: 'No Images',
                text: 'Please upload at least one vehicle image.'
            });
        </script>
        ";

    } else {

        // ==========================================
        // IMG_1 - IMG_10
        // ==========================================

        $img_1 = $uploaded_images[0] ?? '';
        $img_2 = $uploaded_images[1] ?? '';
        $img_3 = $uploaded_images[2] ?? '';
        $img_4 = $uploaded_images[3] ?? '';
        $img_5 = $uploaded_images[4] ?? '';
        $img_6 = $uploaded_images[5] ?? '';
        $img_7 = $uploaded_images[6] ?? '';
        $img_8 = $uploaded_images[7] ?? '';
        $img_9 = $uploaded_images[8] ?? '';
        $img_10 = $uploaded_images[9] ?? '';


        // Escape image names

        $img_1 = mysqli_real_escape_string($conn, $img_1);
        $img_2 = mysqli_real_escape_string($conn, $img_2);
        $img_3 = mysqli_real_escape_string($conn, $img_3);
        $img_4 = mysqli_real_escape_string($conn, $img_4);
        $img_5 = mysqli_real_escape_string($conn, $img_5);
        $img_6 = mysqli_real_escape_string($conn, $img_6);
        $img_7 = mysqli_real_escape_string($conn, $img_7);
        $img_8 = mysqli_real_escape_string($conn, $img_8);
        $img_9 = mysqli_real_escape_string($conn, $img_9);
        $img_10 = mysqli_real_escape_string($conn, $img_10);


        // ==========================================
        // INSERT
        // ==========================================

        $insert = mysqli_query(
            $conn,
            "
            INSERT INTO inventory
            (
                name,
                year,
                transmission,
                fuel,
                mileage,
                price,
                chassis_number,
                engine,
                color,
                seats,
                conditions,
                description,
                img_1,
                img_2,
                img_3,
                img_4,
                img_5,
                img_6,
                img_7,
                img_8,
                img_9,
                img_10,
                engine_capacity
            )
            VALUES
            (
                '$name',
                '$year',
                '$transmission',
                '$fuel',
                '$mileage',
                '$price',
                '$chassis_number',
                '$engine',
                '$color',
                '$seats',
                '$conditions',
                '$description',
                '$img_1',
                '$img_2',
                '$img_3',
                '$img_4',
                '$img_5',
                '$img_6',
                '$img_7',
                '$img_8',
                '$img_9',
                '$img_10',
                '$engine_capacity'
            )
            "
        );


        // ==========================================
        // SUCCESS
        // ==========================================

        if ($insert) {

            echo "
            <script>
                Swal.fire({
                    icon: 'success',
                    title: 'Vehicle Created!',
                    text: 'Vehicle has been added to inventory successfully.',
                    timer: 1800,
                    showConfirmButton: false
                }).then(function() {
                    window.location.href = 'view-inventory.php';
                });
            </script>
            ";

        } else {

            echo "
            <script>
                Swal.fire({
                    icon: 'error',
                    title: 'Database Error',
                    text: 'Failed to create vehicle. Please try again.'
                });
            </script>
            ";
        }
    }
}
?>


<!-- ==========================================
     PAGE HEADING
========================================== -->

<div class="page-heading">

    <div class="page-heading-copy">

        <span class="page-icon">
            <i class="bi bi-car-front-fill" aria-hidden="true"></i>
        </span>

        <div>

            <p class="eyebrow mb-1">
                Inventory
            </p>

            <h1 class="h3 mb-1">
                Create Inventory
            </h1>

            <p class="text-muted mb-0">
                Add a new vehicle to inventory
            </p>

        </div>

    </div>

</div>


<!-- ==========================================
     FORM
========================================== -->

<section class="panel">

    <div class="panel-header">

        <div>

            <h2 class="h5 mb-1 section-title">

                <i class="bi bi-plus-circle"></i>

                <span>
                    New Vehicle
                </span>

            </h2>

            <p class="text-muted mb-0">
                Fill in the vehicle details below
            </p>

        </div>

    </div>


    <form
        method="POST"
        enctype="multipart/form-data"
        id="inventoryForm"
    >

        <div class="row g-3">


            <!-- Vehicle Name -->

            <div class="col-md-6">

                <label class="form-label">
                    Vehicle Name
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="name"
                    placeholder="e.g. Toyota Corolla"
                    required
                >

            </div>


            <!-- Year -->

            <div class="col-md-3">

                <label class="form-label">
                    Year
                </label>

                <input
                    type="number"
                    class="form-control"
                    name="year"
                    placeholder="2022"
                    min="1900"
                    max="2100"
                    required
                >

            </div>


            <!-- Condition -->

            <div class="col-md-3">

                <label class="form-label">
                    Condition
                </label>

                <select
                    class="form-select"
                    name="conditions"
                    required
                >

                    <option value="">
                        Select Condition
                    </option>

                    <option value="New">
                        New
                    </option>

                    <option value="Used">
                        Used
                    </option>

                    <option value="Excellent">
                        Excellent
                    </option>

                    <option value="Good">
                        Good
                    </option>

                </select>

            </div>


            <!-- Transmission -->

            <div class="col-md-4">

                <label class="form-label">
                    Transmission
                </label>

                <select
                    class="form-select"
                    name="transmission"
                    required
                >

                    <option value="">
                        Select Transmission
                    </option>

                    <option value="Automatic">
                        Automatic
                    </option>

                    <option value="Manual">
                        Manual
                    </option>

                    <option value="CVT">
                        CVT
                    </option>

                </select>

            </div>


            <!-- Fuel -->

            <div class="col-md-4">

                <label class="form-label">
                    Fuel
                </label>

                <select
                    class="form-select"
                    name="fuel"
                    required
                >

                    <option value="">
                        Select Fuel
                    </option>

                    <option value="Petrol">
                        Petrol
                    </option>

                    <option value="Diesel">
                        Diesel
                    </option>

                    <option value="Hybrid">
                        Hybrid
                    </option>

                    <option value="Electric">
                        Electric
                    </option>

                </select>

            </div>


            <!-- Mileage -->

            <div class="col-md-4">

                <label class="form-label">
                    Mileage
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="mileage"
                    placeholder="e.g. 45,000 km"
                    required
                >

            </div>


            <!-- Engine Capacity -->

            <div class="col-md-4">

                <label class="form-label">
                    Engine Capacity / CC
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="engine_capacity"
                    placeholder="e.g. 1300cc"
                    required
                >

            </div>


            <!-- Engine -->

            <div class="col-md-4">

                <label class="form-label">
                    Engine
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="engine"
                    placeholder="e.g. 1.3L Petrol"
                    required
                >

            </div>


            <!-- Color -->

            <div class="col-md-4">

                <label class="form-label">
                    Color
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="color"
                    placeholder="e.g. Pearl White"
                    required
                >

            </div>


            <!-- Seats -->

            <div class="col-md-4">

                <label class="form-label">
                    Seats
                </label>

                <input
                    type="number"
                    class="form-control"
                    name="seats"
                    placeholder="5"
                    min="1"
                    max="50"
                    required
                >

            </div>


            <!-- Price -->

            <div class="col-md-4">

                <label class="form-label">
                    Price
                </label>

                <input
                    type="number"
                    class="form-control"
                    name="price"
                    placeholder="e.g. 2500000"
                    min="0"
                    required
                >

            </div>


            <!-- Chassis -->

            <div class="col-md-8">

                <label class="form-label">
                    Chassis Number
                </label>

                <input
                    type="text"
                    class="form-control"
                    name="chassis_number"
                    placeholder="Enter chassis number"
                    required
                >

            </div>


            <!-- Description -->

            <div class="col-12">

                <label class="form-label">
                    Description
                </label>

                <textarea
                    class="form-control"
                    name="description"
                    rows="5"
                    placeholder="Enter vehicle description..."
                    required
                ></textarea>

            </div>


            <!-- ==================================
                 IMAGE UPLOAD
            ================================== -->

            <div class="col-12">

                <label class="form-label">
                    Vehicle Images
                </label>

                <input
                    type="file"
                    class="form-control"
                    id="vehicleImages"
                    name="vehicle_images[]"
                    multiple
                    accept="image/jpeg,image/png,image/webp"
                    required
                >

                <small class="text-muted">
                    Select 1 to 10 images. Drag images below to change their order.
                </small>


                <!-- IMAGE PREVIEW -->

                <div
                    id="imagePreview"
                    class="row g-3 mt-2"
                ></div>

            </div>


            <!-- Buttons -->

            <div class="col-12 mt-3">

                <button
                    type="submit"
                    class="btn btn-primary"
                    id="submitBtn"
                >

                    <i class="bi bi-check-circle"></i>

                    Create Vehicle

                </button>


                <a
                    href="view-inventory.php"
                    class="btn btn-secondary"
                >

                    Cancel

                </a>

            </div>

        </div>

    </form>

</section>



<!-- ==========================================
     SORTABLE JS
========================================== -->

<script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.6/Sortable.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<script>

const imageInput = document.getElementById('vehicleImages');

const imagePreview = document.getElementById('imagePreview');

let selectedFiles = [];


// ==========================================
// IMAGE SELECT
// ==========================================

imageInput.addEventListener('change', function () {

    const newFiles = Array.from(this.files);

    if (selectedFiles.length + newFiles.length > 10) {

        Swal.fire({
            icon: 'warning',
            title: 'Maximum 10 Images',
            text: 'You can upload maximum 10 images.'
        });

        return;
    }


    newFiles.forEach(function (file) {

        if (file.type.startsWith('image/')) {

            selectedFiles.push(file);

        }

    });


    renderImages();

    updateInputFiles();

});


// ==========================================
// RENDER IMAGES
// ==========================================

function renderImages() {

    imagePreview.innerHTML = '';


    selectedFiles.forEach(function (file, index) {

        const reader = new FileReader();


        reader.onload = function (event) {

            const col = document.createElement('div');

            col.className = 'col-6 col-md-4 col-lg-3';


            col.innerHTML = `

                <div
                    class="image-preview-card"
                    data-index="${index}"
                    style="
                        position:relative;
                        border:1px solid #e5e7eb;
                        border-radius:10px;
                        overflow:hidden;
                        background:#fff;
                        cursor:grab;
                    "
                >

                    <img
                        src="${event.target.result}"
                        style="
                            width:100%;
                            height:180px;
                            object-fit:cover;
                            display:block;
                        "
                    >


                    <div
                        style="
                            padding:8px 10px;
                            display:flex;
                            align-items:center;
                            justify-content:space-between;
                            gap:8px;
                        "
                    >

                        <span
                            class="image-number"
                            style="
                                font-size:13px;
                                font-weight:600;
                            "
                        >
                            ${index === 0 ? '⭐ First Image' : 'Image ' + (index + 1)}
                        </span>


                        <button
                            type="button"
                            class="remove-image btn btn-danger btn-sm"
                            data-index="${index}"
                        >

                            <i class="bi bi-trash"></i>

                        </button>

                    </div>

                </div>

            `;


            imagePreview.appendChild(col);

        };


        reader.readAsDataURL(file);

    });

}


// ==========================================
// REMOVE IMAGE
// ==========================================

imagePreview.addEventListener('click', function (e) {

    const removeButton = e.target.closest('.remove-image');

    if (!removeButton) {
        return;
    }


    const index = parseInt(
        removeButton.getAttribute('data-index')
    );


    selectedFiles.splice(index, 1);


    renderImages();

    updateInputFiles();

});


// ==========================================
// DRAG & DROP
// ==========================================

new Sortable(imagePreview, {

    animation: 200,

    ghostClass: 'sortable-ghost',

    onEnd: function () {

        const cards = Array.from(
            imagePreview.querySelectorAll('.image-preview-card')
        );


        const newOrder = [];


        cards.forEach(function (card) {

            const oldIndex = parseInt(
                card.getAttribute('data-index')
            );

            newOrder.push(
                selectedFiles[oldIndex]
            );

        });


        selectedFiles = newOrder;


        renderImages();

        updateInputFiles();

    }

});


// ==========================================
// UPDATE FILE INPUT
// ==========================================

function updateInputFiles() {

    const dataTransfer = new DataTransfer();


    selectedFiles.forEach(function (file) {

        dataTransfer.items.add(file);

    });


    imageInput.files = dataTransfer.files;


    // Required only if no image

    if (selectedFiles.length > 0) {

        imageInput.removeAttribute('required');

    } else {

        imageInput.setAttribute('required', 'required');

    }

}


// ==========================================
// FORM SUBMIT CHECK
// ==========================================

document.getElementById('inventoryForm').addEventListener(
    'submit',
    function (e) {

        if (selectedFiles.length === 0) {

            e.preventDefault();

            Swal.fire({
                icon: 'warning',
                title: 'Images Required',
                text: 'Please upload at least one vehicle image.'
            });

            return false;
        }


        if (selectedFiles.length > 10) {

            e.preventDefault();

            Swal.fire({
                icon: 'warning',
                title: 'Too Many Images',
                text: 'Maximum 10 images are allowed.'
            });

            return false;
        }

    }
);

</script>



<style>

.image-preview-card {
    transition: transform 0.2s ease, box-shadow 0.2s ease;
}

.image-preview-card:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 18px rgba(0,0,0,0.08);
}

.sortable-ghost {
    opacity: 0.4;
}

.remove-image {
    flex-shrink: 0;
}

</style>


<?php include 'footer.php'; ?>