<?php

include '../config.php';


// ==========================================
// DELETE MESSAGE
// ==========================================

if (isset($_GET['delete'])) {

    $id = (int)$_GET['delete'];

    $delete_query = mysqli_query(
        $conn,
        "DELETE FROM contacts WHERE id = '$id'"
    );


    if ($delete_query) {

        echo "
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>

        <script>

        Swal.fire({

            icon: 'success',

            title: 'Deleted!',

            text: 'Message deleted successfully',

            timer: 1500,

            showConfirmButton: false

        }).then(function() {

            window.location.href =
                'view-contact-messages.php';

        });

        </script>
        ";

        exit;

    } else {

        echo "
        <script src='https://cdn.jsdelivr.net/npm/sweetalert2@11'></script>

        <script>

        Swal.fire({

            icon: 'error',

            title: 'Error',

            text: 'Failed to delete message'

        });

        </script>
        ";
    }
}


// ==========================================
// PAGINATION
// ==========================================

$limit = 10;

$page = isset($_GET['page'])
    ? (int)$_GET['page']
    : 1;

if ($page < 1) {
    $page = 1;
}

$offset = ($page - 1) * $limit;


// ==========================================
// SEARCH
// ==========================================

$search = isset($_GET['search'])
    ? trim($_GET['search'])
    : '';

$search = mysqli_real_escape_string(
    $conn,
    $search
);


$search_condition = '';


if ($search !== '') {

    $search_condition = "
        AND (
            name LIKE '%$search%'
            OR email LIKE '%$search%'
            OR phone LIKE '%$search%'
            OR interest LIKE '%$search%'
            OR subject LIKE '%$search%'
            OR message LIKE '%$search%'
        )
    ";
}


// ==========================================
// COUNT RECORDS
// ==========================================

$count_query = mysqli_query(
    $conn,
    "
    SELECT COUNT(*) AS total
    FROM contacts
    WHERE 1=1
    $search_condition
    "
);


$count_result = mysqli_fetch_assoc(
    $count_query
);


$total_records =
    (int)$count_result['total'];


$total_pages =
    $total_records > 0
        ? ceil($total_records / $limit)
        : 1;


// ==========================================
// GET CONTACTS
// ==========================================

$query = mysqli_query(
    $conn,
    "
    SELECT *
    FROM contacts
    WHERE 1=1
    $search_condition
    ORDER BY id DESC
    LIMIT $limit
    OFFSET $offset
    "
);


// ==========================================
// HEADER
// ==========================================

include 'header.php';

?>


<!-- ==========================================
     PAGE HEADING
========================================== -->

<div class="page-heading">

    <div class="page-heading-copy">

        <span class="page-icon">

            <i
                class="bi bi-envelope"
                aria-hidden="true"
            ></i>

        </span>


        <div>

            <p class="eyebrow mb-1">
                Contact
            </p>

            <h1 class="h3 mb-1">
                View Messages
            </h1>

            <p class="text-muted mb-0">
                Manage all contact messages
            </p>

        </div>

    </div>

</div>


<!-- ==========================================
     MAIN PANEL
========================================== -->

<section class="panel">

    <div class="panel-header">

        <div
            class="d-flex justify-content-between align-items-center flex-wrap gap-2"
        >

            <div>

                <h2 class="h5 mb-1 section-title">

                    <i
                        class="bi bi-envelope"
                        aria-hidden="true"
                    ></i>

                    <span>
                        All Messages
                    </span>

                </h2>


                <p class="text-muted mb-0">
                    View and manage contact messages
                </p>

            </div>


            <!-- SEARCH -->

            <div class="search-box">

                <input
                    type="text"
                    id="searchInput"
                    class="form-control"
                    placeholder="Search messages..."
                    value="<?php echo htmlspecialchars($search); ?>"
                >

            </div>

        </div>

    </div>


    <!-- ==========================================
         TABLE
    ========================================== -->

    <div class="table-responsive">

        <table class="table align-middle mb-0">

            <thead>

                <tr>

                    <th>
                        ID
                    </th>

                    <th>
                        Name
                    </th>

                    <th>
                        Email
                    </th>

                    <th>
                        Phone
                    </th>

                    <th>
                        Interest
                    </th>

                    <th>
                        Subject
                    </th>

                    <th>
                        Message
                    </th>

                    <th>
                        Date
                    </th>

                    <th class="text-end">
                        Action
                    </th>

                </tr>

            </thead>


            <tbody>

                <?php if (mysqli_num_rows($query) > 0) { ?>


                    <?php while ($row = mysqli_fetch_assoc($query)) { ?>

                        <tr>


                            <!-- ID -->

                            <td>

                                <?php
                                echo (int)$row['id'];
                                ?>

                            </td>


                            <!-- NAME -->

                            <td>

                                <strong>

                                    <?php
                                    echo htmlspecialchars(
                                        $row['name']
                                    );
                                    ?>

                                </strong>

                            </td>


                            <!-- EMAIL -->

                            <td>

                                <a
                                    href="mailto:<?php echo htmlspecialchars($row['email']); ?>"
                                >

                                    <?php
                                    echo htmlspecialchars(
                                        $row['email']
                                    );
                                    ?>

                                </a>

                            </td>


                            <!-- PHONE -->

                            <td>

                                <?php

                                if (!empty($row['phone'])) {

                                    ?>

                                    <a
                                        href="tel:<?php echo htmlspecialchars($row['phone']); ?>"
                                    >

                                        <?php
                                        echo htmlspecialchars(
                                            $row['phone']
                                        );
                                        ?>

                                    </a>

                                    <?php

                                } else {

                                    echo '<span class="text-muted">—</span>';

                                }

                                ?>

                            </td>


                            <!-- INTEREST -->

                            <td>

                                <?php

                                if (!empty($row['interest'])) {

                                    ?>

                                    <span class="badge bg-light text-dark">

                                        <?php
                                        echo htmlspecialchars(
                                            $row['interest']
                                        );
                                        ?>

                                    </span>

                                    <?php

                                } else {

                                    echo '<span class="text-muted">—</span>';

                                }

                                ?>

                            </td>


                            <!-- SUBJECT -->

                            <td>

                                <?php

                                if (!empty($row['subject'])) {

                                    echo htmlspecialchars(
                                        $row['subject']
                                    );

                                } else {

                                    echo '<span class="text-muted">—</span>';

                                }

                                ?>

                            </td>


                            <!-- MESSAGE -->

                            <td>

                                <?php

                                if (!empty($row['message'])) {

                                    echo htmlspecialchars(
                                        $row['message']
                                    );

                                } else {

                                    echo '<span class="text-muted">—</span>';

                                }

                                ?>

                            </td>


                            <!-- DATE -->

                            <td>

                                <?php

                                if (!empty($row['created_at'])) {

                                    echo date(
                                        'M d, Y',
                                        strtotime(
                                            $row['created_at']
                                        )
                                    );

                                } else {

                                    echo '—';

                                }

                                ?>

                            </td>


                            <!-- ACTION -->

                            <td class="text-end">

                                <button
                                    type="button"
                                    class="btn btn-danger btn-sm"
                                    onclick="confirmDelete(<?php echo (int)$row['id']; ?>)"
                                >

                                    <i class="bi bi-trash"></i>

                                </button>

                            </td>


                        </tr>

                    <?php } ?>


                <?php } else { ?>


                    <!-- NO RECORDS -->

                    <tr>

                        <td
                            colspan="9"
                            class="text-center py-5"
                        >

                            <div class="text-muted">

                                <i
                                    class="bi bi-envelope-open"
                                    style="font-size:40px;"
                                ></i>


                                <div class="mt-2">

                                    <?php

                                    if ($search !== '') {

                                        echo 'No messages found for your search.';

                                    } else {

                                        echo 'No contact messages yet.';

                                    }

                                    ?>

                                </div>

                            </div>

                        </td>

                    </tr>


                <?php } ?>

            </tbody>

        </table>

    </div>


    <!-- ==========================================
         PAGINATION
    ========================================== -->

    <?php if ($total_pages > 1) { ?>

        <nav class="mt-3">

            <ul class="pagination justify-content-center">


                <!-- PREVIOUS -->

                <?php if ($page > 1) { ?>

                    <li class="page-item">

                        <a
                            class="page-link"
                            href="view-contact-messages.php?page=<?php echo $page - 1; ?>&search=<?php echo urlencode($search); ?>"
                        >

                            Previous

                        </a>

                    </li>

                <?php } ?>


                <!-- PAGE NUMBERS -->

                <?php for (
                    $i = 1;
                    $i <= $total_pages;
                    $i++
                ) { ?>

                    <li
                        class="page-item <?php echo ($i == $page) ? 'active' : ''; ?>"
                    >

                        <a
                            class="page-link"
                            href="view-contact-messages.php?page=<?php echo $i; ?>&search=<?php echo urlencode($search); ?>"
                        >

                            <?php
                            echo $i;
                            ?>

                        </a>

                    </li>

                <?php } ?>


                <!-- NEXT -->

                <?php if ($page < $total_pages) { ?>

                    <li class="page-item">

                        <a
                            class="page-link"
                            href="view-contact-messages.php?page=<?php echo $page + 1; ?>&search=<?php echo urlencode($search); ?>"
                        >

                            Next

                        </a>

                    </li>

                <?php } ?>


            </ul>

        </nav>

    <?php } ?>


    <!-- ==========================================
         RECORD COUNT
    ========================================== -->

    <div class="text-center text-muted mt-2">

        <?php

        if ($total_records > 0) {

            $showing_from =
                $offset + 1;

            $showing_to =
                min(
                    $offset + $limit,
                    $total_records
                );

            echo
                "Showing  – $showing_to of $total_records records";

        } else {

            echo "Showing 0 of 0 records";

        }

        ?>

    </div>


</section>


<!-- ==========================================
     SWEETALERT
========================================== -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>


<!-- ==========================================
     JQUERY
========================================== -->

<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>


<script>

// ==========================================
// DELETE CONFIRMATION
// ==========================================

function confirmDelete(id) {

    Swal.fire({

        icon: 'warning',

        title: 'Delete Message?',

        text: 'This message will be permanently deleted.',

        showCancelButton: true,

        confirmButtonColor: '#d33',

        cancelButtonColor: '#6c757d',

        confirmButtonText: 'Yes, Delete',

        cancelButtonText: 'Cancel'

    }).then(function(result) {

        if (result.isConfirmed) {

            window.location.href =
                'view-contact-messages.php?delete=' + id;

        }

    });

}


// ==========================================
// SEARCH
// ==========================================

$(document).ready(function() {

    let searchTimer;


    $('#searchInput').on('keyup', function() {

        clearTimeout(searchTimer);


        const searchValue =
            $(this).val().trim();


        searchTimer = setTimeout(
            function() {

                window.location.href =
                    'view-contact-messages.php?search='
                    +
                    encodeURIComponent(
                        searchValue
                    );

            },
            500
        );

    });

});

</script>


<?php include 'footer.php'; ?>