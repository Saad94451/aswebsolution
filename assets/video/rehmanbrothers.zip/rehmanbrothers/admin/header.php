<?php
session_start();
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
  header("Location: login.php");
  exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="adminHMD professional admin dashboard template">
  <title>Admin Panel | Rehman Brothers </title>

  <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
  <link rel="stylesheet" href="./assets/vendors/bootstrap-icons/bootstrap-icons.css">
  <link rel="stylesheet" href="./assets/css/style.css">
   <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
   <script>
function toggleDropdown(dropdownId, event) {
  if (event) {
    event.stopPropagation();
    event.preventDefault();
  }
  
  var dropdownMenu = document.getElementById(dropdownId);
  var allSubmenus = document.querySelectorAll('.nav-submenu');
  
  // Close all submenus
  allSubmenus.forEach(function(menu) {
    if (menu.id !== dropdownId) {
      menu.style.display = 'none';
    }
  });
  
  // Toggle current submenu
  if (dropdownMenu.style.display === 'none' || dropdownMenu.style.display === '') {
    dropdownMenu.style.display = 'block';
  } else {
    dropdownMenu.style.display = 'none';
  }
}

function confirmLogout() {
  Swal.fire({
    title: 'Are you sure?',
    text: 'You will be logged out of your account',
    icon: 'warning',
    showCancelButton: true,
    confirmButtonColor: '#d33',
    cancelButtonColor: '#3085d6',
    confirmButtonText: 'Yes, logout!'
  }).then((result) => {
    if (result.isConfirmed) {
      window.location.href = 'logout.php';
    }
  });
}

// Prevent sidebar from closing when clicking dropdown toggles
document.addEventListener('DOMContentLoaded', function() {
  var dropdownToggles = document.querySelectorAll('.dropdown-toggle-link');
  dropdownToggles.forEach(function(toggle) {
    toggle.addEventListener('click', function(e) {
      e.stopPropagation();
      e.preventDefault();
    });
  });
});
</script>
</head>

<body>
  <div class="admin-shell">
    <div class="sidebar-backdrop" data-sidebar-close></div>

    <aside class="admin-sidebar" id="adminSidebar" aria-label="Main navigation">
      <div class="sidebar-header">
        <a class="brand-mark" href="index.php" aria-label="harnoor pallak dashboard">
         <img src="../assets/img/logoremove.png" alt="Harnoor Pallak" style="width: 50px; height: 50px;">
          <span class="brand-copy">
            <span class="brand-title">Rehman Brothers</span>
            <span class="brand-subtitle">Admin Panel</span>
          </span>
        </a>
      </div>

      <nav class="sidebar-nav">
        <a class="nav-link active" href="index.php" aria-current="page">
          <span class="nav-icon"><i class="bi bi-speedometer2" aria-hidden="true"></i></span>
          <span class="nav-text">Dashboard</span>
        </a>
        
        <!-- Portfolio Dropdown -->
        <div class="nav-item">
          <a class="nav-link dropdown-toggle-link" href="javascript:void(0)" onclick="toggleDropdown('portfolio-dropdown', event)">
            <span class="nav-icon"><i class="bi bi-images" aria-hidden="true"></i></span>
            <span class="nav-text">Inventory</span>
            <i class="bi bi-chevron-down" style="font-size: 0.8rem; margin-left: auto;"></i>
          </a>
          <ul class="nav-submenu" id="portfolio-dropdown" style="display: none; padding-left: 20px;">
            <li><a class="nav-link" href="view-inventory.php">View Inventory</a></li>
            <li><a class="nav-link" href="create-inventory.php">Create Inventory</a></li>
          
          </ul>
        </div>



        <!-- Blog Dropdown -->
        <div class="nav-item">
          <a class="nav-link dropdown-toggle-link" href="javascript:void(0)" onclick="toggleDropdown('blog-dropdown', event)">
            <span class="nav-icon"><i class="bi bi-journal-text" aria-hidden="true"></i></span>
            <span class="nav-text">Hero Section</span>
            <i class="bi bi-chevron-down" style="font-size: 0.8rem; margin-left: auto;"></i>
          </a>
          <ul class="nav-submenu" id="blog-dropdown" style="display: none; padding-left: 20px;">
            <li><a class="nav-link" href="view-hero.php">Images Management</a></li>
           
          </ul>
        </div>

     
        <!-- Contact Messages -->
        <a class="nav-link" href="view-contact-messages.php">
          <span class="nav-icon"><i class="bi bi-chat-dots" aria-hidden="true"></i></span>
          <span class="nav-text">Contact Messages</span>
        </a>

     
      </nav>

    

      <div class="sidebar-footer">
        <span class="status-dot"></span>
        <span class="sidebar-footer-text">System running smoothly</span>
      </div>
    </aside>

    <div class="admin-main">
      <nav class="navbar admin-navbar navbar-expand bg-white">
        <div class="container-fluid px-3 px-lg-4">
          <button class="sidebar-toggle" type="button" data-sidebar-toggle aria-controls="adminSidebar" aria-expanded="true" aria-label="Toggle sidebar">
            <span></span>
            <span></span>
            <span></span>
          </button>

          <form class="d-none d-md-flex ms-3 flex-grow-1" role="search">
            <input class="form-control search-input" type="search" placeholder="Search..." aria-label="Search">
          </form>

          <div class="navbar-actions ms-auto">
           
          
                <a class="dropdown-item" href="#" onclick="confirmLogout()" style="background-color:#0f4cb3;color:white;padding:5px 10px 7px 10px;border:2px solid #0f4cb3;border-radius:10px;">Logout</a>
              
            
          </div>
        </div>
      </nav>

      <main class="dashboard-content">
        <div class="container-fluid px-3 px-lg-4 py-4">

