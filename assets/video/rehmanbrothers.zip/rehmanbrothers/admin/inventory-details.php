<?php
include 'header.php';
include '../config.php';


// ==========================================
// GET VEHICLE ID
// ==========================================

if (!isset($_GET['id']) || empty($_GET['id'])) {
    echo "<script>
        window.location.href = 'view-inventory.php';
    </script>";
    exit;
}

$id = mysqli_real_escape_string($conn, $_GET['id']);


// ==========================================
// GET VEHICLE
// ==========================================

$query = mysqli_query(
    $conn,
    "SELECT * FROM inventory WHERE id = '$id' LIMIT 1"
);

if (!$query || mysqli_num_rows($query) === 0) {
    echo "<script>
        window.location.href = 'view-inventory.php';
    </script>";
    exit;
}

$row = mysqli_fetch_assoc($query);


// ==========================================
// COLLECT ALL IMAGES
// ==========================================

$vehicle_images = [];

for ($i = 1; $i <= 10; $i++) {

    $image_field = 'img_' . $i;

    if (
        isset($row[$image_field]) &&
        !empty(trim($row[$image_field]))
    ) {

        $image_name = trim($row[$image_field]);

        $vehicle_images[] = $image_name;
    }
}

?>



<!-- ==========================================
     PAGE HEADING
========================================== -->

<div class="page-heading">

    <div class="page-heading-copy">

        <span class="page-icon">
            <i class="bi bi-car-front-fill" aria-hidden="true"></i>
        </span>

        <div>

            <p class="eyebrow mb-1">
                Inventory
            </p>

            <h1 class="h3 mb-1">
                Vehicle Details
            </h1>

            <p class="text-muted mb-0">
                <?php echo htmlspecialchars($row['name']); ?>
            </p>

        </div>

    </div>


    <div class="heading-actions">

        <a
            class="btn btn-secondary btn-sm"
            href="view-inventory.php"
        >

            <i
                class="bi bi-arrow-left"
                aria-hidden="true"
            ></i>

            Back

        </a>


        <a
            class="btn btn-primary btn-sm"
            href="edit-inventory.php?id=<?php echo (int)$row['id']; ?>"
        >

            <i
                class="bi bi-pencil"
                aria-hidden="true"
            ></i>

            Edit

        </a>

    </div>

</div>



<!-- ==========================================
     VEHICLE BASIC INFORMATION
========================================== -->

<section class="panel">

    <div class="panel-header">

        <h2 class="h5 mb-1 section-title">

            <i
                class="bi bi-info-circle"
                aria-hidden="true"
            ></i>

            <span>
                Vehicle Information
            </span>

        </h2>

    </div>


    <div class="row g-4">


        <!-- VEHICLE NAME -->

        <div class="col-md-6">

            <p class="mb-2">

                <strong>
                    Vehicle Name:
                </strong>

                <?php
                echo htmlspecialchars($row['name']);
                ?>

            </p>

        </div>


        <!-- VEHICLE ID -->

        <div class="col-md-6">

            <p class="mb-2">

                <strong>
                    Vehicle ID:
                </strong>

                #<?php
                echo (int)$row['id'];
                ?>

            </p>

        </div>


        <!-- YEAR -->

        <div class="col-md-4">

            <p class="mb-2">

                <strong>
                    Year:
                </strong>

                <?php
                echo htmlspecialchars($row['year']);
                ?>

            </p>

        </div>


        <!-- CONDITION -->

        <div class="col-md-4">

            <p class="mb-2">

                <strong>
                    Condition:
                </strong>

                <?php
                echo htmlspecialchars($row['conditions']);
                ?>

            </p>

        </div>


        <!-- TRANSMISSION -->

        <div class="col-md-4">

            <p class="mb-2">

                <strong>
                    Transmission:
                </strong>

                <?php
                echo htmlspecialchars($row['transmission']);
                ?>

            </p>

        </div>


        <!-- FUEL -->

        <div class="col-md-4">

            <p class="mb-2">

                <strong>
                    Fuel:
                </strong>

                <?php
                echo htmlspecialchars($row['fuel']);
                ?>

            </p>

        </div>


        <!-- MILEAGE -->

        <div class="col-md-4">

            <p class="mb-2">

                <strong>
                    Mileage:
                </strong>

                <?php
                echo htmlspecialchars($row['mileage']);
                ?>

            </p>

        </div>


        <!-- ENGINE CAPACITY -->

        <div class="col-md-4">

            <p class="mb-2">

                <strong>
                    Engine Capacity:
                </strong>

                <?php
                echo htmlspecialchars($row['engine_capacity']);
                ?>

            </p>

        </div>


        <!-- ENGINE -->

        <div class="col-md-4">

            <p class="mb-2">

                <strong>
                    Engine:
                </strong>

                <?php
                echo htmlspecialchars($row['engine']);
                ?>

            </p>

        </div>


        <!-- COLOR -->

        <div class="col-md-4">

            <p class="mb-2">

                <strong>
                    Color:
                </strong>

                <?php
                echo htmlspecialchars($row['color']);
                ?>

            </p>

        </div>


        <!-- SEATS -->

        <div class="col-md-4">

            <p class="mb-2">

                <strong>
                    Seats:
                </strong>

                <?php
                echo htmlspecialchars($row['seats']);
                ?>

            </p>

        </div>


        <!-- PRICE -->

        <div class="col-md-6">

            <p class="mb-2">

                <strong>
                    Price:
                </strong>

                <span class="text-primary fw-bold">

                    <?php
                    echo number_format((int)$row['price']);
                    ?>

                </span>

            </p>

        </div>


        <!-- CHASSIS -->

        <div class="col-md-6">

            <p class="mb-2">

                <strong>
                    Chassis Number:
                </strong>

                <?php
                echo htmlspecialchars($row['chassis_number']);
                ?>

            </p>

        </div>


    </div>

</section>



<!-- ==========================================
     DESCRIPTION
========================================== -->

<section class="panel mt-4">

    <div class="panel-header">

        <h2 class="h5 mb-1 section-title">

            <i
                class="bi bi-card-text"
                aria-hidden="true"
            ></i>

            <span>
                Description
            </span>

        </h2>

    </div>


    <div>

        <?php if (!empty($row['description'])) { ?>

            <p class="mb-0">

                <?php
                echo nl2br(
                    htmlspecialchars($row['description'])
                );
                ?>

            </p>

        <?php } else { ?>

            <p class="text-muted mb-0">
                No description available.
            </p>

        <?php } ?>

    </div>

</section>



<!-- ==========================================
     VEHICLE IMAGES
========================================== -->

<section class="panel mt-4">

    <div class="panel-header">

        <h2 class="h5 mb-1 section-title">

            <i
                class="bi bi-images"
                aria-hidden="true"
            ></i>

            <span>
                Vehicle Images
            </span>

        </h2>

        <p class="text-muted mb-0 mt-1">

            <?php echo count($vehicle_images); ?>

            image(s)

        </p>

    </div>


    <div class="row g-3">

        <?php if (!empty($vehicle_images)) { ?>

            <?php foreach ($vehicle_images as $index => $img) { ?>

                <div class="col-6 col-md-4 col-lg-3">

                    <div
                        style="
                            width:100%;
                            height:220px;
                            overflow:hidden;
                            border-radius:10px;
                            background:#f5f5f5;
                        "
                    >

                        <img
                            src="../uploads/<?php echo htmlspecialchars($img); ?>"
                            alt="<?php echo htmlspecialchars($row['name']); ?> - Image <?php echo $index + 1; ?>"
                            style="
                                width:100%;
                                height:100%;
                                object-fit:cover;
                                display:block;
                                cursor:pointer;
                            "
                            onclick="viewImage(this.src)"
                        >

                    </div>

                </div>

            <?php } ?>

        <?php } else { ?>

            <div class="col-12">

                <div class="text-center py-5 text-muted">

                    <i
                        class="bi bi-image fs-1 d-block mb-2"
                    ></i>

                    No vehicle images available.

                </div>

            </div>

        <?php } ?>

    </div>

</section>



<!-- ==========================================
     DATABASE INFORMATION
========================================== -->

<section class="panel mt-4">

    <div class="panel-header">

        <h2 class="h5 mb-1 section-title">

            <i
                class="bi bi-clock-history"
                aria-hidden="true"
            ></i>

            <span>
                Record Information
            </span>

        </h2>

    </div>


    <div class="row g-4">


        <div class="col-md-6">

            <p class="mb-0">

                <strong>
                    Created:
                </strong>

                <?php
                echo !empty($row['created_at'])
                    ? date(
                        'd M Y, h:i A',
                        strtotime($row['created_at'])
                    )
                    : 'N/A';
                ?>

            </p>

        </div>


        <div class="col-md-6">

            <p class="mb-0">

                <strong>
                    Last Updated:
                </strong>

                <?php
                echo !empty($row['updated_at'])
                    ? date(
                        'd M Y, h:i A',
                        strtotime($row['updated_at'])
                    )
                    : 'N/A';
                ?>

            </p>

        </div>


    </div>

</section>



<!-- ==========================================
     IMAGE POPUP - SWEETALERT
========================================== -->

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

<script>

function viewImage(imageUrl) {

    Swal.fire({

        imageUrl: imageUrl,

        imageAlt: 'Vehicle Image',

        showCloseButton: true,

        showConfirmButton: false,

        width: '900px',

        background: '#ffffff',

        padding: '10px'

    });

}

</script>



<?php include 'footer.php'; ?>