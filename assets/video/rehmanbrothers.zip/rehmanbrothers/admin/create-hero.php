<?php include 'header.php'; ?>
<?php
include '../config.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $category_id = mysqli_real_escape_string($conn, trim($_POST['category_id']));
  $title = mysqli_real_escape_string($conn, trim($_POST['title']));
  $slug = mysqli_real_escape_string($conn, trim($_POST['slug']));
  $description = mysqli_real_escape_string($conn, trim($_POST['description']));
  $author_name = mysqli_real_escape_string($conn, trim($_POST['author_name']));
  $author_designation = mysqli_real_escape_string($conn, trim($_POST['author_designation']));
  $read_time = mysqli_real_escape_string($conn, trim($_POST['read_time']));
  $created_at = mysqli_real_escape_string($conn, trim($_POST['created_at']));
  
  // Blog image upload
  $blog_image = $_FILES['blog_image']['name'];
  $target_dir = "../uploads/blogs/";
  $target_file = $target_dir . basename($blog_image);
  move_uploaded_file($_FILES['blog_image']['tmp_name'], $target_file);
  
  // Author image upload
  $author_image = $_FILES['author_image']['name'];
  $author_target = "../uploads/authors/";
  $author_file = $author_target . basename($author_image);
  move_uploaded_file($_FILES['author_image']['tmp_name'], $author_file);
  
  $insert = mysqli_query($conn, "
    INSERT INTO blogs (category_id, title, slug, description, blog_image, author_name, author_designation, author_image, read_time, created_at)
    VALUES ('$category_id', '$title', '$slug', '$description', '$blog_image', '$author_name', '$author_designation', '$author_image', '$read_time', '$created_at')
  ");
  
  if ($insert) {
    echo "<script>
      Swal.fire({
        icon: 'success',
        title: 'Success!',
        text: 'Blog created successfully',
        timer: 1500,
        showConfirmButton: false
      }).then(() => {
        window.location.href = 'view-blogs.php';
      });
    </script>";
  } else {
    echo "<script>
      Swal.fire({
        icon: 'error',
        title: 'Error',
        text: 'Failed to create blog'
      });
    </script>";
  }
}
?>

<div class="page-heading">
  <div class="page-heading-copy">
    <span class="page-icon"><i class="bi bi-journal-text" aria-hidden="true"></i></span>
    <div>
      <p class="eyebrow mb-1">Blog</p>
      <h1 class="h3 mb-1">Create Blog</h1>
      <p class="text-muted mb-0">Add a new blog post</p>
    </div>
  </div>
</div>

<section class="panel">
  <div class="panel-header">
    <div>
      <h2 class="h5 mb-1 section-title"><i class="bi bi-plus-circle" aria-hidden="true"></i><span>New Blog Post</span></h2>
      <p class="text-muted mb-0">Fill in the details below</p>
    </div>
  </div>
  <form method="POST" enctype="multipart/form-data">
    <div class="row g-3">
      <div class="col-md-6">
        <label class="form-label">Category</label>
        <select class="form-select" name="category_id" required>
          <option value="">Select Category</option>
          <?php
          $categories = mysqli_query($conn, "SELECT * FROM blog_categories ORDER BY category_name ASC");
          while($cat = mysqli_fetch_assoc($categories)) {
          ?>
          <option value="<?php echo $cat['id']; ?>"><?php echo $cat['category_name']; ?></option>
          <?php } ?>
        </select>
      </div>
      <div class="col-md-6">
        <label class="form-label">Title</label>
        <input type="text" class="form-control" name="title" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Slug</label>
        <input type="text" class="form-control" name="slug" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Read Time</label>
        <input type="text" class="form-control" name="read_time" placeholder="e.g., 5 min read" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Author Name</label>
        <input type="text" class="form-control" name="author_name" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Author Designation</label>
        <input type="text" class="form-control" name="author_designation" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Created Date</label>
        <input type="date" class="form-control" name="created_at" required>
      </div>
      <div class="col-12">
        <label class="form-label">Description</label>
        <textarea class="form-control" name="description" rows="5" required></textarea>
      </div>
      <div class="col-md-6">
        <label class="form-label">Blog Image</label>
        <input type="file" class="form-control" name="blog_image" required>
      </div>
      <div class="col-md-6">
        <label class="form-label">Author Image</label>
        <input type="file" class="form-control" name="author_image" required>
      </div>
      <div class="col-12">
        <button type="submit" class="btn btn-primary">
          <i class="bi bi-check-circle"></i> Create Blog
        </button>
        <a href="view-blogs.php" class="btn btn-secondary">Cancel</a>
      </div>
    </div>
  </form>
</section>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
