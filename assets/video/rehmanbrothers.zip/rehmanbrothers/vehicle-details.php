<?php

require_once('config.php');

header('Content-Type: application/json; charset=utf-8');

$response = [
    'success' => false,
    'message' => 'Unable to load vehicle details.'
];

if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    echo json_encode($response);
    exit;
}

$id = (int) $_GET['id'];

$stmt = $conn->prepare("SELECT * FROM inventory WHERE id = ? LIMIT 1");

if (!$stmt) {
    echo json_encode($response);
    exit;
}

$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    $response['message'] = 'Vehicle not found.';
    echo json_encode($response);
    exit;
}

$vehicle = $result->fetch_assoc();


// Prepare images
$images = [];

for ($i = 1; $i <= 10; $i++) {

    $imageColumn = 'img_' . $i;

    if (
        isset($vehicle[$imageColumn]) &&
        !empty(trim($vehicle[$imageColumn]))
    ) {
        $images[] = $vehicle[$imageColumn];
    }
}


// Format response
$response = [
    'success' => true,

    'vehicle' => [
        'id' => (int) $vehicle['id'],

        'name' => $vehicle['name'],

        'year' => $vehicle['year'],

        'transmission' => $vehicle['transmission'],

        'fuel' => $vehicle['fuel'],

        'mileage' => $vehicle['mileage'],

        'price' => (int) $vehicle['price'],

        'chassis_number' => $vehicle['chassis_number'],

        'engine' => $vehicle['engine'],

        'color' => $vehicle['color'],

        'seats' => (int) $vehicle['seats'],

        'conditions' => $vehicle['conditions'],

        'description' => $vehicle['description'],

        'images' => $images
    ]
];

echo json_encode($response);

$stmt->close();
$conn->close();

?>
