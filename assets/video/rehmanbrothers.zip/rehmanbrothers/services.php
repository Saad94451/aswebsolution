﻿<?php
include('header.php');
?>

  <main class="main auto-page-main">
    <section class="auto-page-hero">
      <div class="container" data-aos="fade-up">
        <span class="auto-eyebrow">Complete Export Services</span>
        <h1>End-to-end service from auction to your port</h1>
        <p>From sourcing your car through Japan&apos;s auctions to shipping and documentation, our team handles everything. FOB and CIF options are available, with full updates at every step.</p>
      </div>
    </section>

    <section class="auto-services-page section">
      <div class="container">
        <div class="row g-4 align-items-stretch mb-5">
          <div class="col-lg-7" data-aos="fade-right">
            <div class="auto-feature-panel">
              <span class="auto-eyebrow" style="color:#77a9ff;">Your export partner</span>
              <h2>More than shipping. Full export support.</h2>
              <p>We source, inspect, and ship Japanese vehicles worldwide. Expect clear pricing, real updates, and a team that responds throughout the process.</p>
              <a class="auto-primary-btn" href="contact.html">Contact Export Team <i class="bi bi-arrow-up-right"></i></a>
            </div>
          </div>
          <div class="col-lg-5" data-aos="fade-left">
            <div class="auto-service-list">
              <div><i class="bi bi-search"></i><span><strong>Auction Sourcing</strong>We find the best cars in Japan auctions for your budget.</span></div>
              <div><i class="bi bi-camera"></i><span><strong>Vehicle Inspection</strong>Full reports, photos, and videos before you buy.</span></div>
              <div><i class="bi bi-truck-flatbed"></i><span><strong>FOB &amp; CIF Shipping</strong>Secure shipping to your port with tracking.</span></div>
              <div><i class="bi bi-file-earmark-check"></i><span><strong>Export Documentation</strong>All paperwork handled for smooth customs clearance.</span></div>
            </div>
          </div>
        </div>

        <div class="auto-section-heading">
          <div>
            <span class="auto-eyebrow">What we offer</span>
            <h2>Full-service automotive support</h2>
          </div>
        </div>

        <div class="row g-4">
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
            <article class="auto-service-card">
              <div class="auto-service-card-image">
                <img src="https://images.unsplash.com/photo-1486262715619-67b85e0b08d3?auto=format&fit=crop&w=900&q=80" alt="Vehicle inspection">
                <div class="auto-service-card-icon"><i class="bi bi-search"></i></div>
              </div>
              <div class="auto-service-card-body">
                <h3>Pre-Purchase Inspection</h3>
                <p>Know exactly what you are buying before you commit. We check engine, body, electronics, and history.</p>
                <ul>
                  <li><i class="bi bi-check-circle-fill"></i> 50+ point inspection</li>
                  <li><i class="bi bi-check-circle-fill"></i> Written condition report</li>
                  <li><i class="bi bi-check-circle-fill"></i> Honest buy/no-buy advice</li>
                </ul>
              </div>
            </article>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="150">
            <article class="auto-service-card">
              <div class="auto-service-card-image">
                <img src="https://images.unsplash.com/photo-1625047509168-a702304c0d6a?auto=format&fit=crop&w=900&q=80" alt="Car maintenance">
                <div class="auto-service-card-icon"><i class="bi bi-tools"></i></div>
              </div>
              <div class="auto-service-card-body">
                <h3>Maintenance &amp; Servicing</h3>
                <p>Keep your Japanese car running smoothly with scheduled servicing and expert mechanical support.</p>
                <ul>
                  <li><i class="bi bi-check-circle-fill"></i> Oil, filters &amp; fluids</li>
                  <li><i class="bi bi-check-circle-fill"></i> Brake &amp; suspension checks</li>
                  <li><i class="bi bi-check-circle-fill"></i> Genuine parts guidance</li>
                </ul>
              </div>
            </article>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
            <article class="auto-service-card">
              <div class="auto-service-card-image">
                <img src="https://images.unsplash.com/photo-1492144534655-ae79c964c9d7?auto=format&fit=crop&w=900&q=80" alt="Car modifications">
                <div class="auto-service-card-icon"><i class="bi bi-stars"></i></div>
              </div>
              <div class="auto-service-card-body">
                <h3>Modifications &amp; Upgrades</h3>
                <p>Personalize your ride with tasteful upgrades â€” alloy wheels, audio, lighting, and interior improvements.</p>
                <ul>
                  <li><i class="bi bi-check-circle-fill"></i> Wheels &amp; tyres</li>
                  <li><i class="bi bi-check-circle-fill"></i> Audio &amp; infotainment</li>
                  <li><i class="bi bi-check-circle-fill"></i> Interior &amp; exterior styling</li>
                </ul>
              </div>
            </article>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="250">
            <article class="auto-service-card">
              <div class="auto-service-card-image">
                <img src="https://images.unsplash.com/photo-1554224311-beee415c201f?auto=format&fit=crop&w=900&q=80" alt="Documentation">
                <div class="auto-service-card-icon"><i class="bi bi-file-earmark-check"></i></div>
              </div>
              <div class="auto-service-card-body">
                <h3>Documentation &amp; Transfer</h3>
                <p>We handle the paperwork so you can focus on the excitement of your new car.</p>
                <ul>
                  <li><i class="bi bi-check-circle-fill"></i> Ownership transfer</li>
                  <li><i class="bi bi-check-circle-fill"></i> Registration guidance</li>
                  <li><i class="bi bi-check-circle-fill"></i> Import documentation</li>
                </ul>
              </div>
            </article>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
            <article class="auto-service-card">
              <div class="auto-service-card-image">
                <img src="https://images.unsplash.com/photo-1605559424843-9e4c228bf1c2?auto=format&fit=crop&w=900&q=80" alt="Vehicle sourcing">
                <div class="auto-service-card-icon"><i class="bi bi-car-front"></i></div>
              </div>
              <div class="auto-service-card-body">
                <h3>Custom Vehicle Sourcing</h3>
                <p>Cannot find the exact model in stock? Tell us your requirements and we will source it for you.</p>
                <ul>
                  <li><i class="bi bi-check-circle-fill"></i> Japan &amp; local sourcing</li>
                  <li><i class="bi bi-check-circle-fill"></i> Budget-matched options</li>
                  <li><i class="bi bi-check-circle-fill"></i> Progress updates</li>
                </ul>
              </div>
            </article>
          </div>
          <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="350">
            <article class="auto-service-card">
              <div class="auto-service-card-image">
                <img src="https://images.unsplash.com/photo-1568605117036-5fe5e7bab0b7?auto=format&fit=crop&w=900&q=80" alt="After sales support">
                <div class="auto-service-card-icon"><i class="bi bi-headset"></i></div>
              </div>
              <div class="auto-service-card-body">
                <h3>After-Sales Support</h3>
                <p>Questions after delivery? We are still here â€” for advice, referrals, and ongoing care.</p>
                <ul>
                  <li><i class="bi bi-check-circle-fill"></i> Dedicated support line</li>
                  <li><i class="bi bi-check-circle-fill"></i> Service reminders</li>
                  <li><i class="bi bi-check-circle-fill"></i> Resale guidance</li>
                </ul>
              </div>
            </article>
          </div>
        </div>
      </div>
    </section>

    <section class="section pt-0 pb-5">
      <div class="container" data-aos="fade-up">
        <div class="auto-cta-strip d-flex flex-column flex-lg-row align-items-lg-center justify-content-between gap-4">
          <div>
            <span class="auto-eyebrow" style="color:#77a9ff;">Find your right car</span>
            <h2>Want a car that fits your needs?</h2>
            <p>Contact us and our team will help you find the right car with honest guidance and clear answers.</p>
          </div>
          <a class="auto-primary-btn" href="contact.html">Contact us <i class="bi bi-arrow-up-right"></i></a>
        </div>
      </div>
    </section>
  </main>

    <?php
include('footer.php');
?>